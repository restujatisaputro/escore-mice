<?php 
        // fungsi header dengan mengirimkan raw data excel
        header("Content-type: application/vnd-ms-excel");
         
        // membuat nama file ekspor "export-to-excel.xls"
        header("Content-Disposition: attachment; filename=export_csv.xls");
        
        $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
        
		$id_website = $_POST['id_website'];
		$alamat_website = $_POST['alamat_website'];
?>
<body>
    <h4>OFFICIAL LEISURE TOURISM WEBSITE (GREEN D WEB VARIABLES)</h4>
    <table cellspacing='0'>
		<thead>
			<tr>
	    		<th rowspan='2'>No</th>
				<th rowspan='2'>Indicators</th>
			
				<th>Web 1</th>
				<th>Web 2</th>    
				<th>Web 3</th>    
				<th>Web 4</th>
				<th>Web 5</th>
				<th>Web 6</th>
				<th>Web 7</th>
				<th>Web 8</th>
				<th>Web 9</th>
				<th>Web 10</th>
			</tr>
		
				<tr>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data1 = mysqli_query($connect, "select * from tb_website where id_website = '1' ");
                                while($result1 = mysqli_fetch_array($data1)){
	                                echo $result1["alamat_website"];
	                   ?>
	                        </br>
	                   <?php
	                        echo $result1["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data2 = mysqli_query($connect, "select * from tb_website where id_website = '2' ");
                                while($result2 = mysqli_fetch_array($data2)){
	                                echo $result2["alamat_website"];
	                        ?>
	                        </br>
	                   <?php
	                        echo $result2["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data3 = mysqli_query($connect, "select * from tb_website where id_website = '3' ");
                                while($result3 = mysqli_fetch_array($data3)){
	                                echo $result3["alamat_website"];
	                        ?>
	                        </br>
	                   <?php
	                        echo $result3["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data4 = mysqli_query($connect, "select * from tb_website where id_website = '4' ");
                                while($result4 = mysqli_fetch_array($data4)){
	                                echo $result4["alamat_website"];
	                        ?>
	                        </br>
	                   <?php
	                        echo $result4["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data5 = mysqli_query($connect, "select * from tb_website where id_website = '5' ");
                                while($result5 = mysqli_fetch_array($data5)){
	                                echo $result5["alamat_website"];
	                        ?>
	                        </br>
	                   <?php
	                        echo $result5["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data6 = mysqli_query($connect, "select * from tb_website where id_website = '6' ");
                                while($result6 = mysqli_fetch_array($data6)){
	                                echo $result6["alamat_website"];
	                        ?>
	                                </br>
	                       <?php         
	                                echo $result6["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data7 = mysqli_query($connect, "select * from tb_website where id_website = '7' ");
                                while($result7 = mysqli_fetch_array($data7)){
	                                echo $result7["alamat_website"];
	                       ?>
	                                </br>
	                       <?php         
	                                echo $result7["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data8 = mysqli_query($connect, "select * from tb_website where id_website = '8' ");
                                while($result8 = mysqli_fetch_array($data8)){
	                                echo $result8["alamat_website"];
	                       ?>
	                                </br>
	                       <?php         
	                                echo $result8["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data9 = mysqli_query($connect, "select * from tb_website where id_website = '9' ");
                                while($result9 = mysqli_fetch_array($data9)){
	                                echo $result9["alamat_website"];
	                       ?>
	                                </br>
	                       <?php         
	                                echo $result9["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data10 = mysqli_query($connect, "select * from tb_website where id_website = '10' ");
                                while($result10 = mysqli_fetch_array($data10)){
	                                echo $result10["alamat_website"];
	                       ?>
	                                </br>
	                       <?php         
	                                echo $result10["negara"];
	                        }
                        ?>
				    </th>
				</tr>
			</thead>
			<tbody>
			    <?php
                    $data11 = mysqli_query($connect, "select * from tb_indikator where kelompok = 'GREEN D WEB VARIABLES' ORDER BY id_indikator ASC ");
                    
			        $no=1; // Nomor urut dalam menampilkan data
				  
			        // Menampilkan data Penganggaran Obat
			        foreach($data11 as $row11)
		            {
			    ?>
			        <tr>
			            <td><?php echo $no++ ; ?></td>
			            <td><?php echo $row11['indikator'] ; ?></td>
			            <td>
			                <?php
			                    $data11 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key1 FROM tb_analisakeyword WHERE id_website = '1' and id_indikator ='$row11[id_indikator]' ");
                                    while($result11=mysqli_fetch_array($data11)){	
                                    $nilai_key_1 = $result11["nilai_key1"];
                                    if($nilai_key_1 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data12 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2 FROM tb_analisakeyword WHERE id_website = '2' and id_indikator ='$row11[id_indikator]' ");
                                    while($result12=mysqli_fetch_array($data12)){	
                                    $nilai_key_2 = $result12["nilai_key2"];
                                    if($nilai_key_2 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data13 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key3 FROM tb_analisakeyword WHERE id_website = '3' and id_indikator ='$row11[id_indikator]' ");
                                    while($result13=mysqli_fetch_array($data13)){	
                                    $nilai_key_3 = $result13["nilai_key3"];
                                    if($nilai_key_3 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data14 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key4 FROM tb_analisakeyword WHERE id_website = '4' and id_indikator ='$row11[id_indikator]' ");
                                    while($result14=mysqli_fetch_array($data14)){	
                                    $nilai_key_4 = $result14["nilai_key4"];
                                    if($nilai_key_4 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data15 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key5 FROM tb_analisakeyword WHERE id_website = '5' and id_indikator ='$row11[id_indikator]' ");
                                    while($result15=mysqli_fetch_array($data15)){	
                                    $nilai_key_5 = $result15["nilai_key5"];
                                    if($nilai_key_5 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data16 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key6 FROM tb_analisakeyword WHERE id_website = '6' and id_indikator ='$row11[id_indikator]' ");
                                    while($result16=mysqli_fetch_array($data16)){	
                                    $nilai_key_6 = $result16["nilai_key6"];
                                    if($nilai_key_6 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data17 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key7 FROM tb_analisakeyword WHERE id_website = '7' and id_indikator ='$row11[id_indikator]' ");
                                    while($result17=mysqli_fetch_array($data17)){	
                                    $nilai_key_7 = $result17["nilai_key7"];
                                    if($nilai_key_7 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data18 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key8 FROM tb_analisakeyword WHERE id_website = '8' and id_indikator ='$row11[id_indikator]' ");
                                    while($result18=mysqli_fetch_array($data18)){	
                                    $nilai_key_8 = $result18["nilai_key8"];
                                    if($nilai_key_8 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data19 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key9 FROM tb_analisakeyword WHERE id_website = '9' and id_indikator ='$row11[id_indikator]' ");
                                    while($result19=mysqli_fetch_array($data19)){	
                                    $nilai_key_9 = $result19["nilai_key9"];
                                    if($nilai_key_9 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            
			            <td>
			                <?php
			                    $data20 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key10 FROM tb_analisakeyword WHERE id_website = '10' and id_indikator ='$row11[id_indikator]' ");
                                    while($result20=mysqli_fetch_array($data20)){	
                                    $nilai_key_10 = $result20["nilai_key10"];
                                    if($nilai_key_10 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			        </tr>
			    <?php
		            }
		        ?>
			</tbody>
			</table>

</br>

<h4>OFFICIAL Website (MICE or CVB)</h4>
    <table cellspacing='0'>
		<thead>
			<tr>
	    		<th rowspan='2'>No</th>
				<th rowspan='2'>Indicators</th>
			
				<th>Web 1</th>
				<th>Web 2</th>    
				<th>Web 3</th>    
				<th>Web 4</th>
				<th>Web 5</th>
				<th>Web 6</th>
				<th>Web 7</th>
				<th>Web 8</th>
				<th>Web 9</th>
				<th>Web 10</th>
				<th>Web 11</th>
			</tr>
		
				<tr>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data1 = mysqli_query($connect, "select * from tb_website where id_website = '11' ");
                                while($result1 = mysqli_fetch_array($data1)){
	                                echo $result1["alamat_website"];
	                   ?>
	                        </br>
	                   <?php
	                        echo $result1["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data2 = mysqli_query($connect, "select * from tb_website where id_website = '12' ");
                                while($result2 = mysqli_fetch_array($data2)){
	                                echo $result2["alamat_website"];
	                        ?>
	                        </br>
	                   <?php
	                        echo $result2["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data3 = mysqli_query($connect, "select * from tb_website where id_website = '13' ");
                                while($result3 = mysqli_fetch_array($data3)){
	                                echo $result3["alamat_website"];
	                        ?>
	                        </br>
	                   <?php
	                        echo $result3["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data4 = mysqli_query($connect, "select * from tb_website where id_website = '14' ");
                                while($result4 = mysqli_fetch_array($data4)){
	                                echo $result4["alamat_website"];
	                        ?>
	                        </br>
	                   <?php
	                        echo $result4["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data5 = mysqli_query($connect, "select * from tb_website where id_website = '15' ");
                                while($result5 = mysqli_fetch_array($data5)){
	                                echo $result5["alamat_website"];
	                        ?>
	                        </br>
	                   <?php
	                        echo $result5["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data6 = mysqli_query($connect, "select * from tb_website where id_website = '16' ");
                                while($result6 = mysqli_fetch_array($data6)){
	                                echo $result6["alamat_website"];
	                        ?>
	                                </br>
	                       <?php         
	                                echo $result6["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data7 = mysqli_query($connect, "select * from tb_website where id_website = '17' ");
                                while($result7 = mysqli_fetch_array($data7)){
	                                echo $result7["alamat_website"];
	                       ?>
	                                </br>
	                       <?php         
	                                echo $result7["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data8 = mysqli_query($connect, "select * from tb_website where id_website = '18' ");
                                while($result8 = mysqli_fetch_array($data8)){
	                                echo $result8["alamat_website"];
	                       ?>
	                                </br>
	                       <?php         
	                                echo $result8["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data9 = mysqli_query($connect, "select * from tb_website where id_website = '19' ");
                                while($result9 = mysqli_fetch_array($data9)){
	                                echo $result9["alamat_website"];
	                       ?>
	                                </br>
	                       <?php         
	                                echo $result9["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data10 = mysqli_query($connect, "select * from tb_website where id_website = '20' ");
                                while($result10 = mysqli_fetch_array($data10)){
	                                echo $result10["alamat_website"];
	                       ?>
	                                </br>
	                       <?php         
	                                echo $result10["negara"];
	                        }
                        ?>
				    </th>
				    <th align='center'>
				        <?php
				            $connect=mysqli_connect("localhost", "u197914754_green", "Andri13021980", "u197914754_green");
				            $data10 = mysqli_query($connect, "select * from tb_website where id_website = '21' ");
                                while($result10 = mysqli_fetch_array($data10)){
	                                echo $result10["alamat_website"];
	                       ?>
	                                </br>
	                       <?php         
	                                echo $result10["negara"];
	                        }
                        ?>
				    </th>
				</tr>
			</thead>
			<tbody>
			    <?php
                    $data11 = mysqli_query($connect, "select * from tb_indikator where kelompok = 'MICE or CVB' ORDER BY id_indikator ASC ");
                    
			        $no=1; // Nomor urut dalam menampilkan data
				  
			        // Menampilkan data Penganggaran Obat
			        foreach($data11 as $row11)
		            {
			    ?>
			        <tr>
			            <td><?php echo $no++ ; ?></td>
			            <td><?php echo $row11['indikator'] ; ?></td>
			            <td>
			                <?php
			                    $data21 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_1 FROM tb_analisakeyword WHERE id_website = '11' and id_indikator ='$row11[id_indikator]' ");
                                    while($result21=mysqli_fetch_array($data21)){	
                                    $nilai_key2_1 = $result21["nilai_key2_1"];
                                    if($nilai_key2_1 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data22 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_2 FROM tb_analisakeyword WHERE id_website = '12' and id_indikator ='$row11[id_indikator]' ");
                                    while($result22=mysqli_fetch_array($data22)){	
                                    $nilai_key2_2 = $result22["nilai_key2_2"];
                                    if($nilai_key2_2 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                                }
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data23 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_3 FROM tb_analisakeyword WHERE id_website = '13' and id_indikator ='$row11[id_indikator]' ");
                                    while($result23=mysqli_fetch_array($data23)){	
                                    $nilai_key2_3 = $result23["nilai_key2_3"];
                                    if($nilai_key2_3 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data24 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_4 FROM tb_analisakeyword WHERE id_website = '14' and id_indikator ='$row11[id_indikator]' ");
                                    while($result24=mysqli_fetch_array($data24)){	
                                    $nilai_key2_4 = $result24["nilai_key2_4"];
                                    if($nilai_key2_4 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data25 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_5 FROM tb_analisakeyword WHERE id_website = '15' and id_indikator ='$row11[id_indikator]' ");
                                    while($result25=mysqli_fetch_array($data25)){	
                                    $nilai_key2_5 = $result25["nilai_key2_5"];
                                    if($nilai_key2_5 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data26 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_6 FROM tb_analisakeyword WHERE id_website = '16' and id_indikator ='$row11[id_indikator]' ");
                                    while($result26=mysqli_fetch_array($data26)){	
                                    $nilai_key2_6 = $result26["nilai_key2_6"];
                                    if($nilai_key2_6 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                                }
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data27 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_7 FROM tb_analisakeyword WHERE id_website = '17' and id_indikator ='$row11[id_indikator]' ");
                                    while($result27=mysqli_fetch_array($data27)){	
                                    $nilai_key2_7 = $result27["nilai_key2_7"];
                                    if($nilai_key2_7 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                                }
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data28 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_8 FROM tb_analisakeyword WHERE id_website = '18' and id_indikator ='$row11[id_indikator]' ");
                                    while($result28=mysqli_fetch_array($data28)){	
                                    $nilai_key2_8 = $result28["nilai_key2_8"];
                                    if($nilai_key2_8 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                                }
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data29 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_9 FROM tb_analisakeyword WHERE id_website = '19' and id_indikator ='$row11[id_indikator]' ");
                                    while($result29=mysqli_fetch_array($data29)){	
                                    $nilai_key2_9 = $result29["nilai_key2_9"];
                                    if($nilai_key2_9 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            
			            <td>
			                <?php
			                    $data30 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_10 FROM tb_analisakeyword WHERE id_website = '20' and id_indikator ='$row11[id_indikator]' ");
                                    while($result30=mysqli_fetch_array($data30)){	
                                    $nilai_key2_10 = $result30["nilai_key2_10"];
                                    if($nilai_key2_10 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			            <td>
			                <?php
			                    $data31 = mysqli_query($connect, "SELECT SUM(nilai_indikator) AS nilai_key2_11 FROM tb_analisakeyword WHERE id_website = '21' and id_indikator ='$row11[id_indikator]' ");
                                    while($result31=mysqli_fetch_array($data31)){	
                                    $nilai_key2_11 = $result31["nilai_key2_11"];
                                    if($nilai_key2_11 > 0){
                                        echo 1 ;
                                    }else{ echo 0 ; }
                            }
		                        
			                ?>
			            </td>
			        </tr>
			    <?php
		            }
		        ?>
			</tbody>
			</table>


</body>