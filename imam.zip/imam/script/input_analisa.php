<?php
    
    $alamat_website     = $_POST['alamat_website'];
    $source_code_input  = $_POST['source_code'];
    $inputer            = $_POST['inputer'];


	// print_r($alamat_website);
	// die;
    
    $connect=mysqli_connect("localhost", "root", "", "imam");
    
    $data = mysqli_query($connect, "select * from tb_website where alamat_website = '$alamat_website' ");
		while($result = mysqli_fetch_array($data)){
			$id_website = $result["id_website"];	
		}
		
    $filter = array(".",",","!","?","(",")","-","_");
	$filter_source_code = str_replace($filter, "", $source_code_input);
    $source_code = strtolower($filter_source_code);
    
    $data1= mysqli_query($connect,"select * from tb_indikator where id_indikator='1'");		
	
	while($result1 = mysqli_fetch_array($data1)){	
	$indikator1 = $result1['indikator'];	
	$indikator_kecil1 = strtolower($indikator1);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator1 = str_replace($filter, '', $indikator_kecil1);	
	$tes = explode(' ', $filter_indikator1);
	foreach($tes as $x) {
		echo "$x <br>";
	  }
	  die;
	list($key1_1, $key1_2, $key1_3, $key1_4, $key1_5, $key1_6, $key1_7, $key1_8, $key1_9, $key1_10, $key1_11, $key1_12, $key1_13, $key1_14, $key1_15) = explode(' ', $filter_indikator1) ? explode(' ', $filter_indikator1) : null;
		$jumlah_key1_1 = substr_count($source_code, $key1_1);
		$jumlah_key1_2 = substr_count($source_code, $key1_2);
		$jumlah_key1_3 = substr_count($source_code, $key1_3);
		$jumlah_key1_4 = substr_count($source_code, $key1_4);
		$jumlah_key1_5 = substr_count($source_code, $key1_5);
		$jumlah_key1_6 = substr_count($source_code, $key1_6);
		$jumlah_key1_7 = substr_count($source_code, $key1_7);
		$jumlah_key1_8 = substr_count($source_code, $key1_8);
		$jumlah_key1_9 = substr_count($source_code, $key1_9);
		$jumlah_key1_10 = substr_count($source_code, $key1_10);
		$jumlah_key1_11 = substr_count($source_code, $key1_11);
		$jumlah_key1_12 = substr_count($source_code, $key1_12);
		$jumlah_key1_13 = substr_count($source_code, $key1_13);
		$jumlah_key1_14 = substr_count($source_code, $key1_14);
		$jumlah_key1_15 = substr_count($source_code, $key1_15);
	}	
	
	if($jumlah_key1_1 > 0){$jumlah_key1_1hasil = 1 ; }else{$jumlah_key1_1hasil = 0 ;}
    if($jumlah_key1_2 > 0){$jumlah_key1_2hasil = 1 ; }else{$jumlah_key1_2hasil = 0 ;}
    if($jumlah_key1_3 > 0){$jumlah_key1_3hasil = 1 ; }else{$jumlah_key1_3hasil = 0 ;}
    if($jumlah_key1_4 > 0){$jumlah_key1_4hasil = 1 ; }else{$jumlah_key1_4hasil = 0 ;}
    if($jumlah_key1_5 > 0){$jumlah_key1_5hasil = 1 ; }else{$jumlah_key1_5hasil = 0 ;}
    if($jumlah_key1_6 > 0){$jumlah_key1_6hasil = 1 ; }else{$jumlah_key1_6hasil = 0 ;}
    if($jumlah_key1_7 > 0){$jumlah_key1_7hasil = 1 ; }else{$jumlah_key1_7hasil = 0 ;}
    if($jumlah_key1_8 > 0){$jumlah_key1_8hasil = 1 ; }else{$jumlah_key1_8hasil = 0 ;}
    if($jumlah_key1_9 > 0){$jumlah_key1_9hasil = 1 ; }else{$jumlah_key1_9hasil = 0 ;}
    if($jumlah_key1_10 > 0){$jumlah_key1_10hasil = 1 ; }else{$jumlah_key1_10hasil = 0 ;}
    if($jumlah_key1_11 > 0){$jumlah_key1_11hasil = 1 ; }else{$jumlah_key1_11hasil = 0 ;}
    if($jumlah_key1_12 > 0){$jumlah_key1_12hasil = 1 ; }else{$jumlah_key1_12hasil = 0 ;}
    if($jumlah_key1_13 > 0){$jumlah_key1_13hasil = 1 ; }else{$jumlah_key1_13hasil = 0 ;}
    if($jumlah_key1_14 > 0){$jumlah_key1_14hasil = 1 ; }else{$jumlah_key1_14hasil = 0 ;}
    if($jumlah_key1_15 > 0){$jumlah_key1_15hasil = 1 ; }else{$jumlah_key1_15hasil = 0 ;}


    mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES
        ('$id_website', '$alamat_website', '1', '$key1_1hasil', '$jumlah_key1_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_2hasil', '$jumlah_key1_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_3hasil', '$jumlah_key1_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_4hasil', '$jumlah_key1_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_5hasil', '$jumlah_key1_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_6hasil', '$jumlah_key1_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_7hasil', '$jumlah_key1_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_8hasil', '$jumlah_key1_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_9hasil', '$jumlah_key1_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_10hasil', '$jumlah_key1_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_11hasil', '$jumlah_key1_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_12hasil', '$jumlah_key1_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_13hasil', '$jumlah_key1_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_14hasil', '$jumlah_key1_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),
        ('$id_website', '$alamat_website', '1', '$key1_15hasil', '$jumlah_key1_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )
    ");
    
    
    $data2= mysqli_query($connect,"select * from tb_indikator where id_indikator='2'");		
	    while($result2 = mysqli_fetch_array($data2)){	
	        $indikator2 = $result2['indikator'];	
	        $indikator_kecil2 = strtolower($indikator2);	
	        $filter = array(".",",","!","?","(",")","-","_");	
	        $filter_indikator2 = str_replace($filter, '', $indikator_kecil2);	
	        list($key2_1, $key2_2, $key2_3, $key2_4, $key2_5, $key2_6, $key2_7, $key2_8, $key2_9, $key2_10, $key2_11, $key2_12, $key2_13, $key2_14, $key2_15) = explode(' ', $filter_indikator2);
		        $jumlah_key2_1 = substr_count($source_code, $key2_1);
		        $jumlah_key2_2 = substr_count($source_code, $key2_2);
		        $jumlah_key2_3 = substr_count($source_code, $key2_3);
		        $jumlah_key2_4 = substr_count($source_code, $key2_4);
		        $jumlah_key2_5 = substr_count($source_code, $key2_5);
		        $jumlah_key2_6 = substr_count($source_code, $key2_6);
		        $jumlah_key2_7 = substr_count($source_code, $key2_7);
		        $jumlah_key2_8 = substr_count($source_code, $key2_8);
		        $jumlah_key2_9 = substr_count($source_code, $key2_9);
		        $jumlah_key2_10 = substr_count($source_code, $key2_10);
		        $jumlah_key2_11 = substr_count($source_code, $key2_11);
		        $jumlah_key2_12 = substr_count($source_code, $key2_12);
		        $jumlah_key2_13 = substr_count($source_code, $key2_13);
		        $jumlah_key2_14 = substr_count($source_code, $key2_14);
		        $jumlah_key2_15 = substr_count($source_code, $key2_15);
	        }	
		
    if($jumlah_key2_1 > 0){$jumlah_key2_1hasil = 1 ; }else{$jumlah_key2_1hasil = 0 ;}		
    if($jumlah_key2_2 > 0){$jumlah_key2_2hasil = 1 ; }else{$jumlah_key2_2hasil = 0 ;}		
    if($jumlah_key2_3 > 0){$jumlah_key2_3hasil = 1 ; }else{$jumlah_key2_3hasil = 0 ;}		
    if($jumlah_key2_4 > 0){$jumlah_key2_4hasil = 1 ; }else{$jumlah_key2_4hasil = 0 ;}		
    if($jumlah_key2_5 > 0){$jumlah_key2_5hasil = 1 ; }else{$jumlah_key2_5hasil = 0 ;}		
    if($jumlah_key2_6 > 0){$jumlah_key2_6hasil = 1 ; }else{$jumlah_key2_6hasil = 0 ;}		
    if($jumlah_key2_7 > 0){$jumlah_key2_7hasil = 1 ; }else{$jumlah_key2_7hasil = 0 ;}		
    if($jumlah_key2_8 > 0){$jumlah_key2_8hasil = 1 ; }else{$jumlah_key2_8hasil = 0 ;}		
    if($jumlah_key2_9 > 0){$jumlah_key2_9hasil = 1 ; }else{$jumlah_key2_9hasil = 0 ;}		
    if($jumlah_key2_10 > 0){$jumlah_key2_10hasil = 1 ; }else{$jumlah_key2_10hasil = 0 ;}		
    if($jumlah_key2_11 > 0){$jumlah_key2_11hasil = 1 ; }else{$jumlah_key2_11hasil = 0 ;}		
    if($jumlah_key2_12 > 0){$jumlah_key2_12hasil = 1 ; }else{$jumlah_key2_12hasil = 0 ;}		
    if($jumlah_key2_13 > 0){$jumlah_key2_13hasil = 1 ; }else{$jumlah_key2_13hasil = 0 ;}		
    if($jumlah_key2_14 > 0){$jumlah_key2_14hasil = 1 ; }else{$jumlah_key2_14hasil = 0 ;}		
    if($jumlah_key2_15 > 0){$jumlah_key2_15hasil = 1 ; }else{$jumlah_key2_15hasil = 0 ;}		
		
		
    mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
        ('$id_website', '$alamat_website', '2', '$key2_1hasil', '$jumlah_key2_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_2hasil', '$jumlah_key2_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_3hasil', '$jumlah_key2_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_4hasil', '$jumlah_key2_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_5hasil', '$jumlah_key2_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_6hasil', '$jumlah_key2_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_7hasil', '$jumlah_key2_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_8hasil', '$jumlah_key2_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_9hasil', '$jumlah_key2_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_10hasil', '$jumlah_key2_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_11hasil', '$jumlah_key2_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_12hasil', '$jumlah_key2_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_13hasil', '$jumlah_key2_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_14hasil', '$jumlah_key2_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
        ('$id_website', '$alamat_website', '2', '$key2_15hasil', '$jumlah_key2_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )	
    ");		
    
    $data3= mysqli_query($connect,"select * from tb_indikator where id_indikator='3'");		
	while($result3 = mysqli_fetch_array($data3)){	
	$indikator3 = $result3['indikator'];	
	$indikator_kecil3 = strtolower($indikator3);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator3 = str_replace($filter, '', $indikator_kecil3);	
	list($key3_1, $key3_2, $key3_3, $key3_4, $key3_5, $key3_6, $key3_7, $key3_8, $key3_9, $key3_10, $key3_11, $key3_12, $key3_13, $key3_14, $key3_15) = explode(' ', $filter_indikator3);	
		$jumlah_key3_1 = substr_count($source_code, $key3_1);
		$jumlah_key3_2 = substr_count($source_code, $key3_2);
		$jumlah_key3_3 = substr_count($source_code, $key3_3);
		$jumlah_key3_4 = substr_count($source_code, $key3_4);
		$jumlah_key3_5 = substr_count($source_code, $key3_5);
		$jumlah_key3_6 = substr_count($source_code, $key3_6);
		$jumlah_key3_7 = substr_count($source_code, $key3_7);
		$jumlah_key3_8 = substr_count($source_code, $key3_8);
		$jumlah_key3_9 = substr_count($source_code, $key3_9);
		$jumlah_key3_10 = substr_count($source_code, $key3_10);
		$jumlah_key3_11 = substr_count($source_code, $key3_11);
		$jumlah_key3_12 = substr_count($source_code, $key3_12);
		$jumlah_key3_13 = substr_count($source_code, $key3_13);
		$jumlah_key3_14 = substr_count($source_code, $key3_14);
		$jumlah_key3_15 = substr_count($source_code, $key3_15);
	    }	
		
if($jumlah_key3_1 > 0){$jumlah_key3_1hasil = 1 ; }else{$jumlah_key3_1hasil = 0 ;}		
if($jumlah_key3_2 > 0){$jumlah_key3_2hasil = 1 ; }else{$jumlah_key3_2hasil = 0 ;}		
if($jumlah_key3_3 > 0){$jumlah_key3_3hasil = 1 ; }else{$jumlah_key3_3hasil = 0 ;}		
if($jumlah_key3_4 > 0){$jumlah_key3_4hasil = 1 ; }else{$jumlah_key3_4hasil = 0 ;}		
if($jumlah_key3_5 > 0){$jumlah_key3_5hasil = 1 ; }else{$jumlah_key3_5hasil = 0 ;}		
if($jumlah_key3_6 > 0){$jumlah_key3_6hasil = 1 ; }else{$jumlah_key3_6hasil = 0 ;}		
if($jumlah_key3_7 > 0){$jumlah_key3_7hasil = 1 ; }else{$jumlah_key3_7hasil = 0 ;}		
if($jumlah_key3_8 > 0){$jumlah_key3_8hasil = 1 ; }else{$jumlah_key3_8hasil = 0 ;}		
if($jumlah_key3_9 > 0){$jumlah_key3_9hasil = 1 ; }else{$jumlah_key3_9hasil = 0 ;}		
if($jumlah_key3_10 > 0){$jumlah_key3_10hasil = 1 ; }else{$jumlah_key3_10hasil = 0 ;}		
if($jumlah_key3_11 > 0){$jumlah_key3_11hasil = 1 ; }else{$jumlah_key3_11hasil = 0 ;}		
if($jumlah_key3_12 > 0){$jumlah_key3_12hasil = 1 ; }else{$jumlah_key3_12hasil = 0 ;}		
if($jumlah_key3_13 > 0){$jumlah_key3_13hasil = 1 ; }else{$jumlah_key3_13hasil = 0 ;}		
if($jumlah_key3_14 > 0){$jumlah_key3_14hasil = 1 ; }else{$jumlah_key3_14hasil = 0 ;}		
if($jumlah_key3_15 > 0){$jumlah_key3_15hasil = 1 ; }else{$jumlah_key3_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '3', '$key3_1hasil', '$jumlah_key3_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_2hasil', '$jumlah_key3_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_3hasil', '$jumlah_key3_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_4hasil', '$jumlah_key3_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_5hasil', '$jumlah_key3_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_6hasil', '$jumlah_key3_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_7hasil', '$jumlah_key3_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_8hasil', '$jumlah_key3_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_9hasil', '$jumlah_key3_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_10hasil', '$jumlah_key3_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_11hasil', '$jumlah_key3_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_12hasil', '$jumlah_key3_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_13hasil', '$jumlah_key3_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_14hasil', '$jumlah_key3_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '3', '$key3_15hasil', '$jumlah_key3_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data4= mysqli_query($connect,"select * from tb_indikator where id_indikator='4'");		
	while($result4 = mysqli_fetch_array($data4)){	
	$indikator4 = $result4['indikator'];	
	$indikator_kecil4 = strtolower($indikator4);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator4 = str_replace($filter, '', $indikator_kecil4);	
	list($key4_1, $key4_2, $key4_3, $key4_4, $key4_5, $key4_6, $key4_7, $key4_8, $key4_9, $key4_10, $key4_11, $key4_12, $key4_13, $key4_14, $key4_15) = explode(' ', $filter_indikator4);	
		$jumlah_key4_1 = substr_count($source_code, $key4_1);
		$jumlah_key4_2 = substr_count($source_code, $key4_2);
		$jumlah_key4_3 = substr_count($source_code, $key4_3);
		$jumlah_key4_4 = substr_count($source_code, $key4_4);
		$jumlah_key4_5 = substr_count($source_code, $key4_5);
		$jumlah_key4_6 = substr_count($source_code, $key4_6);
		$jumlah_key4_7 = substr_count($source_code, $key4_7);
		$jumlah_key4_8 = substr_count($source_code, $key4_8);
		$jumlah_key4_9 = substr_count($source_code, $key4_9);
		$jumlah_key4_10 = substr_count($source_code, $key4_10);
		$jumlah_key4_11 = substr_count($source_code, $key4_11);
		$jumlah_key4_12 = substr_count($source_code, $key4_12);
		$jumlah_key4_13 = substr_count($source_code, $key4_13);
		$jumlah_key4_14 = substr_count($source_code, $key4_14);
		$jumlah_key4_15 = substr_count($source_code, $key4_15);
	    }	
		
if($jumlah_key4_1 > 0){$jumlah_key4_1hasil = 1 ; }else{$jumlah_key4_1hasil = 0 ;}		
if($jumlah_key4_2 > 0){$jumlah_key4_2hasil = 1 ; }else{$jumlah_key4_2hasil = 0 ;}		
if($jumlah_key4_3 > 0){$jumlah_key4_3hasil = 1 ; }else{$jumlah_key4_3hasil = 0 ;}		
if($jumlah_key4_4 > 0){$jumlah_key4_4hasil = 1 ; }else{$jumlah_key4_4hasil = 0 ;}		
if($jumlah_key4_5 > 0){$jumlah_key4_5hasil = 1 ; }else{$jumlah_key4_5hasil = 0 ;}		
if($jumlah_key4_6 > 0){$jumlah_key4_6hasil = 1 ; }else{$jumlah_key4_6hasil = 0 ;}		
if($jumlah_key4_7 > 0){$jumlah_key4_7hasil = 1 ; }else{$jumlah_key4_7hasil = 0 ;}		
if($jumlah_key4_8 > 0){$jumlah_key4_8hasil = 1 ; }else{$jumlah_key4_8hasil = 0 ;}		
if($jumlah_key4_9 > 0){$jumlah_key4_9hasil = 1 ; }else{$jumlah_key4_9hasil = 0 ;}		
if($jumlah_key4_10 > 0){$jumlah_key4_10hasil = 1 ; }else{$jumlah_key4_10hasil = 0 ;}		
if($jumlah_key4_11 > 0){$jumlah_key4_11hasil = 1 ; }else{$jumlah_key4_11hasil = 0 ;}		
if($jumlah_key4_12 > 0){$jumlah_key4_12hasil = 1 ; }else{$jumlah_key4_12hasil = 0 ;}		
if($jumlah_key4_13 > 0){$jumlah_key4_13hasil = 1 ; }else{$jumlah_key4_13hasil = 0 ;}		
if($jumlah_key4_14 > 0){$jumlah_key4_14hasil = 1 ; }else{$jumlah_key4_14hasil = 0 ;}		
if($jumlah_key4_15 > 0){$jumlah_key4_15hasil = 1 ; }else{$jumlah_key4_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '4', '$key4_1hasil', '$jumlah_key4_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_2hasil', '$jumlah_key4_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_3hasil', '$jumlah_key4_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_4hasil', '$jumlah_key4_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_5hasil', '$jumlah_key4_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_6hasil', '$jumlah_key4_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_7hasil', '$jumlah_key4_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_8hasil', '$jumlah_key4_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_9hasil', '$jumlah_key4_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_10hasil', '$jumlah_key4_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_11hasil', '$jumlah_key4_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_12hasil', '$jumlah_key4_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_13hasil', '$jumlah_key4_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_14hasil', '$jumlah_key4_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '4', '$key4_15hasil', '$jumlah_key4_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data5= mysqli_query($connect,"select * from tb_indikator where id_indikator='5'");		
	while($result5 = mysqli_fetch_array($data5)){	
	$indikator5 = $result5['indikator'];	
	$indikator_kecil5 = strtolower($indikator5);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator5 = str_replace($filter, '', $indikator_kecil5);	
	list($key5_1, $key5_2, $key5_3, $key5_4, $key5_5, $key5_6, $key5_7, $key5_8, $key5_9, $key5_10, $key5_11, $key5_12, $key5_13, $key5_14, $key5_15) = explode(' ', $filter_indikator5);	
		$jumlah_key5_1 = substr_count($source_code, $key5_1);
		$jumlah_key5_2 = substr_count($source_code, $key5_2);
		$jumlah_key5_3 = substr_count($source_code, $key5_3);
		$jumlah_key5_4 = substr_count($source_code, $key5_4);
		$jumlah_key5_5 = substr_count($source_code, $key5_5);
		$jumlah_key5_6 = substr_count($source_code, $key5_6);
		$jumlah_key5_7 = substr_count($source_code, $key5_7);
		$jumlah_key5_8 = substr_count($source_code, $key5_8);
		$jumlah_key5_9 = substr_count($source_code, $key5_9);
		$jumlah_key5_10 = substr_count($source_code, $key5_10);
		$jumlah_key5_11 = substr_count($source_code, $key5_11);
		$jumlah_key5_12 = substr_count($source_code, $key5_12);
		$jumlah_key5_13 = substr_count($source_code, $key5_13);
		$jumlah_key5_14 = substr_count($source_code, $key5_14);
		$jumlah_key5_15 = substr_count($source_code, $key5_15);
	    }	
		
if($jumlah_key5_1 > 0){$jumlah_key5_1hasil = 1 ; }else{$jumlah_key5_1hasil = 0 ;}		
if($jumlah_key5_2 > 0){$jumlah_key5_2hasil = 1 ; }else{$jumlah_key5_2hasil = 0 ;}		
if($jumlah_key5_3 > 0){$jumlah_key5_3hasil = 1 ; }else{$jumlah_key5_3hasil = 0 ;}		
if($jumlah_key5_4 > 0){$jumlah_key5_4hasil = 1 ; }else{$jumlah_key5_4hasil = 0 ;}		
if($jumlah_key5_5 > 0){$jumlah_key5_5hasil = 1 ; }else{$jumlah_key5_5hasil = 0 ;}		
if($jumlah_key5_6 > 0){$jumlah_key5_6hasil = 1 ; }else{$jumlah_key5_6hasil = 0 ;}		
if($jumlah_key5_7 > 0){$jumlah_key5_7hasil = 1 ; }else{$jumlah_key5_7hasil = 0 ;}		
if($jumlah_key5_8 > 0){$jumlah_key5_8hasil = 1 ; }else{$jumlah_key5_8hasil = 0 ;}		
if($jumlah_key5_9 > 0){$jumlah_key5_9hasil = 1 ; }else{$jumlah_key5_9hasil = 0 ;}		
if($jumlah_key5_10 > 0){$jumlah_key5_10hasil = 1 ; }else{$jumlah_key5_10hasil = 0 ;}		
if($jumlah_key5_11 > 0){$jumlah_key5_11hasil = 1 ; }else{$jumlah_key5_11hasil = 0 ;}		
if($jumlah_key5_12 > 0){$jumlah_key5_12hasil = 1 ; }else{$jumlah_key5_12hasil = 0 ;}		
if($jumlah_key5_13 > 0){$jumlah_key5_13hasil = 1 ; }else{$jumlah_key5_13hasil = 0 ;}		
if($jumlah_key5_14 > 0){$jumlah_key5_14hasil = 1 ; }else{$jumlah_key5_14hasil = 0 ;}		
if($jumlah_key5_15 > 0){$jumlah_key5_15hasil = 1 ; }else{$jumlah_key5_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '5', '$key5_1hasil', '$jumlah_key5_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_2hasil', '$jumlah_key5_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_3hasil', '$jumlah_key5_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_4hasil', '$jumlah_key5_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_5hasil', '$jumlah_key5_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_6hasil', '$jumlah_key5_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_7hasil', '$jumlah_key5_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_8hasil', '$jumlah_key5_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_9hasil', '$jumlah_key5_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_10hasil', '$jumlah_key5_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_11hasil', '$jumlah_key5_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_12hasil', '$jumlah_key5_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_13hasil', '$jumlah_key5_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_14hasil', '$jumlah_key5_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '5', '$key5_15hasil', '$jumlah_key5_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data6= mysqli_query($connect,"select * from tb_indikator where id_indikator='6'");		
	while($result6 = mysqli_fetch_array($data6)){	
	$indikator6 = $result6['indikator'];	
	$indikator_kecil6 = strtolower($indikator6);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator6 = str_replace($filter, '', $indikator_kecil6);	
	list($key6_1, $key6_2, $key6_3, $key6_4, $key6_5, $key6_6, $key6_7, $key6_8, $key6_9, $key6_10, $key6_11, $key6_12, $key6_13, $key6_14, $key6_15) = explode(' ', $filter_indikator6);	
		$jumlah_key6_1 = substr_count($source_code, $key6_1);
		$jumlah_key6_2 = substr_count($source_code, $key6_2);
		$jumlah_key6_3 = substr_count($source_code, $key6_3);
		$jumlah_key6_4 = substr_count($source_code, $key6_4);
		$jumlah_key6_5 = substr_count($source_code, $key6_5);
		$jumlah_key6_6 = substr_count($source_code, $key6_6);
		$jumlah_key6_7 = substr_count($source_code, $key6_7);
		$jumlah_key6_8 = substr_count($source_code, $key6_8);
		$jumlah_key6_9 = substr_count($source_code, $key6_9);
		$jumlah_key6_10 = substr_count($source_code, $key6_10);
		$jumlah_key6_11 = substr_count($source_code, $key6_11);
		$jumlah_key6_12 = substr_count($source_code, $key6_12);
		$jumlah_key6_13 = substr_count($source_code, $key6_13);
		$jumlah_key6_14 = substr_count($source_code, $key6_14);
		$jumlah_key6_15 = substr_count($source_code, $key6_15);
	    }	
		
if($jumlah_key6_1 > 0){$jumlah_key6_1hasil = 1 ; }else{$jumlah_key6_1hasil = 0 ;}		
if($jumlah_key6_2 > 0){$jumlah_key6_2hasil = 1 ; }else{$jumlah_key6_2hasil = 0 ;}		
if($jumlah_key6_3 > 0){$jumlah_key6_3hasil = 1 ; }else{$jumlah_key6_3hasil = 0 ;}		
if($jumlah_key6_4 > 0){$jumlah_key6_4hasil = 1 ; }else{$jumlah_key6_4hasil = 0 ;}		
if($jumlah_key6_5 > 0){$jumlah_key6_5hasil = 1 ; }else{$jumlah_key6_5hasil = 0 ;}		
if($jumlah_key6_6 > 0){$jumlah_key6_6hasil = 1 ; }else{$jumlah_key6_6hasil = 0 ;}		
if($jumlah_key6_7 > 0){$jumlah_key6_7hasil = 1 ; }else{$jumlah_key6_7hasil = 0 ;}		
if($jumlah_key6_8 > 0){$jumlah_key6_8hasil = 1 ; }else{$jumlah_key6_8hasil = 0 ;}		
if($jumlah_key6_9 > 0){$jumlah_key6_9hasil = 1 ; }else{$jumlah_key6_9hasil = 0 ;}		
if($jumlah_key6_10 > 0){$jumlah_key6_10hasil = 1 ; }else{$jumlah_key6_10hasil = 0 ;}		
if($jumlah_key6_11 > 0){$jumlah_key6_11hasil = 1 ; }else{$jumlah_key6_11hasil = 0 ;}		
if($jumlah_key6_12 > 0){$jumlah_key6_12hasil = 1 ; }else{$jumlah_key6_12hasil = 0 ;}		
if($jumlah_key6_13 > 0){$jumlah_key6_13hasil = 1 ; }else{$jumlah_key6_13hasil = 0 ;}		
if($jumlah_key6_14 > 0){$jumlah_key6_14hasil = 1 ; }else{$jumlah_key6_14hasil = 0 ;}		
if($jumlah_key6_15 > 0){$jumlah_key6_15hasil = 1 ; }else{$jumlah_key6_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '6', '$key6_1hasil', '$jumlah_key6_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_2hasil', '$jumlah_key6_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_3hasil', '$jumlah_key6_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_4hasil', '$jumlah_key6_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_5hasil', '$jumlah_key6_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_6hasil', '$jumlah_key6_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_7hasil', '$jumlah_key6_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_8hasil', '$jumlah_key6_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_9hasil', '$jumlah_key6_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_10hasil', '$jumlah_key6_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_11hasil', '$jumlah_key6_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_12hasil', '$jumlah_key6_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_13hasil', '$jumlah_key6_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_14hasil', '$jumlah_key6_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '6', '$key6_15hasil', '$jumlah_key6_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data7= mysqli_query($connect,"select * from tb_indikator where id_indikator='7'");		
	while($result7 = mysqli_fetch_array($data7)){	
	$indikator7 = $result7['indikator'];	
	$indikator_kecil7 = strtolower($indikator7);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator7 = str_replace($filter, '', $indikator_kecil7);	
	list($key7_1, $key7_2, $key7_3, $key7_4, $key7_5, $key7_6, $key7_7, $key7_8, $key7_9, $key7_10, $key7_11, $key7_12, $key7_13, $key7_14, $key7_15) = explode(' ', $filter_indikator7);	
		$jumlah_key7_1 = substr_count($source_code, $key7_1);
		$jumlah_key7_2 = substr_count($source_code, $key7_2);
		$jumlah_key7_3 = substr_count($source_code, $key7_3);
		$jumlah_key7_4 = substr_count($source_code, $key7_4);
		$jumlah_key7_5 = substr_count($source_code, $key7_5);
		$jumlah_key7_6 = substr_count($source_code, $key7_6);
		$jumlah_key7_7 = substr_count($source_code, $key7_7);
		$jumlah_key7_8 = substr_count($source_code, $key7_8);
		$jumlah_key7_9 = substr_count($source_code, $key7_9);
		$jumlah_key7_10 = substr_count($source_code, $key7_10);
		$jumlah_key7_11 = substr_count($source_code, $key7_11);
		$jumlah_key7_12 = substr_count($source_code, $key7_12);
		$jumlah_key7_13 = substr_count($source_code, $key7_13);
		$jumlah_key7_14 = substr_count($source_code, $key7_14);
		$jumlah_key7_15 = substr_count($source_code, $key7_15);
	    }	
		
if($jumlah_key7_1 > 0){$jumlah_key7_1hasil = 1 ; }else{$jumlah_key7_1hasil = 0 ;}		
if($jumlah_key7_2 > 0){$jumlah_key7_2hasil = 1 ; }else{$jumlah_key7_2hasil = 0 ;}		
if($jumlah_key7_3 > 0){$jumlah_key7_3hasil = 1 ; }else{$jumlah_key7_3hasil = 0 ;}		
if($jumlah_key7_4 > 0){$jumlah_key7_4hasil = 1 ; }else{$jumlah_key7_4hasil = 0 ;}		
if($jumlah_key7_5 > 0){$jumlah_key7_5hasil = 1 ; }else{$jumlah_key7_5hasil = 0 ;}		
if($jumlah_key7_6 > 0){$jumlah_key7_6hasil = 1 ; }else{$jumlah_key7_6hasil = 0 ;}		
if($jumlah_key7_7 > 0){$jumlah_key7_7hasil = 1 ; }else{$jumlah_key7_7hasil = 0 ;}		
if($jumlah_key7_8 > 0){$jumlah_key7_8hasil = 1 ; }else{$jumlah_key7_8hasil = 0 ;}		
if($jumlah_key7_9 > 0){$jumlah_key7_9hasil = 1 ; }else{$jumlah_key7_9hasil = 0 ;}		
if($jumlah_key7_10 > 0){$jumlah_key7_10hasil = 1 ; }else{$jumlah_key7_10hasil = 0 ;}		
if($jumlah_key7_11 > 0){$jumlah_key7_11hasil = 1 ; }else{$jumlah_key7_11hasil = 0 ;}		
if($jumlah_key7_12 > 0){$jumlah_key7_12hasil = 1 ; }else{$jumlah_key7_12hasil = 0 ;}		
if($jumlah_key7_13 > 0){$jumlah_key7_13hasil = 1 ; }else{$jumlah_key7_13hasil = 0 ;}		
if($jumlah_key7_14 > 0){$jumlah_key7_14hasil = 1 ; }else{$jumlah_key7_14hasil = 0 ;}		
if($jumlah_key7_15 > 0){$jumlah_key7_15hasil = 1 ; }else{$jumlah_key7_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '7', '$key7_1hasil', '$jumlah_key7_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_2hasil', '$jumlah_key7_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_3hasil', '$jumlah_key7_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_4hasil', '$jumlah_key7_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_5hasil', '$jumlah_key7_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_6hasil', '$jumlah_key7_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_7hasil', '$jumlah_key7_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_8hasil', '$jumlah_key7_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_9hasil', '$jumlah_key7_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_10hasil', '$jumlah_key7_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_11hasil', '$jumlah_key7_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_12hasil', '$jumlah_key7_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_13hasil', '$jumlah_key7_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_14hasil', '$jumlah_key7_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '7', '$key7_15hasil', '$jumlah_key7_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		


$data8= mysqli_query($connect,"select * from tb_indikator where id_indikator='8'");		
	while($result8 = mysqli_fetch_array($data8)){	
	$indikator8 = $result8['indikator'];	
	$indikator_kecil8 = strtolower($indikator8);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator8 = str_replace($filter, '', $indikator_kecil8);	
	list($key8_1, $key8_2, $key8_3, $key8_4, $key8_5, $key8_6, $key8_7, $key8_8, $key8_9, $key8_10, $key8_11, $key8_12, $key8_13, $key8_14, $key8_15) = explode(' ', $filter_indikator8);	
		$jumlah_key8_1 = substr_count($source_code, $key8_1);
		$jumlah_key8_2 = substr_count($source_code, $key8_2);
		$jumlah_key8_3 = substr_count($source_code, $key8_3);
		$jumlah_key8_4 = substr_count($source_code, $key8_4);
		$jumlah_key8_5 = substr_count($source_code, $key8_5);
		$jumlah_key8_6 = substr_count($source_code, $key8_6);
		$jumlah_key8_7 = substr_count($source_code, $key8_7);
		$jumlah_key8_8 = substr_count($source_code, $key8_8);
		$jumlah_key8_9 = substr_count($source_code, $key8_9);
		$jumlah_key8_10 = substr_count($source_code, $key8_10);
		$jumlah_key8_11 = substr_count($source_code, $key8_11);
		$jumlah_key8_12 = substr_count($source_code, $key8_12);
		$jumlah_key8_13 = substr_count($source_code, $key8_13);
		$jumlah_key8_14 = substr_count($source_code, $key8_14);
		$jumlah_key8_15 = substr_count($source_code, $key8_15);
	    }	
		
if($jumlah_key8_1 > 0){$jumlah_key8_1hasil = 1 ; }else{$jumlah_key8_1hasil = 0 ;}		
if($jumlah_key8_2 > 0){$jumlah_key8_2hasil = 1 ; }else{$jumlah_key8_2hasil = 0 ;}		
if($jumlah_key8_3 > 0){$jumlah_key8_3hasil = 1 ; }else{$jumlah_key8_3hasil = 0 ;}		
if($jumlah_key8_4 > 0){$jumlah_key8_4hasil = 1 ; }else{$jumlah_key8_4hasil = 0 ;}		
if($jumlah_key8_5 > 0){$jumlah_key8_5hasil = 1 ; }else{$jumlah_key8_5hasil = 0 ;}		
if($jumlah_key8_6 > 0){$jumlah_key8_6hasil = 1 ; }else{$jumlah_key8_6hasil = 0 ;}		
if($jumlah_key8_7 > 0){$jumlah_key8_7hasil = 1 ; }else{$jumlah_key8_7hasil = 0 ;}		
if($jumlah_key8_8 > 0){$jumlah_key8_8hasil = 1 ; }else{$jumlah_key8_8hasil = 0 ;}		
if($jumlah_key8_9 > 0){$jumlah_key8_9hasil = 1 ; }else{$jumlah_key8_9hasil = 0 ;}		
if($jumlah_key8_10 > 0){$jumlah_key8_10hasil = 1 ; }else{$jumlah_key8_10hasil = 0 ;}		
if($jumlah_key8_11 > 0){$jumlah_key8_11hasil = 1 ; }else{$jumlah_key8_11hasil = 0 ;}		
if($jumlah_key8_12 > 0){$jumlah_key8_12hasil = 1 ; }else{$jumlah_key8_12hasil = 0 ;}		
if($jumlah_key8_13 > 0){$jumlah_key8_13hasil = 1 ; }else{$jumlah_key8_13hasil = 0 ;}		
if($jumlah_key8_14 > 0){$jumlah_key8_14hasil = 1 ; }else{$jumlah_key8_14hasil = 0 ;}		
if($jumlah_key8_15 > 0){$jumlah_key8_15hasil = 1 ; }else{$jumlah_key8_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '8', '$key8_1hasil', '$jumlah_key8_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_2hasil', '$jumlah_key8_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_3hasil', '$jumlah_key8_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_4hasil', '$jumlah_key8_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_5hasil', '$jumlah_key8_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_6hasil', '$jumlah_key8_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_7hasil', '$jumlah_key8_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_8hasil', '$jumlah_key8_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_9hasil', '$jumlah_key8_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_10hasil', '$jumlah_key8_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_11hasil', '$jumlah_key8_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_12hasil', '$jumlah_key8_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_13hasil', '$jumlah_key8_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_14hasil', '$jumlah_key8_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '8', '$key8_15hasil', '$jumlah_key8_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data9= mysqli_query($connect,"select * from tb_indikator where id_indikator='9'");		
	while($result9 = mysqli_fetch_array($data9)){	
	$indikator9 = $result9['indikator'];	
	$indikator_kecil9 = strtolower($indikator9);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator9 = str_replace($filter, '', $indikator_kecil9);	
	list($key9_1, $key9_2, $key9_3, $key9_4, $key9_5, $key9_6, $key9_7, $key9_8, $key9_9, $key9_10, $key9_11, $key9_12, $key9_13, $key9_14, $key9_15) = explode(' ', $filter_indikator9);	
		$jumlah_key9_1 = substr_count($source_code, $key9_1);
		$jumlah_key9_2 = substr_count($source_code, $key9_2);
		$jumlah_key9_3 = substr_count($source_code, $key9_3);
		$jumlah_key9_4 = substr_count($source_code, $key9_4);
		$jumlah_key9_5 = substr_count($source_code, $key9_5);
		$jumlah_key9_6 = substr_count($source_code, $key9_6);
		$jumlah_key9_7 = substr_count($source_code, $key9_7);
		$jumlah_key9_8 = substr_count($source_code, $key9_8);
		$jumlah_key9_9 = substr_count($source_code, $key9_9);
		$jumlah_key9_10 = substr_count($source_code, $key9_10);
		$jumlah_key9_11 = substr_count($source_code, $key9_11);
		$jumlah_key9_12 = substr_count($source_code, $key9_12);
		$jumlah_key9_13 = substr_count($source_code, $key9_13);
		$jumlah_key9_14 = substr_count($source_code, $key9_14);
		$jumlah_key9_15 = substr_count($source_code, $key9_15);
	    }	
		
if($jumlah_key9_1 > 0){$jumlah_key9_1hasil = 1 ; }else{$jumlah_key9_1hasil = 0 ;}		
if($jumlah_key9_2 > 0){$jumlah_key9_2hasil = 1 ; }else{$jumlah_key9_2hasil = 0 ;}		
if($jumlah_key9_3 > 0){$jumlah_key9_3hasil = 1 ; }else{$jumlah_key9_3hasil = 0 ;}		
if($jumlah_key9_4 > 0){$jumlah_key9_4hasil = 1 ; }else{$jumlah_key9_4hasil = 0 ;}		
if($jumlah_key9_5 > 0){$jumlah_key9_5hasil = 1 ; }else{$jumlah_key9_5hasil = 0 ;}		
if($jumlah_key9_6 > 0){$jumlah_key9_6hasil = 1 ; }else{$jumlah_key9_6hasil = 0 ;}		
if($jumlah_key9_7 > 0){$jumlah_key9_7hasil = 1 ; }else{$jumlah_key9_7hasil = 0 ;}		
if($jumlah_key9_8 > 0){$jumlah_key9_8hasil = 1 ; }else{$jumlah_key9_8hasil = 0 ;}		
if($jumlah_key9_9 > 0){$jumlah_key9_9hasil = 1 ; }else{$jumlah_key9_9hasil = 0 ;}		
if($jumlah_key9_10 > 0){$jumlah_key9_10hasil = 1 ; }else{$jumlah_key9_10hasil = 0 ;}		
if($jumlah_key9_11 > 0){$jumlah_key9_11hasil = 1 ; }else{$jumlah_key9_11hasil = 0 ;}		
if($jumlah_key9_12 > 0){$jumlah_key9_12hasil = 1 ; }else{$jumlah_key9_12hasil = 0 ;}		
if($jumlah_key9_13 > 0){$jumlah_key9_13hasil = 1 ; }else{$jumlah_key9_13hasil = 0 ;}		
if($jumlah_key9_14 > 0){$jumlah_key9_14hasil = 1 ; }else{$jumlah_key9_14hasil = 0 ;}		
if($jumlah_key9_15 > 0){$jumlah_key9_15hasil = 1 ; }else{$jumlah_key9_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '9', '$key9_1hasil', '$jumlah_key9_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_2hasil', '$jumlah_key9_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_3hasil', '$jumlah_key9_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_4hasil', '$jumlah_key9_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_5hasil', '$jumlah_key9_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_6hasil', '$jumlah_key9_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_7hasil', '$jumlah_key9_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_8hasil', '$jumlah_key9_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_9hasil', '$jumlah_key9_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_10hasil', '$jumlah_key9_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_11hasil', '$jumlah_key9_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_12hasil', '$jumlah_key9_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_13hasil', '$jumlah_key9_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_14hasil', '$jumlah_key9_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '9', '$key9_15hasil', '$jumlah_key9_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		


$data10= mysqli_query($connect,"select * from tb_indikator where id_indikator='10'");		
	while($result10 = mysqli_fetch_array($data10)){	
	$indikator10 = $result10['indikator'];	
	$indikator_kecil10 = strtolower($indikator10);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator10 = str_replace($filter, '', $indikator_kecil10);	
	list($key10_1, $key10_2, $key10_3, $key10_4, $key10_5, $key10_6, $key10_7, $key10_8, $key10_9, $key10_10, $key10_11, $key10_12, $key10_13, $key10_14, $key10_15) = explode(' ', $filter_indikator10);	
		$jumlah_key10_1 = substr_count($source_code, $key10_1);
		$jumlah_key10_2 = substr_count($source_code, $key10_2);
		$jumlah_key10_3 = substr_count($source_code, $key10_3);
		$jumlah_key10_4 = substr_count($source_code, $key10_4);
		$jumlah_key10_5 = substr_count($source_code, $key10_5);
		$jumlah_key10_6 = substr_count($source_code, $key10_6);
		$jumlah_key10_7 = substr_count($source_code, $key10_7);
		$jumlah_key10_8 = substr_count($source_code, $key10_8);
		$jumlah_key10_9 = substr_count($source_code, $key10_9);
		$jumlah_key10_10 = substr_count($source_code, $key10_10);
		$jumlah_key10_11 = substr_count($source_code, $key10_11);
		$jumlah_key10_12 = substr_count($source_code, $key10_12);
		$jumlah_key10_13 = substr_count($source_code, $key10_13);
		$jumlah_key10_14 = substr_count($source_code, $key10_14);
		$jumlah_key10_15 = substr_count($source_code, $key10_15);
	    }	
		
if($jumlah_key10_1 > 0){$jumlah_key10_1hasil = 1 ; }else{$jumlah_key10_1hasil = 0 ;}		
if($jumlah_key10_2 > 0){$jumlah_key10_2hasil = 1 ; }else{$jumlah_key10_2hasil = 0 ;}		
if($jumlah_key10_3 > 0){$jumlah_key10_3hasil = 1 ; }else{$jumlah_key10_3hasil = 0 ;}		
if($jumlah_key10_4 > 0){$jumlah_key10_4hasil = 1 ; }else{$jumlah_key10_4hasil = 0 ;}		
if($jumlah_key10_5 > 0){$jumlah_key10_5hasil = 1 ; }else{$jumlah_key10_5hasil = 0 ;}		
if($jumlah_key10_6 > 0){$jumlah_key10_6hasil = 1 ; }else{$jumlah_key10_6hasil = 0 ;}		
if($jumlah_key10_7 > 0){$jumlah_key10_7hasil = 1 ; }else{$jumlah_key10_7hasil = 0 ;}		
if($jumlah_key10_8 > 0){$jumlah_key10_8hasil = 1 ; }else{$jumlah_key10_8hasil = 0 ;}		
if($jumlah_key10_9 > 0){$jumlah_key10_9hasil = 1 ; }else{$jumlah_key10_9hasil = 0 ;}		
if($jumlah_key10_10 > 0){$jumlah_key10_10hasil = 1 ; }else{$jumlah_key10_10hasil = 0 ;}		
if($jumlah_key10_11 > 0){$jumlah_key10_11hasil = 1 ; }else{$jumlah_key10_11hasil = 0 ;}		
if($jumlah_key10_12 > 0){$jumlah_key10_12hasil = 1 ; }else{$jumlah_key10_12hasil = 0 ;}		
if($jumlah_key10_13 > 0){$jumlah_key10_13hasil = 1 ; }else{$jumlah_key10_13hasil = 0 ;}		
if($jumlah_key10_14 > 0){$jumlah_key10_14hasil = 1 ; }else{$jumlah_key10_14hasil = 0 ;}		
if($jumlah_key10_15 > 0){$jumlah_key10_15hasil = 1 ; }else{$jumlah_key10_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '10', '$key10_1hasil', '$jumlah_key10_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_2hasil', '$jumlah_key10_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_3hasil', '$jumlah_key10_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_4hasil', '$jumlah_key10_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_5hasil', '$jumlah_key10_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_6hasil', '$jumlah_key10_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_7hasil', '$jumlah_key10_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_8hasil', '$jumlah_key10_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_9hasil', '$jumlah_key10_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_10hasil', '$jumlah_key10_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_11hasil', '$jumlah_key10_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_12hasil', '$jumlah_key10_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_13hasil', '$jumlah_key10_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_14hasil', '$jumlah_key10_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '10', '$key10_15hasil', '$jumlah_key10_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data11= mysqli_query($connect,"select * from tb_indikator where id_indikator='11'");		
	while($result11 = mysqli_fetch_array($data11)){	
	$indikator11 = $result11['indikator'];	
	$indikator_kecil11 = strtolower($indikator11);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator11 = str_replace($filter, '', $indikator_kecil11);	
	list($key11_1, $key11_2, $key11_3, $key11_4, $key11_5, $key11_6, $key11_7, $key11_8, $key11_9, $key11_10, $key11_11, $key11_12, $key11_13, $key11_14, $key11_15) = explode(' ', $filter_indikator11);	
		$jumlah_key11_1 = substr_count($source_code, $key11_1);
		$jumlah_key11_2 = substr_count($source_code, $key11_2);
		$jumlah_key11_3 = substr_count($source_code, $key11_3);
		$jumlah_key11_4 = substr_count($source_code, $key11_4);
		$jumlah_key11_5 = substr_count($source_code, $key11_5);
		$jumlah_key11_6 = substr_count($source_code, $key11_6);
		$jumlah_key11_7 = substr_count($source_code, $key11_7);
		$jumlah_key11_8 = substr_count($source_code, $key11_8);
		$jumlah_key11_9 = substr_count($source_code, $key11_9);
		$jumlah_key11_10 = substr_count($source_code, $key11_10);
		$jumlah_key11_11 = substr_count($source_code, $key11_11);
		$jumlah_key11_12 = substr_count($source_code, $key11_12);
		$jumlah_key11_13 = substr_count($source_code, $key11_13);
		$jumlah_key11_14 = substr_count($source_code, $key11_14);
		$jumlah_key11_15 = substr_count($source_code, $key11_15);
	    }	
		
if($jumlah_key11_1 > 0){$jumlah_key11_1hasil = 1 ; }else{$jumlah_key11_1hasil = 0 ;}		
if($jumlah_key11_2 > 0){$jumlah_key11_2hasil = 1 ; }else{$jumlah_key11_2hasil = 0 ;}		
if($jumlah_key11_3 > 0){$jumlah_key11_3hasil = 1 ; }else{$jumlah_key11_3hasil = 0 ;}		
if($jumlah_key11_4 > 0){$jumlah_key11_4hasil = 1 ; }else{$jumlah_key11_4hasil = 0 ;}		
if($jumlah_key11_5 > 0){$jumlah_key11_5hasil = 1 ; }else{$jumlah_key11_5hasil = 0 ;}		
if($jumlah_key11_6 > 0){$jumlah_key11_6hasil = 1 ; }else{$jumlah_key11_6hasil = 0 ;}		
if($jumlah_key11_7 > 0){$jumlah_key11_7hasil = 1 ; }else{$jumlah_key11_7hasil = 0 ;}		
if($jumlah_key11_8 > 0){$jumlah_key11_8hasil = 1 ; }else{$jumlah_key11_8hasil = 0 ;}		
if($jumlah_key11_9 > 0){$jumlah_key11_9hasil = 1 ; }else{$jumlah_key11_9hasil = 0 ;}		
if($jumlah_key11_10 > 0){$jumlah_key11_10hasil = 1 ; }else{$jumlah_key11_10hasil = 0 ;}		
if($jumlah_key11_11 > 0){$jumlah_key11_11hasil = 1 ; }else{$jumlah_key11_11hasil = 0 ;}		
if($jumlah_key11_12 > 0){$jumlah_key11_12hasil = 1 ; }else{$jumlah_key11_12hasil = 0 ;}		
if($jumlah_key11_13 > 0){$jumlah_key11_13hasil = 1 ; }else{$jumlah_key11_13hasil = 0 ;}		
if($jumlah_key11_14 > 0){$jumlah_key11_14hasil = 1 ; }else{$jumlah_key11_14hasil = 0 ;}		
if($jumlah_key11_15 > 0){$jumlah_key11_15hasil = 1 ; }else{$jumlah_key11_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '11', '$key11_1hasil', '$jumlah_key11_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_2hasil', '$jumlah_key11_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_3hasil', '$jumlah_key11_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_4hasil', '$jumlah_key11_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_5hasil', '$jumlah_key11_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_6hasil', '$jumlah_key11_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_7hasil', '$jumlah_key11_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_8hasil', '$jumlah_key11_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_9hasil', '$jumlah_key11_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_10hasil', '$jumlah_key11_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_11hasil', '$jumlah_key11_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_12hasil', '$jumlah_key11_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_13hasil', '$jumlah_key11_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_14hasil', '$jumlah_key11_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '11', '$key11_15hasil', '$jumlah_key11_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data12= mysqli_query($connect,"select * from tb_indikator where id_indikator='12'");		
	while($result12 = mysqli_fetch_array($data12)){	
	$indikator12 = $result12['indikator'];	
	$indikator_kecil12 = strtolower($indikator12);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator12 = str_replace($filter, '', $indikator_kecil12);	
	list($key12_1, $key12_2, $key12_3, $key12_4, $key12_5, $key12_6, $key12_7, $key12_8, $key12_9, $key12_10, $key12_11, $key12_12, $key12_13, $key12_14, $key12_15) = explode(' ', $filter_indikator12);	
		$jumlah_key12_1 = substr_count($source_code, $key12_1);
		$jumlah_key12_2 = substr_count($source_code, $key12_2);
		$jumlah_key12_3 = substr_count($source_code, $key12_3);
		$jumlah_key12_4 = substr_count($source_code, $key12_4);
		$jumlah_key12_5 = substr_count($source_code, $key12_5);
		$jumlah_key12_6 = substr_count($source_code, $key12_6);
		$jumlah_key12_7 = substr_count($source_code, $key12_7);
		$jumlah_key12_8 = substr_count($source_code, $key12_8);
		$jumlah_key12_9 = substr_count($source_code, $key12_9);
		$jumlah_key12_10 = substr_count($source_code, $key12_10);
		$jumlah_key12_11 = substr_count($source_code, $key12_11);
		$jumlah_key12_12 = substr_count($source_code, $key12_12);
		$jumlah_key12_13 = substr_count($source_code, $key12_13);
		$jumlah_key12_14 = substr_count($source_code, $key12_14);
		$jumlah_key12_15 = substr_count($source_code, $key12_15);
	    }	
		
if($jumlah_key12_1 > 0){$jumlah_key12_1hasil = 1 ; }else{$jumlah_key12_1hasil = 0 ;}		
if($jumlah_key12_2 > 0){$jumlah_key12_2hasil = 1 ; }else{$jumlah_key12_2hasil = 0 ;}		
if($jumlah_key12_3 > 0){$jumlah_key12_3hasil = 1 ; }else{$jumlah_key12_3hasil = 0 ;}		
if($jumlah_key12_4 > 0){$jumlah_key12_4hasil = 1 ; }else{$jumlah_key12_4hasil = 0 ;}		
if($jumlah_key12_5 > 0){$jumlah_key12_5hasil = 1 ; }else{$jumlah_key12_5hasil = 0 ;}		
if($jumlah_key12_6 > 0){$jumlah_key12_6hasil = 1 ; }else{$jumlah_key12_6hasil = 0 ;}		
if($jumlah_key12_7 > 0){$jumlah_key12_7hasil = 1 ; }else{$jumlah_key12_7hasil = 0 ;}		
if($jumlah_key12_8 > 0){$jumlah_key12_8hasil = 1 ; }else{$jumlah_key12_8hasil = 0 ;}		
if($jumlah_key12_9 > 0){$jumlah_key12_9hasil = 1 ; }else{$jumlah_key12_9hasil = 0 ;}		
if($jumlah_key12_10 > 0){$jumlah_key12_10hasil = 1 ; }else{$jumlah_key12_10hasil = 0 ;}		
if($jumlah_key12_11 > 0){$jumlah_key12_11hasil = 1 ; }else{$jumlah_key12_11hasil = 0 ;}		
if($jumlah_key12_12 > 0){$jumlah_key12_12hasil = 1 ; }else{$jumlah_key12_12hasil = 0 ;}		
if($jumlah_key12_13 > 0){$jumlah_key12_13hasil = 1 ; }else{$jumlah_key12_13hasil = 0 ;}		
if($jumlah_key12_14 > 0){$jumlah_key12_14hasil = 1 ; }else{$jumlah_key12_14hasil = 0 ;}		
if($jumlah_key12_15 > 0){$jumlah_key12_15hasil = 1 ; }else{$jumlah_key12_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '12', '$key12_1hasil', '$jumlah_key12_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_2hasil', '$jumlah_key12_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_3hasil', '$jumlah_key12_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_4hasil', '$jumlah_key12_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_5hasil', '$jumlah_key12_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_6hasil', '$jumlah_key12_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_7hasil', '$jumlah_key12_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_8hasil', '$jumlah_key12_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_9hasil', '$jumlah_key12_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_10hasil', '$jumlah_key12_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_11hasil', '$jumlah_key12_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_12hasil', '$jumlah_key12_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_13hasil', '$jumlah_key12_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_14hasil', '$jumlah_key12_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '12', '$key12_15hasil', '$jumlah_key12_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data13= mysqli_query($connect,"select * from tb_indikator where id_indikator='13'");		
	while($result13 = mysqli_fetch_array($data13)){	
	$indikator13 = $result13['indikator'];	
	$indikator_kecil13 = strtolower($indikator13);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator13 = str_replace($filter, '', $indikator_kecil13);	
	list($key13_1, $key13_2, $key13_3, $key13_4, $key13_5, $key13_6, $key13_7, $key13_8, $key13_9, $key13_10, $key13_11, $key13_12, $key13_13, $key13_14, $key13_15) = explode(' ', $filter_indikator13);	
		$jumlah_key13_1 = substr_count($source_code, $key13_1);
		$jumlah_key13_2 = substr_count($source_code, $key13_2);
		$jumlah_key13_3 = substr_count($source_code, $key13_3);
		$jumlah_key13_4 = substr_count($source_code, $key13_4);
		$jumlah_key13_5 = substr_count($source_code, $key13_5);
		$jumlah_key13_6 = substr_count($source_code, $key13_6);
		$jumlah_key13_7 = substr_count($source_code, $key13_7);
		$jumlah_key13_8 = substr_count($source_code, $key13_8);
		$jumlah_key13_9 = substr_count($source_code, $key13_9);
		$jumlah_key13_10 = substr_count($source_code, $key13_10);
		$jumlah_key13_11 = substr_count($source_code, $key13_11);
		$jumlah_key13_12 = substr_count($source_code, $key13_12);
		$jumlah_key13_13 = substr_count($source_code, $key13_13);
		$jumlah_key13_14 = substr_count($source_code, $key13_14);
		$jumlah_key13_15 = substr_count($source_code, $key13_15);
	    }	
		
if($jumlah_key13_1 > 0){$jumlah_key13_1hasil = 1 ; }else{$jumlah_key13_1hasil = 0 ;}		
if($jumlah_key13_2 > 0){$jumlah_key13_2hasil = 1 ; }else{$jumlah_key13_2hasil = 0 ;}		
if($jumlah_key13_3 > 0){$jumlah_key13_3hasil = 1 ; }else{$jumlah_key13_3hasil = 0 ;}		
if($jumlah_key13_4 > 0){$jumlah_key13_4hasil = 1 ; }else{$jumlah_key13_4hasil = 0 ;}		
if($jumlah_key13_5 > 0){$jumlah_key13_5hasil = 1 ; }else{$jumlah_key13_5hasil = 0 ;}		
if($jumlah_key13_6 > 0){$jumlah_key13_6hasil = 1 ; }else{$jumlah_key13_6hasil = 0 ;}		
if($jumlah_key13_7 > 0){$jumlah_key13_7hasil = 1 ; }else{$jumlah_key13_7hasil = 0 ;}		
if($jumlah_key13_8 > 0){$jumlah_key13_8hasil = 1 ; }else{$jumlah_key13_8hasil = 0 ;}		
if($jumlah_key13_9 > 0){$jumlah_key13_9hasil = 1 ; }else{$jumlah_key13_9hasil = 0 ;}		
if($jumlah_key13_10 > 0){$jumlah_key13_10hasil = 1 ; }else{$jumlah_key13_10hasil = 0 ;}		
if($jumlah_key13_11 > 0){$jumlah_key13_11hasil = 1 ; }else{$jumlah_key13_11hasil = 0 ;}		
if($jumlah_key13_12 > 0){$jumlah_key13_12hasil = 1 ; }else{$jumlah_key13_12hasil = 0 ;}		
if($jumlah_key13_13 > 0){$jumlah_key13_13hasil = 1 ; }else{$jumlah_key13_13hasil = 0 ;}		
if($jumlah_key13_14 > 0){$jumlah_key13_14hasil = 1 ; }else{$jumlah_key13_14hasil = 0 ;}		
if($jumlah_key13_15 > 0){$jumlah_key13_15hasil = 1 ; }else{$jumlah_key13_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '13', '$key13_1hasil', '$jumlah_key13_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_2hasil', '$jumlah_key13_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_3hasil', '$jumlah_key13_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_4hasil', '$jumlah_key13_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_5hasil', '$jumlah_key13_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_6hasil', '$jumlah_key13_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_7hasil', '$jumlah_key13_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_8hasil', '$jumlah_key13_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_9hasil', '$jumlah_key13_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_10hasil', '$jumlah_key13_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_11hasil', '$jumlah_key13_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_12hasil', '$jumlah_key13_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_13hasil', '$jumlah_key13_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_14hasil', '$jumlah_key13_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '13', '$key13_15hasil', '$jumlah_key13_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data14= mysqli_query($connect,"select * from tb_indikator where id_indikator='14'");		
	while($result14 = mysqli_fetch_array($data14)){	
	$indikator14 = $result14['indikator'];	
	$indikator_kecil14 = strtolower($indikator14);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator14 = str_replace($filter, '', $indikator_kecil14);	
	list($key14_1, $key14_2, $key14_3, $key14_4, $key14_5, $key14_6, $key14_7, $key14_8, $key14_9, $key14_10, $key14_11, $key14_12, $key14_13, $key14_14, $key14_15) = explode(' ', $filter_indikator14);	
		$jumlah_key14_1 = substr_count($source_code, $key14_1);
		$jumlah_key14_2 = substr_count($source_code, $key14_2);
		$jumlah_key14_3 = substr_count($source_code, $key14_3);
		$jumlah_key14_4 = substr_count($source_code, $key14_4);
		$jumlah_key14_5 = substr_count($source_code, $key14_5);
		$jumlah_key14_6 = substr_count($source_code, $key14_6);
		$jumlah_key14_7 = substr_count($source_code, $key14_7);
		$jumlah_key14_8 = substr_count($source_code, $key14_8);
		$jumlah_key14_9 = substr_count($source_code, $key14_9);
		$jumlah_key14_10 = substr_count($source_code, $key14_10);
		$jumlah_key14_11 = substr_count($source_code, $key14_11);
		$jumlah_key14_12 = substr_count($source_code, $key14_12);
		$jumlah_key14_13 = substr_count($source_code, $key14_13);
		$jumlah_key14_14 = substr_count($source_code, $key14_14);
		$jumlah_key14_15 = substr_count($source_code, $key14_15);
	    }	
		
if($jumlah_key14_1 > 0){$jumlah_key14_1hasil = 1 ; }else{$jumlah_key14_1hasil = 0 ;}		
if($jumlah_key14_2 > 0){$jumlah_key14_2hasil = 1 ; }else{$jumlah_key14_2hasil = 0 ;}		
if($jumlah_key14_3 > 0){$jumlah_key14_3hasil = 1 ; }else{$jumlah_key14_3hasil = 0 ;}		
if($jumlah_key14_4 > 0){$jumlah_key14_4hasil = 1 ; }else{$jumlah_key14_4hasil = 0 ;}		
if($jumlah_key14_5 > 0){$jumlah_key14_5hasil = 1 ; }else{$jumlah_key14_5hasil = 0 ;}		
if($jumlah_key14_6 > 0){$jumlah_key14_6hasil = 1 ; }else{$jumlah_key14_6hasil = 0 ;}		
if($jumlah_key14_7 > 0){$jumlah_key14_7hasil = 1 ; }else{$jumlah_key14_7hasil = 0 ;}		
if($jumlah_key14_8 > 0){$jumlah_key14_8hasil = 1 ; }else{$jumlah_key14_8hasil = 0 ;}		
if($jumlah_key14_9 > 0){$jumlah_key14_9hasil = 1 ; }else{$jumlah_key14_9hasil = 0 ;}		
if($jumlah_key14_10 > 0){$jumlah_key14_10hasil = 1 ; }else{$jumlah_key14_10hasil = 0 ;}		
if($jumlah_key14_11 > 0){$jumlah_key14_11hasil = 1 ; }else{$jumlah_key14_11hasil = 0 ;}		
if($jumlah_key14_12 > 0){$jumlah_key14_12hasil = 1 ; }else{$jumlah_key14_12hasil = 0 ;}		
if($jumlah_key14_13 > 0){$jumlah_key14_13hasil = 1 ; }else{$jumlah_key14_13hasil = 0 ;}		
if($jumlah_key14_14 > 0){$jumlah_key14_14hasil = 1 ; }else{$jumlah_key14_14hasil = 0 ;}		
if($jumlah_key14_15 > 0){$jumlah_key14_15hasil = 1 ; }else{$jumlah_key14_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '14', '$key14_1hasil', '$jumlah_key14_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_2hasil', '$jumlah_key14_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_3hasil', '$jumlah_key14_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_4hasil', '$jumlah_key14_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_5hasil', '$jumlah_key14_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_6hasil', '$jumlah_key14_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_7hasil', '$jumlah_key14_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_8hasil', '$jumlah_key14_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_9hasil', '$jumlah_key14_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_10hasil', '$jumlah_key14_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_11hasil', '$jumlah_key14_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_12hasil', '$jumlah_key14_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_13hasil', '$jumlah_key14_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_14hasil', '$jumlah_key14_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '14', '$key14_15hasil', '$jumlah_key14_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data15= mysqli_query($connect,"select * from tb_indikator where id_indikator='15'");		
	while($result15 = mysqli_fetch_array($data15)){	
	$indikator15 = $result15['indikator'];	
	$indikator_kecil15 = strtolower($indikator15);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator15 = str_replace($filter, '', $indikator_kecil15);	
	list($key15_1, $key15_2, $key15_3, $key15_4, $key15_5, $key15_6, $key15_7, $key15_8, $key15_9, $key15_10, $key15_11, $key15_12, $key15_13, $key15_14, $key15_15) = explode(' ', $filter_indikator15);	
		$jumlah_key15_1 = substr_count($source_code, $key15_1);
		$jumlah_key15_2 = substr_count($source_code, $key15_2);
		$jumlah_key15_3 = substr_count($source_code, $key15_3);
		$jumlah_key15_4 = substr_count($source_code, $key15_4);
		$jumlah_key15_5 = substr_count($source_code, $key15_5);
		$jumlah_key15_6 = substr_count($source_code, $key15_6);
		$jumlah_key15_7 = substr_count($source_code, $key15_7);
		$jumlah_key15_8 = substr_count($source_code, $key15_8);
		$jumlah_key15_9 = substr_count($source_code, $key15_9);
		$jumlah_key15_10 = substr_count($source_code, $key15_10);
		$jumlah_key15_11 = substr_count($source_code, $key15_11);
		$jumlah_key15_12 = substr_count($source_code, $key15_12);
		$jumlah_key15_13 = substr_count($source_code, $key15_13);
		$jumlah_key15_14 = substr_count($source_code, $key15_14);
		$jumlah_key15_15 = substr_count($source_code, $key15_15);
	    }	
		
if($jumlah_key15_1 > 0){$jumlah_key15_1hasil = 1 ; }else{$jumlah_key15_1hasil = 0 ;}		
if($jumlah_key15_2 > 0){$jumlah_key15_2hasil = 1 ; }else{$jumlah_key15_2hasil = 0 ;}		
if($jumlah_key15_3 > 0){$jumlah_key15_3hasil = 1 ; }else{$jumlah_key15_3hasil = 0 ;}		
if($jumlah_key15_4 > 0){$jumlah_key15_4hasil = 1 ; }else{$jumlah_key15_4hasil = 0 ;}		
if($jumlah_key15_5 > 0){$jumlah_key15_5hasil = 1 ; }else{$jumlah_key15_5hasil = 0 ;}		
if($jumlah_key15_6 > 0){$jumlah_key15_6hasil = 1 ; }else{$jumlah_key15_6hasil = 0 ;}		
if($jumlah_key15_7 > 0){$jumlah_key15_7hasil = 1 ; }else{$jumlah_key15_7hasil = 0 ;}		
if($jumlah_key15_8 > 0){$jumlah_key15_8hasil = 1 ; }else{$jumlah_key15_8hasil = 0 ;}		
if($jumlah_key15_9 > 0){$jumlah_key15_9hasil = 1 ; }else{$jumlah_key15_9hasil = 0 ;}		
if($jumlah_key15_10 > 0){$jumlah_key15_10hasil = 1 ; }else{$jumlah_key15_10hasil = 0 ;}		
if($jumlah_key15_11 > 0){$jumlah_key15_11hasil = 1 ; }else{$jumlah_key15_11hasil = 0 ;}		
if($jumlah_key15_12 > 0){$jumlah_key15_12hasil = 1 ; }else{$jumlah_key15_12hasil = 0 ;}		
if($jumlah_key15_13 > 0){$jumlah_key15_13hasil = 1 ; }else{$jumlah_key15_13hasil = 0 ;}		
if($jumlah_key15_14 > 0){$jumlah_key15_14hasil = 1 ; }else{$jumlah_key15_14hasil = 0 ;}		
if($jumlah_key15_15 > 0){$jumlah_key15_15hasil = 1 ; }else{$jumlah_key15_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '15', '$key15_1hasil', '$jumlah_key15_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_2hasil', '$jumlah_key15_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_3hasil', '$jumlah_key15_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_4hasil', '$jumlah_key15_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_5hasil', '$jumlah_key15_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_6hasil', '$jumlah_key15_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_7hasil', '$jumlah_key15_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_8hasil', '$jumlah_key15_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_9hasil', '$jumlah_key15_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_10hasil', '$jumlah_key15_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_11hasil', '$jumlah_key15_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_12hasil', '$jumlah_key15_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_13hasil', '$jumlah_key15_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_14hasil', '$jumlah_key15_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '15', '$key15_15hasil', '$jumlah_key15_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data16= mysqli_query($connect,"select * from tb_indikator where id_indikator='16'");		
	while($result16 = mysqli_fetch_array($data16)){	
	$indikator16 = $result16['indikator'];	
	$indikator_kecil16 = strtolower($indikator16);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator16 = str_replace($filter, '', $indikator_kecil16);	
	list($key16_1, $key16_2, $key16_3, $key16_4, $key16_5, $key16_6, $key16_7, $key16_8, $key16_9, $key16_10, $key16_11, $key16_12, $key16_13, $key16_14, $key16_15) = explode(' ', $filter_indikator16);	
		$jumlah_key16_1 = substr_count($source_code, $key16_1);
		$jumlah_key16_2 = substr_count($source_code, $key16_2);
		$jumlah_key16_3 = substr_count($source_code, $key16_3);
		$jumlah_key16_4 = substr_count($source_code, $key16_4);
		$jumlah_key16_5 = substr_count($source_code, $key16_5);
		$jumlah_key16_6 = substr_count($source_code, $key16_6);
		$jumlah_key16_7 = substr_count($source_code, $key16_7);
		$jumlah_key16_8 = substr_count($source_code, $key16_8);
		$jumlah_key16_9 = substr_count($source_code, $key16_9);
		$jumlah_key16_10 = substr_count($source_code, $key16_10);
		$jumlah_key16_11 = substr_count($source_code, $key16_11);
		$jumlah_key16_12 = substr_count($source_code, $key16_12);
		$jumlah_key16_13 = substr_count($source_code, $key16_13);
		$jumlah_key16_14 = substr_count($source_code, $key16_14);
		$jumlah_key16_15 = substr_count($source_code, $key16_15);
	    }	
		
if($jumlah_key16_1 > 0){$jumlah_key16_1hasil = 1 ; }else{$jumlah_key16_1hasil = 0 ;}		
if($jumlah_key16_2 > 0){$jumlah_key16_2hasil = 1 ; }else{$jumlah_key16_2hasil = 0 ;}		
if($jumlah_key16_3 > 0){$jumlah_key16_3hasil = 1 ; }else{$jumlah_key16_3hasil = 0 ;}		
if($jumlah_key16_4 > 0){$jumlah_key16_4hasil = 1 ; }else{$jumlah_key16_4hasil = 0 ;}		
if($jumlah_key16_5 > 0){$jumlah_key16_5hasil = 1 ; }else{$jumlah_key16_5hasil = 0 ;}		
if($jumlah_key16_6 > 0){$jumlah_key16_6hasil = 1 ; }else{$jumlah_key16_6hasil = 0 ;}		
if($jumlah_key16_7 > 0){$jumlah_key16_7hasil = 1 ; }else{$jumlah_key16_7hasil = 0 ;}		
if($jumlah_key16_8 > 0){$jumlah_key16_8hasil = 1 ; }else{$jumlah_key16_8hasil = 0 ;}		
if($jumlah_key16_9 > 0){$jumlah_key16_9hasil = 1 ; }else{$jumlah_key16_9hasil = 0 ;}		
if($jumlah_key16_10 > 0){$jumlah_key16_10hasil = 1 ; }else{$jumlah_key16_10hasil = 0 ;}		
if($jumlah_key16_11 > 0){$jumlah_key16_11hasil = 1 ; }else{$jumlah_key16_11hasil = 0 ;}		
if($jumlah_key16_12 > 0){$jumlah_key16_12hasil = 1 ; }else{$jumlah_key16_12hasil = 0 ;}		
if($jumlah_key16_13 > 0){$jumlah_key16_13hasil = 1 ; }else{$jumlah_key16_13hasil = 0 ;}		
if($jumlah_key16_14 > 0){$jumlah_key16_14hasil = 1 ; }else{$jumlah_key16_14hasil = 0 ;}		
if($jumlah_key16_15 > 0){$jumlah_key16_15hasil = 1 ; }else{$jumlah_key16_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '16', '$key16_1hasil', '$jumlah_key16_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_2hasil', '$jumlah_key16_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_3hasil', '$jumlah_key16_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_4hasil', '$jumlah_key16_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_5hasil', '$jumlah_key16_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_6hasil', '$jumlah_key16_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_7hasil', '$jumlah_key16_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_8hasil', '$jumlah_key16_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_9hasil', '$jumlah_key16_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_10hasil', '$jumlah_key16_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_11hasil', '$jumlah_key16_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_12hasil', '$jumlah_key16_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_13hasil', '$jumlah_key16_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_14hasil', '$jumlah_key16_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '16', '$key16_15hasil', '$jumlah_key16_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data17= mysqli_query($connect,"select * from tb_indikator where id_indikator='17'");		
	while($result17 = mysqli_fetch_array($data17)){	
	$indikator17 = $result17['indikator'];	
	$indikator_kecil17 = strtolower($indikator17);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator17 = str_replace($filter, '', $indikator_kecil17);	
	list($key17_1, $key17_2, $key17_3, $key17_4, $key17_5, $key17_6, $key17_7, $key17_8, $key17_9, $key17_10, $key17_11, $key17_12, $key17_13, $key17_14, $key17_15) = explode(' ', $filter_indikator17);	
		$jumlah_key17_1 = substr_count($source_code, $key17_1);
		$jumlah_key17_2 = substr_count($source_code, $key17_2);
		$jumlah_key17_3 = substr_count($source_code, $key17_3);
		$jumlah_key17_4 = substr_count($source_code, $key17_4);
		$jumlah_key17_5 = substr_count($source_code, $key17_5);
		$jumlah_key17_6 = substr_count($source_code, $key17_6);
		$jumlah_key17_7 = substr_count($source_code, $key17_7);
		$jumlah_key17_8 = substr_count($source_code, $key17_8);
		$jumlah_key17_9 = substr_count($source_code, $key17_9);
		$jumlah_key17_10 = substr_count($source_code, $key17_10);
		$jumlah_key17_11 = substr_count($source_code, $key17_11);
		$jumlah_key17_12 = substr_count($source_code, $key17_12);
		$jumlah_key17_13 = substr_count($source_code, $key17_13);
		$jumlah_key17_14 = substr_count($source_code, $key17_14);
		$jumlah_key17_15 = substr_count($source_code, $key17_15);
	    }	
		
if($jumlah_key17_1 > 0){$jumlah_key17_1hasil = 1 ; }else{$jumlah_key17_1hasil = 0 ;}		
if($jumlah_key17_2 > 0){$jumlah_key17_2hasil = 1 ; }else{$jumlah_key17_2hasil = 0 ;}		
if($jumlah_key17_3 > 0){$jumlah_key17_3hasil = 1 ; }else{$jumlah_key17_3hasil = 0 ;}		
if($jumlah_key17_4 > 0){$jumlah_key17_4hasil = 1 ; }else{$jumlah_key17_4hasil = 0 ;}		
if($jumlah_key17_5 > 0){$jumlah_key17_5hasil = 1 ; }else{$jumlah_key17_5hasil = 0 ;}		
if($jumlah_key17_6 > 0){$jumlah_key17_6hasil = 1 ; }else{$jumlah_key17_6hasil = 0 ;}		
if($jumlah_key17_7 > 0){$jumlah_key17_7hasil = 1 ; }else{$jumlah_key17_7hasil = 0 ;}		
if($jumlah_key17_8 > 0){$jumlah_key17_8hasil = 1 ; }else{$jumlah_key17_8hasil = 0 ;}		
if($jumlah_key17_9 > 0){$jumlah_key17_9hasil = 1 ; }else{$jumlah_key17_9hasil = 0 ;}		
if($jumlah_key17_10 > 0){$jumlah_key17_10hasil = 1 ; }else{$jumlah_key17_10hasil = 0 ;}		
if($jumlah_key17_11 > 0){$jumlah_key17_11hasil = 1 ; }else{$jumlah_key17_11hasil = 0 ;}		
if($jumlah_key17_12 > 0){$jumlah_key17_12hasil = 1 ; }else{$jumlah_key17_12hasil = 0 ;}		
if($jumlah_key17_13 > 0){$jumlah_key17_13hasil = 1 ; }else{$jumlah_key17_13hasil = 0 ;}		
if($jumlah_key17_14 > 0){$jumlah_key17_14hasil = 1 ; }else{$jumlah_key17_14hasil = 0 ;}		
if($jumlah_key17_15 > 0){$jumlah_key17_15hasil = 1 ; }else{$jumlah_key17_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '17', '$key17_1hasil', '$jumlah_key17_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_2hasil', '$jumlah_key17_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_3hasil', '$jumlah_key17_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_4hasil', '$jumlah_key17_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_5hasil', '$jumlah_key17_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_6hasil', '$jumlah_key17_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_7hasil', '$jumlah_key17_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_8hasil', '$jumlah_key17_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_9hasil', '$jumlah_key17_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_10hasil', '$jumlah_key17_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_11hasil', '$jumlah_key17_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_12hasil', '$jumlah_key17_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_13hasil', '$jumlah_key17_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_14hasil', '$jumlah_key17_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '17', '$key17_15hasil', '$jumlah_key17_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data18= mysqli_query($connect,"select * from tb_indikator where id_indikator='18'");		
	while($result18 = mysqli_fetch_array($data18)){	
	$indikator18 = $result18['indikator'];	
	$indikator_kecil18 = strtolower($indikator18);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator18 = str_replace($filter, '', $indikator_kecil18);	
	list($key18_1, $key18_2, $key18_3, $key18_4, $key18_5, $key18_6, $key18_7, $key18_8, $key18_9, $key18_10, $key18_11, $key18_12, $key18_13, $key18_14, $key18_15) = explode(' ', $filter_indikator18);	
		$jumlah_key18_1 = substr_count($source_code, $key18_1);
		$jumlah_key18_2 = substr_count($source_code, $key18_2);
		$jumlah_key18_3 = substr_count($source_code, $key18_3);
		$jumlah_key18_4 = substr_count($source_code, $key18_4);
		$jumlah_key18_5 = substr_count($source_code, $key18_5);
		$jumlah_key18_6 = substr_count($source_code, $key18_6);
		$jumlah_key18_7 = substr_count($source_code, $key18_7);
		$jumlah_key18_8 = substr_count($source_code, $key18_8);
		$jumlah_key18_9 = substr_count($source_code, $key18_9);
		$jumlah_key18_10 = substr_count($source_code, $key18_10);
		$jumlah_key18_11 = substr_count($source_code, $key18_11);
		$jumlah_key18_12 = substr_count($source_code, $key18_12);
		$jumlah_key18_13 = substr_count($source_code, $key18_13);
		$jumlah_key18_14 = substr_count($source_code, $key18_14);
		$jumlah_key18_15 = substr_count($source_code, $key18_15);
	    }	
		
if($jumlah_key18_1 > 0){$jumlah_key18_1hasil = 1 ; }else{$jumlah_key18_1hasil = 0 ;}		
if($jumlah_key18_2 > 0){$jumlah_key18_2hasil = 1 ; }else{$jumlah_key18_2hasil = 0 ;}		
if($jumlah_key18_3 > 0){$jumlah_key18_3hasil = 1 ; }else{$jumlah_key18_3hasil = 0 ;}		
if($jumlah_key18_4 > 0){$jumlah_key18_4hasil = 1 ; }else{$jumlah_key18_4hasil = 0 ;}		
if($jumlah_key18_5 > 0){$jumlah_key18_5hasil = 1 ; }else{$jumlah_key18_5hasil = 0 ;}		
if($jumlah_key18_6 > 0){$jumlah_key18_6hasil = 1 ; }else{$jumlah_key18_6hasil = 0 ;}		
if($jumlah_key18_7 > 0){$jumlah_key18_7hasil = 1 ; }else{$jumlah_key18_7hasil = 0 ;}		
if($jumlah_key18_8 > 0){$jumlah_key18_8hasil = 1 ; }else{$jumlah_key18_8hasil = 0 ;}		
if($jumlah_key18_9 > 0){$jumlah_key18_9hasil = 1 ; }else{$jumlah_key18_9hasil = 0 ;}		
if($jumlah_key18_10 > 0){$jumlah_key18_10hasil = 1 ; }else{$jumlah_key18_10hasil = 0 ;}		
if($jumlah_key18_11 > 0){$jumlah_key18_11hasil = 1 ; }else{$jumlah_key18_11hasil = 0 ;}		
if($jumlah_key18_12 > 0){$jumlah_key18_12hasil = 1 ; }else{$jumlah_key18_12hasil = 0 ;}		
if($jumlah_key18_13 > 0){$jumlah_key18_13hasil = 1 ; }else{$jumlah_key18_13hasil = 0 ;}		
if($jumlah_key18_14 > 0){$jumlah_key18_14hasil = 1 ; }else{$jumlah_key18_14hasil = 0 ;}		
if($jumlah_key18_15 > 0){$jumlah_key18_15hasil = 1 ; }else{$jumlah_key18_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '18', '$key18_1hasil', '$jumlah_key18_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_2hasil', '$jumlah_key18_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_3hasil', '$jumlah_key18_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_4hasil', '$jumlah_key18_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_5hasil', '$jumlah_key18_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_6hasil', '$jumlah_key18_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_7hasil', '$jumlah_key18_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_8hasil', '$jumlah_key18_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_9hasil', '$jumlah_key18_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_10hasil', '$jumlah_key18_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_11hasil', '$jumlah_key18_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_12hasil', '$jumlah_key18_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_13hasil', '$jumlah_key18_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_14hasil', '$jumlah_key18_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '18', '$key18_15hasil', '$jumlah_key18_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data19= mysqli_query($connect,"select * from tb_indikator where id_indikator='19'");		
	while($result19 = mysqli_fetch_array($data19)){	
	$indikator19 = $result19['indikator'];	
	$indikator_kecil19 = strtolower($indikator19);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator19 = str_replace($filter, '', $indikator_kecil19);	
	list($key19_1, $key19_2, $key19_3, $key19_4, $key19_5, $key19_6, $key19_7, $key19_8, $key19_9, $key19_10, $key19_11, $key19_12, $key19_13, $key19_14, $key19_15) = explode(' ', $filter_indikator19);	
		$jumlah_key19_1 = substr_count($source_code, $key19_1);
		$jumlah_key19_2 = substr_count($source_code, $key19_2);
		$jumlah_key19_3 = substr_count($source_code, $key19_3);
		$jumlah_key19_4 = substr_count($source_code, $key19_4);
		$jumlah_key19_5 = substr_count($source_code, $key19_5);
		$jumlah_key19_6 = substr_count($source_code, $key19_6);
		$jumlah_key19_7 = substr_count($source_code, $key19_7);
		$jumlah_key19_8 = substr_count($source_code, $key19_8);
		$jumlah_key19_9 = substr_count($source_code, $key19_9);
		$jumlah_key19_10 = substr_count($source_code, $key19_10);
		$jumlah_key19_11 = substr_count($source_code, $key19_11);
		$jumlah_key19_12 = substr_count($source_code, $key19_12);
		$jumlah_key19_13 = substr_count($source_code, $key19_13);
		$jumlah_key19_14 = substr_count($source_code, $key19_14);
		$jumlah_key19_15 = substr_count($source_code, $key19_15);
	    }	
		
if($jumlah_key19_1 > 0){$jumlah_key19_1hasil = 1 ; }else{$jumlah_key19_1hasil = 0 ;}		
if($jumlah_key19_2 > 0){$jumlah_key19_2hasil = 1 ; }else{$jumlah_key19_2hasil = 0 ;}		
if($jumlah_key19_3 > 0){$jumlah_key19_3hasil = 1 ; }else{$jumlah_key19_3hasil = 0 ;}		
if($jumlah_key19_4 > 0){$jumlah_key19_4hasil = 1 ; }else{$jumlah_key19_4hasil = 0 ;}		
if($jumlah_key19_5 > 0){$jumlah_key19_5hasil = 1 ; }else{$jumlah_key19_5hasil = 0 ;}		
if($jumlah_key19_6 > 0){$jumlah_key19_6hasil = 1 ; }else{$jumlah_key19_6hasil = 0 ;}		
if($jumlah_key19_7 > 0){$jumlah_key19_7hasil = 1 ; }else{$jumlah_key19_7hasil = 0 ;}		
if($jumlah_key19_8 > 0){$jumlah_key19_8hasil = 1 ; }else{$jumlah_key19_8hasil = 0 ;}		
if($jumlah_key19_9 > 0){$jumlah_key19_9hasil = 1 ; }else{$jumlah_key19_9hasil = 0 ;}		
if($jumlah_key19_10 > 0){$jumlah_key19_10hasil = 1 ; }else{$jumlah_key19_10hasil = 0 ;}		
if($jumlah_key19_11 > 0){$jumlah_key19_11hasil = 1 ; }else{$jumlah_key19_11hasil = 0 ;}		
if($jumlah_key19_12 > 0){$jumlah_key19_12hasil = 1 ; }else{$jumlah_key19_12hasil = 0 ;}		
if($jumlah_key19_13 > 0){$jumlah_key19_13hasil = 1 ; }else{$jumlah_key19_13hasil = 0 ;}		
if($jumlah_key19_14 > 0){$jumlah_key19_14hasil = 1 ; }else{$jumlah_key19_14hasil = 0 ;}		
if($jumlah_key19_15 > 0){$jumlah_key19_15hasil = 1 ; }else{$jumlah_key19_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '19', '$key19_1hasil', '$jumlah_key19_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_2hasil', '$jumlah_key19_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_3hasil', '$jumlah_key19_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_4hasil', '$jumlah_key19_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_5hasil', '$jumlah_key19_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_6hasil', '$jumlah_key19_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_7hasil', '$jumlah_key19_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_8hasil', '$jumlah_key19_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_9hasil', '$jumlah_key19_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_10hasil', '$jumlah_key19_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_11hasil', '$jumlah_key19_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_12hasil', '$jumlah_key19_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_13hasil', '$jumlah_key19_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_14hasil', '$jumlah_key19_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '19', '$key19_15hasil', '$jumlah_key19_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data20= mysqli_query($connect,"select * from tb_indikator where id_indikator='20'");		
	while($result20 = mysqli_fetch_array($data20)){	
	$indikator20 = $result20['indikator'];	
	$indikator_kecil20 = strtolower($indikator20);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator20 = str_replace($filter, '', $indikator_kecil20);	
	list($key20_1, $key20_2, $key20_3, $key20_4, $key20_5, $key20_6, $key20_7, $key20_8, $key20_9, $key20_10, $key20_11, $key20_12, $key20_13, $key20_14, $key20_15) = explode(' ', $filter_indikator20);	
		$jumlah_key20_1 = substr_count($source_code, $key20_1);
		$jumlah_key20_2 = substr_count($source_code, $key20_2);
		$jumlah_key20_3 = substr_count($source_code, $key20_3);
		$jumlah_key20_4 = substr_count($source_code, $key20_4);
		$jumlah_key20_5 = substr_count($source_code, $key20_5);
		$jumlah_key20_6 = substr_count($source_code, $key20_6);
		$jumlah_key20_7 = substr_count($source_code, $key20_7);
		$jumlah_key20_8 = substr_count($source_code, $key20_8);
		$jumlah_key20_9 = substr_count($source_code, $key20_9);
		$jumlah_key20_10 = substr_count($source_code, $key20_10);
		$jumlah_key20_11 = substr_count($source_code, $key20_11);
		$jumlah_key20_12 = substr_count($source_code, $key20_12);
		$jumlah_key20_13 = substr_count($source_code, $key20_13);
		$jumlah_key20_14 = substr_count($source_code, $key20_14);
		$jumlah_key20_15 = substr_count($source_code, $key20_15);
	    }	
		
if($jumlah_key20_1 > 0){$jumlah_key20_1hasil = 1 ; }else{$jumlah_key20_1hasil = 0 ;}		
if($jumlah_key20_2 > 0){$jumlah_key20_2hasil = 1 ; }else{$jumlah_key20_2hasil = 0 ;}		
if($jumlah_key20_3 > 0){$jumlah_key20_3hasil = 1 ; }else{$jumlah_key20_3hasil = 0 ;}		
if($jumlah_key20_4 > 0){$jumlah_key20_4hasil = 1 ; }else{$jumlah_key20_4hasil = 0 ;}		
if($jumlah_key20_5 > 0){$jumlah_key20_5hasil = 1 ; }else{$jumlah_key20_5hasil = 0 ;}		
if($jumlah_key20_6 > 0){$jumlah_key20_6hasil = 1 ; }else{$jumlah_key20_6hasil = 0 ;}		
if($jumlah_key20_7 > 0){$jumlah_key20_7hasil = 1 ; }else{$jumlah_key20_7hasil = 0 ;}		
if($jumlah_key20_8 > 0){$jumlah_key20_8hasil = 1 ; }else{$jumlah_key20_8hasil = 0 ;}		
if($jumlah_key20_9 > 0){$jumlah_key20_9hasil = 1 ; }else{$jumlah_key20_9hasil = 0 ;}		
if($jumlah_key20_10 > 0){$jumlah_key20_10hasil = 1 ; }else{$jumlah_key20_10hasil = 0 ;}		
if($jumlah_key20_11 > 0){$jumlah_key20_11hasil = 1 ; }else{$jumlah_key20_11hasil = 0 ;}		
if($jumlah_key20_12 > 0){$jumlah_key20_12hasil = 1 ; }else{$jumlah_key20_12hasil = 0 ;}		
if($jumlah_key20_13 > 0){$jumlah_key20_13hasil = 1 ; }else{$jumlah_key20_13hasil = 0 ;}		
if($jumlah_key20_14 > 0){$jumlah_key20_14hasil = 1 ; }else{$jumlah_key20_14hasil = 0 ;}		
if($jumlah_key20_15 > 0){$jumlah_key20_15hasil = 1 ; }else{$jumlah_key20_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '20', '$key20_1hasil', '$jumlah_key20_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_2hasil', '$jumlah_key20_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_3hasil', '$jumlah_key20_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_4hasil', '$jumlah_key20_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_5hasil', '$jumlah_key20_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_6hasil', '$jumlah_key20_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_7hasil', '$jumlah_key20_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_8hasil', '$jumlah_key20_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_9hasil', '$jumlah_key20_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_10hasil', '$jumlah_key20_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_11hasil', '$jumlah_key20_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_12hasil', '$jumlah_key20_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_13hasil', '$jumlah_key20_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_14hasil', '$jumlah_key20_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '20', '$key20_15hasil', '$jumlah_key20_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data21= mysqli_query($connect,"select * from tb_indikator where id_indikator='21'");		
	while($result21 = mysqli_fetch_array($data21)){	
	$indikator21 = $result21['indikator'];	
	$indikator_kecil21 = strtolower($indikator21);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator21 = str_replace($filter, '', $indikator_kecil21);	
	list($key21_1, $key21_2, $key21_3, $key21_4, $key21_5, $key21_6, $key21_7, $key21_8, $key21_9, $key21_10, $key21_11, $key21_12, $key21_13, $key21_14, $key21_15) = explode(' ', $filter_indikator21);	
		$jumlah_key21_1 = substr_count($source_code, $key21_1);
		$jumlah_key21_2 = substr_count($source_code, $key21_2);
		$jumlah_key21_3 = substr_count($source_code, $key21_3);
		$jumlah_key21_4 = substr_count($source_code, $key21_4);
		$jumlah_key21_5 = substr_count($source_code, $key21_5);
		$jumlah_key21_6 = substr_count($source_code, $key21_6);
		$jumlah_key21_7 = substr_count($source_code, $key21_7);
		$jumlah_key21_8 = substr_count($source_code, $key21_8);
		$jumlah_key21_9 = substr_count($source_code, $key21_9);
		$jumlah_key21_10 = substr_count($source_code, $key21_10);
		$jumlah_key21_11 = substr_count($source_code, $key21_11);
		$jumlah_key21_12 = substr_count($source_code, $key21_12);
		$jumlah_key21_13 = substr_count($source_code, $key21_13);
		$jumlah_key21_14 = substr_count($source_code, $key21_14);
		$jumlah_key21_15 = substr_count($source_code, $key21_15);
	    }	
		
if($jumlah_key21_1 > 0){$jumlah_key21_1hasil = 1 ; }else{$jumlah_key21_1hasil = 0 ;}		
if($jumlah_key21_2 > 0){$jumlah_key21_2hasil = 1 ; }else{$jumlah_key21_2hasil = 0 ;}		
if($jumlah_key21_3 > 0){$jumlah_key21_3hasil = 1 ; }else{$jumlah_key21_3hasil = 0 ;}		
if($jumlah_key21_4 > 0){$jumlah_key21_4hasil = 1 ; }else{$jumlah_key21_4hasil = 0 ;}		
if($jumlah_key21_5 > 0){$jumlah_key21_5hasil = 1 ; }else{$jumlah_key21_5hasil = 0 ;}		
if($jumlah_key21_6 > 0){$jumlah_key21_6hasil = 1 ; }else{$jumlah_key21_6hasil = 0 ;}		
if($jumlah_key21_7 > 0){$jumlah_key21_7hasil = 1 ; }else{$jumlah_key21_7hasil = 0 ;}		
if($jumlah_key21_8 > 0){$jumlah_key21_8hasil = 1 ; }else{$jumlah_key21_8hasil = 0 ;}		
if($jumlah_key21_9 > 0){$jumlah_key21_9hasil = 1 ; }else{$jumlah_key21_9hasil = 0 ;}		
if($jumlah_key21_10 > 0){$jumlah_key21_10hasil = 1 ; }else{$jumlah_key21_10hasil = 0 ;}		
if($jumlah_key21_11 > 0){$jumlah_key21_11hasil = 1 ; }else{$jumlah_key21_11hasil = 0 ;}		
if($jumlah_key21_12 > 0){$jumlah_key21_12hasil = 1 ; }else{$jumlah_key21_12hasil = 0 ;}		
if($jumlah_key21_13 > 0){$jumlah_key21_13hasil = 1 ; }else{$jumlah_key21_13hasil = 0 ;}		
if($jumlah_key21_14 > 0){$jumlah_key21_14hasil = 1 ; }else{$jumlah_key21_14hasil = 0 ;}		
if($jumlah_key21_15 > 0){$jumlah_key21_15hasil = 1 ; }else{$jumlah_key21_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '21', '$key21_1hasil', '$jumlah_key21_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_2hasil', '$jumlah_key21_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_3hasil', '$jumlah_key21_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_4hasil', '$jumlah_key21_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_5hasil', '$jumlah_key21_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_6hasil', '$jumlah_key21_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_7hasil', '$jumlah_key21_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_8hasil', '$jumlah_key21_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_9hasil', '$jumlah_key21_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_10hasil', '$jumlah_key21_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_11hasil', '$jumlah_key21_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_12hasil', '$jumlah_key21_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_13hasil', '$jumlah_key21_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_14hasil', '$jumlah_key21_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '21', '$key21_15hasil', '$jumlah_key21_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data22= mysqli_query($connect,"select * from tb_indikator where id_indikator='22'");		
	while($result22 = mysqli_fetch_array($data22)){	
	$indikator22 = $result22['indikator'];	
	$indikator_kecil22 = strtolower($indikator22);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator22 = str_replace($filter, '', $indikator_kecil22);	
	list($key22_1, $key22_2, $key22_3, $key22_4, $key22_5, $key22_6, $key22_7, $key22_8, $key22_9, $key22_10, $key22_11, $key22_12, $key22_13, $key22_14, $key22_15) = explode(' ', $filter_indikator22);	
		$jumlah_key22_1 = substr_count($source_code, $key22_1);
		$jumlah_key22_2 = substr_count($source_code, $key22_2);
		$jumlah_key22_3 = substr_count($source_code, $key22_3);
		$jumlah_key22_4 = substr_count($source_code, $key22_4);
		$jumlah_key22_5 = substr_count($source_code, $key22_5);
		$jumlah_key22_6 = substr_count($source_code, $key22_6);
		$jumlah_key22_7 = substr_count($source_code, $key22_7);
		$jumlah_key22_8 = substr_count($source_code, $key22_8);
		$jumlah_key22_9 = substr_count($source_code, $key22_9);
		$jumlah_key22_10 = substr_count($source_code, $key22_10);
		$jumlah_key22_11 = substr_count($source_code, $key22_11);
		$jumlah_key22_12 = substr_count($source_code, $key22_12);
		$jumlah_key22_13 = substr_count($source_code, $key22_13);
		$jumlah_key22_14 = substr_count($source_code, $key22_14);
		$jumlah_key22_15 = substr_count($source_code, $key22_15);
	    }	
		
if($jumlah_key22_1 > 0){$jumlah_key22_1hasil = 1 ; }else{$jumlah_key22_1hasil = 0 ;}		
if($jumlah_key22_2 > 0){$jumlah_key22_2hasil = 1 ; }else{$jumlah_key22_2hasil = 0 ;}		
if($jumlah_key22_3 > 0){$jumlah_key22_3hasil = 1 ; }else{$jumlah_key22_3hasil = 0 ;}		
if($jumlah_key22_4 > 0){$jumlah_key22_4hasil = 1 ; }else{$jumlah_key22_4hasil = 0 ;}		
if($jumlah_key22_5 > 0){$jumlah_key22_5hasil = 1 ; }else{$jumlah_key22_5hasil = 0 ;}		
if($jumlah_key22_6 > 0){$jumlah_key22_6hasil = 1 ; }else{$jumlah_key22_6hasil = 0 ;}		
if($jumlah_key22_7 > 0){$jumlah_key22_7hasil = 1 ; }else{$jumlah_key22_7hasil = 0 ;}		
if($jumlah_key22_8 > 0){$jumlah_key22_8hasil = 1 ; }else{$jumlah_key22_8hasil = 0 ;}		
if($jumlah_key22_9 > 0){$jumlah_key22_9hasil = 1 ; }else{$jumlah_key22_9hasil = 0 ;}		
if($jumlah_key22_10 > 0){$jumlah_key22_10hasil = 1 ; }else{$jumlah_key22_10hasil = 0 ;}		
if($jumlah_key22_11 > 0){$jumlah_key22_11hasil = 1 ; }else{$jumlah_key22_11hasil = 0 ;}		
if($jumlah_key22_12 > 0){$jumlah_key22_12hasil = 1 ; }else{$jumlah_key22_12hasil = 0 ;}		
if($jumlah_key22_13 > 0){$jumlah_key22_13hasil = 1 ; }else{$jumlah_key22_13hasil = 0 ;}		
if($jumlah_key22_14 > 0){$jumlah_key22_14hasil = 1 ; }else{$jumlah_key22_14hasil = 0 ;}		
if($jumlah_key22_15 > 0){$jumlah_key22_15hasil = 1 ; }else{$jumlah_key22_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '22', '$key22_1hasil', '$jumlah_key22_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_2hasil', '$jumlah_key22_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_3hasil', '$jumlah_key22_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_4hasil', '$jumlah_key22_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_5hasil', '$jumlah_key22_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_6hasil', '$jumlah_key22_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_7hasil', '$jumlah_key22_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_8hasil', '$jumlah_key22_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_9hasil', '$jumlah_key22_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_10hasil', '$jumlah_key22_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_11hasil', '$jumlah_key22_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_12hasil', '$jumlah_key22_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_13hasil', '$jumlah_key22_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_14hasil', '$jumlah_key22_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '22', '$key22_15hasil', '$jumlah_key22_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data23= mysqli_query($connect,"select * from tb_indikator where id_indikator='23'");		
	while($result23 = mysqli_fetch_array($data23)){	
	$indikator23 = $result23['indikator'];	
	$indikator_kecil23 = strtolower($indikator23);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator23 = str_replace($filter, '', $indikator_kecil23);	
	list($key23_1, $key23_2, $key23_3, $key23_4, $key23_5, $key23_6, $key23_7, $key23_8, $key23_9, $key23_10, $key23_11, $key23_12, $key23_13, $key23_14, $key23_15) = explode(' ', $filter_indikator23);	
		$jumlah_key23_1 = substr_count($source_code, $key23_1);
		$jumlah_key23_2 = substr_count($source_code, $key23_2);
		$jumlah_key23_3 = substr_count($source_code, $key23_3);
		$jumlah_key23_4 = substr_count($source_code, $key23_4);
		$jumlah_key23_5 = substr_count($source_code, $key23_5);
		$jumlah_key23_6 = substr_count($source_code, $key23_6);
		$jumlah_key23_7 = substr_count($source_code, $key23_7);
		$jumlah_key23_8 = substr_count($source_code, $key23_8);
		$jumlah_key23_9 = substr_count($source_code, $key23_9);
		$jumlah_key23_10 = substr_count($source_code, $key23_10);
		$jumlah_key23_11 = substr_count($source_code, $key23_11);
		$jumlah_key23_12 = substr_count($source_code, $key23_12);
		$jumlah_key23_13 = substr_count($source_code, $key23_13);
		$jumlah_key23_14 = substr_count($source_code, $key23_14);
		$jumlah_key23_15 = substr_count($source_code, $key23_15);
	    }	
		
if($jumlah_key23_1 > 0){$jumlah_key23_1hasil = 1 ; }else{$jumlah_key23_1hasil = 0 ;}		
if($jumlah_key23_2 > 0){$jumlah_key23_2hasil = 1 ; }else{$jumlah_key23_2hasil = 0 ;}		
if($jumlah_key23_3 > 0){$jumlah_key23_3hasil = 1 ; }else{$jumlah_key23_3hasil = 0 ;}		
if($jumlah_key23_4 > 0){$jumlah_key23_4hasil = 1 ; }else{$jumlah_key23_4hasil = 0 ;}		
if($jumlah_key23_5 > 0){$jumlah_key23_5hasil = 1 ; }else{$jumlah_key23_5hasil = 0 ;}		
if($jumlah_key23_6 > 0){$jumlah_key23_6hasil = 1 ; }else{$jumlah_key23_6hasil = 0 ;}		
if($jumlah_key23_7 > 0){$jumlah_key23_7hasil = 1 ; }else{$jumlah_key23_7hasil = 0 ;}		
if($jumlah_key23_8 > 0){$jumlah_key23_8hasil = 1 ; }else{$jumlah_key23_8hasil = 0 ;}		
if($jumlah_key23_9 > 0){$jumlah_key23_9hasil = 1 ; }else{$jumlah_key23_9hasil = 0 ;}		
if($jumlah_key23_10 > 0){$jumlah_key23_10hasil = 1 ; }else{$jumlah_key23_10hasil = 0 ;}		
if($jumlah_key23_11 > 0){$jumlah_key23_11hasil = 1 ; }else{$jumlah_key23_11hasil = 0 ;}		
if($jumlah_key23_12 > 0){$jumlah_key23_12hasil = 1 ; }else{$jumlah_key23_12hasil = 0 ;}		
if($jumlah_key23_13 > 0){$jumlah_key23_13hasil = 1 ; }else{$jumlah_key23_13hasil = 0 ;}		
if($jumlah_key23_14 > 0){$jumlah_key23_14hasil = 1 ; }else{$jumlah_key23_14hasil = 0 ;}		
if($jumlah_key23_15 > 0){$jumlah_key23_15hasil = 1 ; }else{$jumlah_key23_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '23', '$key23_1hasil', '$jumlah_key23_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_2hasil', '$jumlah_key23_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_3hasil', '$jumlah_key23_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_4hasil', '$jumlah_key23_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_5hasil', '$jumlah_key23_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_6hasil', '$jumlah_key23_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_7hasil', '$jumlah_key23_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_8hasil', '$jumlah_key23_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_9hasil', '$jumlah_key23_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_10hasil', '$jumlah_key23_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_11hasil', '$jumlah_key23_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_12hasil', '$jumlah_key23_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_13hasil', '$jumlah_key23_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_14hasil', '$jumlah_key23_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '23', '$key23_15hasil', '$jumlah_key23_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data24= mysqli_query($connect,"select * from tb_indikator where id_indikator='24'");		
	while($result24 = mysqli_fetch_array($data24)){	
	$indikator24 = $result24['indikator'];	
	$indikator_kecil24 = strtolower($indikator24);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator24 = str_replace($filter, '', $indikator_kecil24);	
	list($key24_1, $key24_2, $key24_3, $key24_4, $key24_5, $key24_6, $key24_7, $key24_8, $key24_9, $key24_10, $key24_11, $key24_12, $key24_13, $key24_14, $key24_15) = explode(' ', $filter_indikator24);	
		$jumlah_key24_1 = substr_count($source_code, $key24_1);
		$jumlah_key24_2 = substr_count($source_code, $key24_2);
		$jumlah_key24_3 = substr_count($source_code, $key24_3);
		$jumlah_key24_4 = substr_count($source_code, $key24_4);
		$jumlah_key24_5 = substr_count($source_code, $key24_5);
		$jumlah_key24_6 = substr_count($source_code, $key24_6);
		$jumlah_key24_7 = substr_count($source_code, $key24_7);
		$jumlah_key24_8 = substr_count($source_code, $key24_8);
		$jumlah_key24_9 = substr_count($source_code, $key24_9);
		$jumlah_key24_10 = substr_count($source_code, $key24_10);
		$jumlah_key24_11 = substr_count($source_code, $key24_11);
		$jumlah_key24_12 = substr_count($source_code, $key24_12);
		$jumlah_key24_13 = substr_count($source_code, $key24_13);
		$jumlah_key24_14 = substr_count($source_code, $key24_14);
		$jumlah_key24_15 = substr_count($source_code, $key24_15);
	    }	
		
if($jumlah_key24_1 > 0){$jumlah_key24_1hasil = 1 ; }else{$jumlah_key24_1hasil = 0 ;}		
if($jumlah_key24_2 > 0){$jumlah_key24_2hasil = 1 ; }else{$jumlah_key24_2hasil = 0 ;}		
if($jumlah_key24_3 > 0){$jumlah_key24_3hasil = 1 ; }else{$jumlah_key24_3hasil = 0 ;}		
if($jumlah_key24_4 > 0){$jumlah_key24_4hasil = 1 ; }else{$jumlah_key24_4hasil = 0 ;}		
if($jumlah_key24_5 > 0){$jumlah_key24_5hasil = 1 ; }else{$jumlah_key24_5hasil = 0 ;}		
if($jumlah_key24_6 > 0){$jumlah_key24_6hasil = 1 ; }else{$jumlah_key24_6hasil = 0 ;}		
if($jumlah_key24_7 > 0){$jumlah_key24_7hasil = 1 ; }else{$jumlah_key24_7hasil = 0 ;}		
if($jumlah_key24_8 > 0){$jumlah_key24_8hasil = 1 ; }else{$jumlah_key24_8hasil = 0 ;}		
if($jumlah_key24_9 > 0){$jumlah_key24_9hasil = 1 ; }else{$jumlah_key24_9hasil = 0 ;}		
if($jumlah_key24_10 > 0){$jumlah_key24_10hasil = 1 ; }else{$jumlah_key24_10hasil = 0 ;}		
if($jumlah_key24_11 > 0){$jumlah_key24_11hasil = 1 ; }else{$jumlah_key24_11hasil = 0 ;}		
if($jumlah_key24_12 > 0){$jumlah_key24_12hasil = 1 ; }else{$jumlah_key24_12hasil = 0 ;}		
if($jumlah_key24_13 > 0){$jumlah_key24_13hasil = 1 ; }else{$jumlah_key24_13hasil = 0 ;}		
if($jumlah_key24_14 > 0){$jumlah_key24_14hasil = 1 ; }else{$jumlah_key24_14hasil = 0 ;}		
if($jumlah_key24_15 > 0){$jumlah_key24_15hasil = 1 ; }else{$jumlah_key24_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '24', '$key24_1hasil', '$jumlah_key24_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_2hasil', '$jumlah_key24_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_3hasil', '$jumlah_key24_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_4hasil', '$jumlah_key24_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_5hasil', '$jumlah_key24_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_6hasil', '$jumlah_key24_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_7hasil', '$jumlah_key24_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_8hasil', '$jumlah_key24_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_9hasil', '$jumlah_key24_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_10hasil', '$jumlah_key24_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_11hasil', '$jumlah_key24_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_12hasil', '$jumlah_key24_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_13hasil', '$jumlah_key24_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_14hasil', '$jumlah_key24_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '24', '$key24_15hasil', '$jumlah_key24_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data25= mysqli_query($connect,"select * from tb_indikator where id_indikator='25'");		
	while($result25 = mysqli_fetch_array($data25)){	
	$indikator25 = $result25['indikator'];	
	$indikator_kecil25 = strtolower($indikator25);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator25 = str_replace($filter, '', $indikator_kecil25);	
	list($key25_1, $key25_2, $key25_3, $key25_4, $key25_5, $key25_6, $key25_7, $key25_8, $key25_9, $key25_10, $key25_11, $key25_12, $key25_13, $key25_14, $key25_15) = explode(' ', $filter_indikator25);	
		$jumlah_key25_1 = substr_count($source_code, $key25_1);
		$jumlah_key25_2 = substr_count($source_code, $key25_2);
		$jumlah_key25_3 = substr_count($source_code, $key25_3);
		$jumlah_key25_4 = substr_count($source_code, $key25_4);
		$jumlah_key25_5 = substr_count($source_code, $key25_5);
		$jumlah_key25_6 = substr_count($source_code, $key25_6);
		$jumlah_key25_7 = substr_count($source_code, $key25_7);
		$jumlah_key25_8 = substr_count($source_code, $key25_8);
		$jumlah_key25_9 = substr_count($source_code, $key25_9);
		$jumlah_key25_10 = substr_count($source_code, $key25_10);
		$jumlah_key25_11 = substr_count($source_code, $key25_11);
		$jumlah_key25_12 = substr_count($source_code, $key25_12);
		$jumlah_key25_13 = substr_count($source_code, $key25_13);
		$jumlah_key25_14 = substr_count($source_code, $key25_14);
		$jumlah_key25_15 = substr_count($source_code, $key25_15);
	    }	
		
if($jumlah_key25_1 > 0){$jumlah_key25_1hasil = 1 ; }else{$jumlah_key25_1hasil = 0 ;}		
if($jumlah_key25_2 > 0){$jumlah_key25_2hasil = 1 ; }else{$jumlah_key25_2hasil = 0 ;}		
if($jumlah_key25_3 > 0){$jumlah_key25_3hasil = 1 ; }else{$jumlah_key25_3hasil = 0 ;}		
if($jumlah_key25_4 > 0){$jumlah_key25_4hasil = 1 ; }else{$jumlah_key25_4hasil = 0 ;}		
if($jumlah_key25_5 > 0){$jumlah_key25_5hasil = 1 ; }else{$jumlah_key25_5hasil = 0 ;}		
if($jumlah_key25_6 > 0){$jumlah_key25_6hasil = 1 ; }else{$jumlah_key25_6hasil = 0 ;}		
if($jumlah_key25_7 > 0){$jumlah_key25_7hasil = 1 ; }else{$jumlah_key25_7hasil = 0 ;}		
if($jumlah_key25_8 > 0){$jumlah_key25_8hasil = 1 ; }else{$jumlah_key25_8hasil = 0 ;}		
if($jumlah_key25_9 > 0){$jumlah_key25_9hasil = 1 ; }else{$jumlah_key25_9hasil = 0 ;}		
if($jumlah_key25_10 > 0){$jumlah_key25_10hasil = 1 ; }else{$jumlah_key25_10hasil = 0 ;}		
if($jumlah_key25_11 > 0){$jumlah_key25_11hasil = 1 ; }else{$jumlah_key25_11hasil = 0 ;}		
if($jumlah_key25_12 > 0){$jumlah_key25_12hasil = 1 ; }else{$jumlah_key25_12hasil = 0 ;}		
if($jumlah_key25_13 > 0){$jumlah_key25_13hasil = 1 ; }else{$jumlah_key25_13hasil = 0 ;}		
if($jumlah_key25_14 > 0){$jumlah_key25_14hasil = 1 ; }else{$jumlah_key25_14hasil = 0 ;}		
if($jumlah_key25_15 > 0){$jumlah_key25_15hasil = 1 ; }else{$jumlah_key25_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '25', '$key25_1hasil', '$jumlah_key25_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_2hasil', '$jumlah_key25_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_3hasil', '$jumlah_key25_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_4hasil', '$jumlah_key25_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_5hasil', '$jumlah_key25_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_6hasil', '$jumlah_key25_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_7hasil', '$jumlah_key25_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_8hasil', '$jumlah_key25_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_9hasil', '$jumlah_key25_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_10hasil', '$jumlah_key25_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_11hasil', '$jumlah_key25_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_12hasil', '$jumlah_key25_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_13hasil', '$jumlah_key25_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_14hasil', '$jumlah_key25_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '25', '$key25_15hasil', '$jumlah_key25_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data26= mysqli_query($connect,"select * from tb_indikator where id_indikator='26'");		
	while($result26 = mysqli_fetch_array($data26)){	
	$indikator26 = $result26['indikator'];	
	$indikator_kecil26 = strtolower($indikator26);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator26 = str_replace($filter, '', $indikator_kecil26);	
	list($key26_1, $key26_2, $key26_3, $key26_4, $key26_5, $key26_6, $key26_7, $key26_8, $key26_9, $key26_10, $key26_11, $key26_12, $key26_13, $key26_14, $key26_15) = explode(' ', $filter_indikator26);	
		$jumlah_key26_1 = substr_count($source_code, $key26_1);
		$jumlah_key26_2 = substr_count($source_code, $key26_2);
		$jumlah_key26_3 = substr_count($source_code, $key26_3);
		$jumlah_key26_4 = substr_count($source_code, $key26_4);
		$jumlah_key26_5 = substr_count($source_code, $key26_5);
		$jumlah_key26_6 = substr_count($source_code, $key26_6);
		$jumlah_key26_7 = substr_count($source_code, $key26_7);
		$jumlah_key26_8 = substr_count($source_code, $key26_8);
		$jumlah_key26_9 = substr_count($source_code, $key26_9);
		$jumlah_key26_10 = substr_count($source_code, $key26_10);
		$jumlah_key26_11 = substr_count($source_code, $key26_11);
		$jumlah_key26_12 = substr_count($source_code, $key26_12);
		$jumlah_key26_13 = substr_count($source_code, $key26_13);
		$jumlah_key26_14 = substr_count($source_code, $key26_14);
		$jumlah_key26_15 = substr_count($source_code, $key26_15);
	    }	
		
if($jumlah_key26_1 > 0){$jumlah_key26_1hasil = 1 ; }else{$jumlah_key26_1hasil = 0 ;}		
if($jumlah_key26_2 > 0){$jumlah_key26_2hasil = 1 ; }else{$jumlah_key26_2hasil = 0 ;}		
if($jumlah_key26_3 > 0){$jumlah_key26_3hasil = 1 ; }else{$jumlah_key26_3hasil = 0 ;}		
if($jumlah_key26_4 > 0){$jumlah_key26_4hasil = 1 ; }else{$jumlah_key26_4hasil = 0 ;}		
if($jumlah_key26_5 > 0){$jumlah_key26_5hasil = 1 ; }else{$jumlah_key26_5hasil = 0 ;}		
if($jumlah_key26_6 > 0){$jumlah_key26_6hasil = 1 ; }else{$jumlah_key26_6hasil = 0 ;}		
if($jumlah_key26_7 > 0){$jumlah_key26_7hasil = 1 ; }else{$jumlah_key26_7hasil = 0 ;}		
if($jumlah_key26_8 > 0){$jumlah_key26_8hasil = 1 ; }else{$jumlah_key26_8hasil = 0 ;}		
if($jumlah_key26_9 > 0){$jumlah_key26_9hasil = 1 ; }else{$jumlah_key26_9hasil = 0 ;}		
if($jumlah_key26_10 > 0){$jumlah_key26_10hasil = 1 ; }else{$jumlah_key26_10hasil = 0 ;}		
if($jumlah_key26_11 > 0){$jumlah_key26_11hasil = 1 ; }else{$jumlah_key26_11hasil = 0 ;}		
if($jumlah_key26_12 > 0){$jumlah_key26_12hasil = 1 ; }else{$jumlah_key26_12hasil = 0 ;}		
if($jumlah_key26_13 > 0){$jumlah_key26_13hasil = 1 ; }else{$jumlah_key26_13hasil = 0 ;}		
if($jumlah_key26_14 > 0){$jumlah_key26_14hasil = 1 ; }else{$jumlah_key26_14hasil = 0 ;}		
if($jumlah_key26_15 > 0){$jumlah_key26_15hasil = 1 ; }else{$jumlah_key26_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '26', '$key26_1hasil', '$jumlah_key26_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_2hasil', '$jumlah_key26_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_3hasil', '$jumlah_key26_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_4hasil', '$jumlah_key26_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_5hasil', '$jumlah_key26_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_6hasil', '$jumlah_key26_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_7hasil', '$jumlah_key26_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_8hasil', '$jumlah_key26_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_9hasil', '$jumlah_key26_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_10hasil', '$jumlah_key26_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_11hasil', '$jumlah_key26_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_12hasil', '$jumlah_key26_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_13hasil', '$jumlah_key26_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_14hasil', '$jumlah_key26_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '26', '$key26_15hasil', '$jumlah_key26_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data27= mysqli_query($connect,"select * from tb_indikator where id_indikator='27'");		
	while($result27 = mysqli_fetch_array($data27)){	
	$indikator27 = $result27['indikator'];	
	$indikator_kecil27 = strtolower($indikator27);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator27 = str_replace($filter, '', $indikator_kecil27);	
	list($key27_1, $key27_2, $key27_3, $key27_4, $key27_5, $key27_6, $key27_7, $key27_8, $key27_9, $key27_10, $key27_11, $key27_12, $key27_13, $key27_14, $key27_15) = explode(' ', $filter_indikator27);	
		$jumlah_key27_1 = substr_count($source_code, $key27_1);
		$jumlah_key27_2 = substr_count($source_code, $key27_2);
		$jumlah_key27_3 = substr_count($source_code, $key27_3);
		$jumlah_key27_4 = substr_count($source_code, $key27_4);
		$jumlah_key27_5 = substr_count($source_code, $key27_5);
		$jumlah_key27_6 = substr_count($source_code, $key27_6);
		$jumlah_key27_7 = substr_count($source_code, $key27_7);
		$jumlah_key27_8 = substr_count($source_code, $key27_8);
		$jumlah_key27_9 = substr_count($source_code, $key27_9);
		$jumlah_key27_10 = substr_count($source_code, $key27_10);
		$jumlah_key27_11 = substr_count($source_code, $key27_11);
		$jumlah_key27_12 = substr_count($source_code, $key27_12);
		$jumlah_key27_13 = substr_count($source_code, $key27_13);
		$jumlah_key27_14 = substr_count($source_code, $key27_14);
		$jumlah_key27_15 = substr_count($source_code, $key27_15);
	    }	
		
if($jumlah_key27_1 > 0){$jumlah_key27_1hasil = 1 ; }else{$jumlah_key27_1hasil = 0 ;}		
if($jumlah_key27_2 > 0){$jumlah_key27_2hasil = 1 ; }else{$jumlah_key27_2hasil = 0 ;}		
if($jumlah_key27_3 > 0){$jumlah_key27_3hasil = 1 ; }else{$jumlah_key27_3hasil = 0 ;}		
if($jumlah_key27_4 > 0){$jumlah_key27_4hasil = 1 ; }else{$jumlah_key27_4hasil = 0 ;}		
if($jumlah_key27_5 > 0){$jumlah_key27_5hasil = 1 ; }else{$jumlah_key27_5hasil = 0 ;}		
if($jumlah_key27_6 > 0){$jumlah_key27_6hasil = 1 ; }else{$jumlah_key27_6hasil = 0 ;}		
if($jumlah_key27_7 > 0){$jumlah_key27_7hasil = 1 ; }else{$jumlah_key27_7hasil = 0 ;}		
if($jumlah_key27_8 > 0){$jumlah_key27_8hasil = 1 ; }else{$jumlah_key27_8hasil = 0 ;}		
if($jumlah_key27_9 > 0){$jumlah_key27_9hasil = 1 ; }else{$jumlah_key27_9hasil = 0 ;}		
if($jumlah_key27_10 > 0){$jumlah_key27_10hasil = 1 ; }else{$jumlah_key27_10hasil = 0 ;}		
if($jumlah_key27_11 > 0){$jumlah_key27_11hasil = 1 ; }else{$jumlah_key27_11hasil = 0 ;}		
if($jumlah_key27_12 > 0){$jumlah_key27_12hasil = 1 ; }else{$jumlah_key27_12hasil = 0 ;}		
if($jumlah_key27_13 > 0){$jumlah_key27_13hasil = 1 ; }else{$jumlah_key27_13hasil = 0 ;}		
if($jumlah_key27_14 > 0){$jumlah_key27_14hasil = 1 ; }else{$jumlah_key27_14hasil = 0 ;}		
if($jumlah_key27_15 > 0){$jumlah_key27_15hasil = 1 ; }else{$jumlah_key27_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '27', '$key27_1hasil', '$jumlah_key27_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_2hasil', '$jumlah_key27_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_3hasil', '$jumlah_key27_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_4hasil', '$jumlah_key27_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_5hasil', '$jumlah_key27_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_6hasil', '$jumlah_key27_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_7hasil', '$jumlah_key27_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_8hasil', '$jumlah_key27_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_9hasil', '$jumlah_key27_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_10hasil', '$jumlah_key27_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_11hasil', '$jumlah_key27_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_12hasil', '$jumlah_key27_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_13hasil', '$jumlah_key27_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_14hasil', '$jumlah_key27_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '27', '$key27_15hasil', '$jumlah_key27_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data28= mysqli_query($connect,"select * from tb_indikator where id_indikator='28'");		
	while($result28 = mysqli_fetch_array($data28)){	
	$indikator28 = $result28['indikator'];	
	$indikator_kecil28 = strtolower($indikator28);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator28 = str_replace($filter, '', $indikator_kecil28);	
	list($key28_1, $key28_2, $key28_3, $key28_4, $key28_5, $key28_6, $key28_7, $key28_8, $key28_9, $key28_10, $key28_11, $key28_12, $key28_13, $key28_14, $key28_15) = explode(' ', $filter_indikator28);	
		$jumlah_key28_1 = substr_count($source_code, $key28_1);
		$jumlah_key28_2 = substr_count($source_code, $key28_2);
		$jumlah_key28_3 = substr_count($source_code, $key28_3);
		$jumlah_key28_4 = substr_count($source_code, $key28_4);
		$jumlah_key28_5 = substr_count($source_code, $key28_5);
		$jumlah_key28_6 = substr_count($source_code, $key28_6);
		$jumlah_key28_7 = substr_count($source_code, $key28_7);
		$jumlah_key28_8 = substr_count($source_code, $key28_8);
		$jumlah_key28_9 = substr_count($source_code, $key28_9);
		$jumlah_key28_10 = substr_count($source_code, $key28_10);
		$jumlah_key28_11 = substr_count($source_code, $key28_11);
		$jumlah_key28_12 = substr_count($source_code, $key28_12);
		$jumlah_key28_13 = substr_count($source_code, $key28_13);
		$jumlah_key28_14 = substr_count($source_code, $key28_14);
		$jumlah_key28_15 = substr_count($source_code, $key28_15);
	    }	
		
if($jumlah_key28_1 > 0){$jumlah_key28_1hasil = 1 ; }else{$jumlah_key28_1hasil = 0 ;}		
if($jumlah_key28_2 > 0){$jumlah_key28_2hasil = 1 ; }else{$jumlah_key28_2hasil = 0 ;}		
if($jumlah_key28_3 > 0){$jumlah_key28_3hasil = 1 ; }else{$jumlah_key28_3hasil = 0 ;}		
if($jumlah_key28_4 > 0){$jumlah_key28_4hasil = 1 ; }else{$jumlah_key28_4hasil = 0 ;}		
if($jumlah_key28_5 > 0){$jumlah_key28_5hasil = 1 ; }else{$jumlah_key28_5hasil = 0 ;}		
if($jumlah_key28_6 > 0){$jumlah_key28_6hasil = 1 ; }else{$jumlah_key28_6hasil = 0 ;}		
if($jumlah_key28_7 > 0){$jumlah_key28_7hasil = 1 ; }else{$jumlah_key28_7hasil = 0 ;}		
if($jumlah_key28_8 > 0){$jumlah_key28_8hasil = 1 ; }else{$jumlah_key28_8hasil = 0 ;}		
if($jumlah_key28_9 > 0){$jumlah_key28_9hasil = 1 ; }else{$jumlah_key28_9hasil = 0 ;}		
if($jumlah_key28_10 > 0){$jumlah_key28_10hasil = 1 ; }else{$jumlah_key28_10hasil = 0 ;}		
if($jumlah_key28_11 > 0){$jumlah_key28_11hasil = 1 ; }else{$jumlah_key28_11hasil = 0 ;}		
if($jumlah_key28_12 > 0){$jumlah_key28_12hasil = 1 ; }else{$jumlah_key28_12hasil = 0 ;}		
if($jumlah_key28_13 > 0){$jumlah_key28_13hasil = 1 ; }else{$jumlah_key28_13hasil = 0 ;}		
if($jumlah_key28_14 > 0){$jumlah_key28_14hasil = 1 ; }else{$jumlah_key28_14hasil = 0 ;}		
if($jumlah_key28_15 > 0){$jumlah_key28_15hasil = 1 ; }else{$jumlah_key28_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '28', '$key28_1hasil', '$jumlah_key28_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_2hasil', '$jumlah_key28_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_3hasil', '$jumlah_key28_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_4hasil', '$jumlah_key28_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_5hasil', '$jumlah_key28_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_6hasil', '$jumlah_key28_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_7hasil', '$jumlah_key28_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_8hasil', '$jumlah_key28_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_9hasil', '$jumlah_key28_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_10hasil', '$jumlah_key28_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_11hasil', '$jumlah_key28_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_12hasil', '$jumlah_key28_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_13hasil', '$jumlah_key28_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_14hasil', '$jumlah_key28_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '28', '$key28_15hasil', '$jumlah_key28_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		


$data29= mysqli_query($connect,"select * from tb_indikator where id_indikator='29'");		
	while($result29 = mysqli_fetch_array($data29)){	
	$indikator29 = $result29['indikator'];	
	$indikator_kecil29 = strtolower($indikator29);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator29 = str_replace($filter, '', $indikator_kecil29);	
	list($key29_1, $key29_2, $key29_3, $key29_4, $key29_5, $key29_6, $key29_7, $key29_8, $key29_9, $key29_10, $key29_11, $key29_12, $key29_13, $key29_14, $key29_15) = explode(' ', $filter_indikator29);	
		$jumlah_key29_1 = substr_count($source_code, $key29_1);
		$jumlah_key29_2 = substr_count($source_code, $key29_2);
		$jumlah_key29_3 = substr_count($source_code, $key29_3);
		$jumlah_key29_4 = substr_count($source_code, $key29_4);
		$jumlah_key29_5 = substr_count($source_code, $key29_5);
		$jumlah_key29_6 = substr_count($source_code, $key29_6);
		$jumlah_key29_7 = substr_count($source_code, $key29_7);
		$jumlah_key29_8 = substr_count($source_code, $key29_8);
		$jumlah_key29_9 = substr_count($source_code, $key29_9);
		$jumlah_key29_10 = substr_count($source_code, $key29_10);
		$jumlah_key29_11 = substr_count($source_code, $key29_11);
		$jumlah_key29_12 = substr_count($source_code, $key29_12);
		$jumlah_key29_13 = substr_count($source_code, $key29_13);
		$jumlah_key29_14 = substr_count($source_code, $key29_14);
		$jumlah_key29_15 = substr_count($source_code, $key29_15);
	    }	
		
if($jumlah_key29_1 > 0){$jumlah_key29_1hasil = 1 ; }else{$jumlah_key29_1hasil = 0 ;}		
if($jumlah_key29_2 > 0){$jumlah_key29_2hasil = 1 ; }else{$jumlah_key29_2hasil = 0 ;}		
if($jumlah_key29_3 > 0){$jumlah_key29_3hasil = 1 ; }else{$jumlah_key29_3hasil = 0 ;}		
if($jumlah_key29_4 > 0){$jumlah_key29_4hasil = 1 ; }else{$jumlah_key29_4hasil = 0 ;}		
if($jumlah_key29_5 > 0){$jumlah_key29_5hasil = 1 ; }else{$jumlah_key29_5hasil = 0 ;}		
if($jumlah_key29_6 > 0){$jumlah_key29_6hasil = 1 ; }else{$jumlah_key29_6hasil = 0 ;}		
if($jumlah_key29_7 > 0){$jumlah_key29_7hasil = 1 ; }else{$jumlah_key29_7hasil = 0 ;}		
if($jumlah_key29_8 > 0){$jumlah_key29_8hasil = 1 ; }else{$jumlah_key29_8hasil = 0 ;}		
if($jumlah_key29_9 > 0){$jumlah_key29_9hasil = 1 ; }else{$jumlah_key29_9hasil = 0 ;}		
if($jumlah_key29_10 > 0){$jumlah_key29_10hasil = 1 ; }else{$jumlah_key29_10hasil = 0 ;}		
if($jumlah_key29_11 > 0){$jumlah_key29_11hasil = 1 ; }else{$jumlah_key29_11hasil = 0 ;}		
if($jumlah_key29_12 > 0){$jumlah_key29_12hasil = 1 ; }else{$jumlah_key29_12hasil = 0 ;}		
if($jumlah_key29_13 > 0){$jumlah_key29_13hasil = 1 ; }else{$jumlah_key29_13hasil = 0 ;}		
if($jumlah_key29_14 > 0){$jumlah_key29_14hasil = 1 ; }else{$jumlah_key29_14hasil = 0 ;}		
if($jumlah_key29_15 > 0){$jumlah_key29_15hasil = 1 ; }else{$jumlah_key29_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '29', '$key29_1hasil', '$jumlah_key29_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_2hasil', '$jumlah_key29_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_3hasil', '$jumlah_key29_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_4hasil', '$jumlah_key29_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_5hasil', '$jumlah_key29_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_6hasil', '$jumlah_key29_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_7hasil', '$jumlah_key29_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_8hasil', '$jumlah_key29_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_9hasil', '$jumlah_key29_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_10hasil', '$jumlah_key29_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_11hasil', '$jumlah_key29_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_12hasil', '$jumlah_key29_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_13hasil', '$jumlah_key29_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_14hasil', '$jumlah_key29_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '29', '$key29_15hasil', '$jumlah_key29_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data30= mysqli_query($connect,"select * from tb_indikator where id_indikator='30'");		
	while($result30 = mysqli_fetch_array($data30)){	
	$indikator30 = $result30['indikator'];	
	$indikator_kecil30 = strtolower($indikator30);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator30 = str_replace($filter, '', $indikator_kecil30);	
	list($key30_1, $key30_2, $key30_3, $key30_4, $key30_5, $key30_6, $key30_7, $key30_8, $key30_9, $key30_10, $key30_11, $key30_12, $key30_13, $key30_14, $key30_15) = explode(' ', $filter_indikator30);	
		$jumlah_key30_1 = substr_count($source_code, $key30_1);
		$jumlah_key30_2 = substr_count($source_code, $key30_2);
		$jumlah_key30_3 = substr_count($source_code, $key30_3);
		$jumlah_key30_4 = substr_count($source_code, $key30_4);
		$jumlah_key30_5 = substr_count($source_code, $key30_5);
		$jumlah_key30_6 = substr_count($source_code, $key30_6);
		$jumlah_key30_7 = substr_count($source_code, $key30_7);
		$jumlah_key30_8 = substr_count($source_code, $key30_8);
		$jumlah_key30_9 = substr_count($source_code, $key30_9);
		$jumlah_key30_10 = substr_count($source_code, $key30_10);
		$jumlah_key30_11 = substr_count($source_code, $key30_11);
		$jumlah_key30_12 = substr_count($source_code, $key30_12);
		$jumlah_key30_13 = substr_count($source_code, $key30_13);
		$jumlah_key30_14 = substr_count($source_code, $key30_14);
		$jumlah_key30_15 = substr_count($source_code, $key30_15);
	    }	
		
if($jumlah_key30_1 > 0){$jumlah_key30_1hasil = 1 ; }else{$jumlah_key30_1hasil = 0 ;}		
if($jumlah_key30_2 > 0){$jumlah_key30_2hasil = 1 ; }else{$jumlah_key30_2hasil = 0 ;}		
if($jumlah_key30_3 > 0){$jumlah_key30_3hasil = 1 ; }else{$jumlah_key30_3hasil = 0 ;}		
if($jumlah_key30_4 > 0){$jumlah_key30_4hasil = 1 ; }else{$jumlah_key30_4hasil = 0 ;}		
if($jumlah_key30_5 > 0){$jumlah_key30_5hasil = 1 ; }else{$jumlah_key30_5hasil = 0 ;}		
if($jumlah_key30_6 > 0){$jumlah_key30_6hasil = 1 ; }else{$jumlah_key30_6hasil = 0 ;}		
if($jumlah_key30_7 > 0){$jumlah_key30_7hasil = 1 ; }else{$jumlah_key30_7hasil = 0 ;}		
if($jumlah_key30_8 > 0){$jumlah_key30_8hasil = 1 ; }else{$jumlah_key30_8hasil = 0 ;}		
if($jumlah_key30_9 > 0){$jumlah_key30_9hasil = 1 ; }else{$jumlah_key30_9hasil = 0 ;}		
if($jumlah_key30_10 > 0){$jumlah_key30_10hasil = 1 ; }else{$jumlah_key30_10hasil = 0 ;}		
if($jumlah_key30_11 > 0){$jumlah_key30_11hasil = 1 ; }else{$jumlah_key30_11hasil = 0 ;}		
if($jumlah_key30_12 > 0){$jumlah_key30_12hasil = 1 ; }else{$jumlah_key30_12hasil = 0 ;}		
if($jumlah_key30_13 > 0){$jumlah_key30_13hasil = 1 ; }else{$jumlah_key30_13hasil = 0 ;}		
if($jumlah_key30_14 > 0){$jumlah_key30_14hasil = 1 ; }else{$jumlah_key30_14hasil = 0 ;}		
if($jumlah_key30_15 > 0){$jumlah_key30_15hasil = 1 ; }else{$jumlah_key30_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '30', '$key30_1hasil', '$jumlah_key30_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_2hasil', '$jumlah_key30_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_3hasil', '$jumlah_key30_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_4hasil', '$jumlah_key30_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_5hasil', '$jumlah_key30_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_6hasil', '$jumlah_key30_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_7hasil', '$jumlah_key30_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_8hasil', '$jumlah_key30_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_9hasil', '$jumlah_key30_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_10hasil', '$jumlah_key30_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_11hasil', '$jumlah_key30_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_12hasil', '$jumlah_key30_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_13hasil', '$jumlah_key30_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_14hasil', '$jumlah_key30_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '30', '$key30_15hasil', '$jumlah_key30_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data31= mysqli_query($connect,"select * from tb_indikator where id_indikator='31'");		
	while($result31 = mysqli_fetch_array($data31)){	
	$indikator31 = $result31['indikator'];	
	$indikator_kecil31 = strtolower($indikator31);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator31 = str_replace($filter, '', $indikator_kecil31);	
	list($key31_1, $key31_2, $key31_3, $key31_4, $key31_5, $key31_6, $key31_7, $key31_8, $key31_9, $key31_10, $key31_11, $key31_12, $key31_13, $key31_14, $key31_15) = explode(' ', $filter_indikator31);	
		$jumlah_key31_1 = substr_count($source_code, $key31_1);
		$jumlah_key31_2 = substr_count($source_code, $key31_2);
		$jumlah_key31_3 = substr_count($source_code, $key31_3);
		$jumlah_key31_4 = substr_count($source_code, $key31_4);
		$jumlah_key31_5 = substr_count($source_code, $key31_5);
		$jumlah_key31_6 = substr_count($source_code, $key31_6);
		$jumlah_key31_7 = substr_count($source_code, $key31_7);
		$jumlah_key31_8 = substr_count($source_code, $key31_8);
		$jumlah_key31_9 = substr_count($source_code, $key31_9);
		$jumlah_key31_10 = substr_count($source_code, $key31_10);
		$jumlah_key31_11 = substr_count($source_code, $key31_11);
		$jumlah_key31_12 = substr_count($source_code, $key31_12);
		$jumlah_key31_13 = substr_count($source_code, $key31_13);
		$jumlah_key31_14 = substr_count($source_code, $key31_14);
		$jumlah_key31_15 = substr_count($source_code, $key31_15);
	    }	
		
if($jumlah_key31_1 > 0){$jumlah_key31_1hasil = 1 ; }else{$jumlah_key31_1hasil = 0 ;}		
if($jumlah_key31_2 > 0){$jumlah_key31_2hasil = 1 ; }else{$jumlah_key31_2hasil = 0 ;}		
if($jumlah_key31_3 > 0){$jumlah_key31_3hasil = 1 ; }else{$jumlah_key31_3hasil = 0 ;}		
if($jumlah_key31_4 > 0){$jumlah_key31_4hasil = 1 ; }else{$jumlah_key31_4hasil = 0 ;}		
if($jumlah_key31_5 > 0){$jumlah_key31_5hasil = 1 ; }else{$jumlah_key31_5hasil = 0 ;}		
if($jumlah_key31_6 > 0){$jumlah_key31_6hasil = 1 ; }else{$jumlah_key31_6hasil = 0 ;}		
if($jumlah_key31_7 > 0){$jumlah_key31_7hasil = 1 ; }else{$jumlah_key31_7hasil = 0 ;}		
if($jumlah_key31_8 > 0){$jumlah_key31_8hasil = 1 ; }else{$jumlah_key31_8hasil = 0 ;}		
if($jumlah_key31_9 > 0){$jumlah_key31_9hasil = 1 ; }else{$jumlah_key31_9hasil = 0 ;}		
if($jumlah_key31_10 > 0){$jumlah_key31_10hasil = 1 ; }else{$jumlah_key31_10hasil = 0 ;}		
if($jumlah_key31_11 > 0){$jumlah_key31_11hasil = 1 ; }else{$jumlah_key31_11hasil = 0 ;}		
if($jumlah_key31_12 > 0){$jumlah_key31_12hasil = 1 ; }else{$jumlah_key31_12hasil = 0 ;}		
if($jumlah_key31_13 > 0){$jumlah_key31_13hasil = 1 ; }else{$jumlah_key31_13hasil = 0 ;}		
if($jumlah_key31_14 > 0){$jumlah_key31_14hasil = 1 ; }else{$jumlah_key31_14hasil = 0 ;}		
if($jumlah_key31_15 > 0){$jumlah_key31_15hasil = 1 ; }else{$jumlah_key31_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '31', '$key31_1hasil', '$jumlah_key31_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_2hasil', '$jumlah_key31_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_3hasil', '$jumlah_key31_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_4hasil', '$jumlah_key31_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_5hasil', '$jumlah_key31_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_6hasil', '$jumlah_key31_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_7hasil', '$jumlah_key31_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_8hasil', '$jumlah_key31_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_9hasil', '$jumlah_key31_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_10hasil', '$jumlah_key31_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_11hasil', '$jumlah_key31_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_12hasil', '$jumlah_key31_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_13hasil', '$jumlah_key31_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_14hasil', '$jumlah_key31_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '31', '$key31_15hasil', '$jumlah_key31_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data32= mysqli_query($connect,"select * from tb_indikator where id_indikator='32'");		
	while($result32 = mysqli_fetch_array($data32)){	
	$indikator32 = $result32['indikator'];	
	$indikator_kecil32 = strtolower($indikator32);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator32 = str_replace($filter, '', $indikator_kecil32);	
	list($key32_1, $key32_2, $key32_3, $key32_4, $key32_5, $key32_6, $key32_7, $key32_8, $key32_9, $key32_10, $key32_11, $key32_12, $key32_13, $key32_14, $key32_15) = explode(' ', $filter_indikator32);	
		$jumlah_key32_1 = substr_count($source_code, $key32_1);
		$jumlah_key32_2 = substr_count($source_code, $key32_2);
		$jumlah_key32_3 = substr_count($source_code, $key32_3);
		$jumlah_key32_4 = substr_count($source_code, $key32_4);
		$jumlah_key32_5 = substr_count($source_code, $key32_5);
		$jumlah_key32_6 = substr_count($source_code, $key32_6);
		$jumlah_key32_7 = substr_count($source_code, $key32_7);
		$jumlah_key32_8 = substr_count($source_code, $key32_8);
		$jumlah_key32_9 = substr_count($source_code, $key32_9);
		$jumlah_key32_10 = substr_count($source_code, $key32_10);
		$jumlah_key32_11 = substr_count($source_code, $key32_11);
		$jumlah_key32_12 = substr_count($source_code, $key32_12);
		$jumlah_key32_13 = substr_count($source_code, $key32_13);
		$jumlah_key32_14 = substr_count($source_code, $key32_14);
		$jumlah_key32_15 = substr_count($source_code, $key32_15);
	    }	
		
if($jumlah_key32_1 > 0){$jumlah_key32_1hasil = 1 ; }else{$jumlah_key32_1hasil = 0 ;}		
if($jumlah_key32_2 > 0){$jumlah_key32_2hasil = 1 ; }else{$jumlah_key32_2hasil = 0 ;}		
if($jumlah_key32_3 > 0){$jumlah_key32_3hasil = 1 ; }else{$jumlah_key32_3hasil = 0 ;}		
if($jumlah_key32_4 > 0){$jumlah_key32_4hasil = 1 ; }else{$jumlah_key32_4hasil = 0 ;}		
if($jumlah_key32_5 > 0){$jumlah_key32_5hasil = 1 ; }else{$jumlah_key32_5hasil = 0 ;}		
if($jumlah_key32_6 > 0){$jumlah_key32_6hasil = 1 ; }else{$jumlah_key32_6hasil = 0 ;}		
if($jumlah_key32_7 > 0){$jumlah_key32_7hasil = 1 ; }else{$jumlah_key32_7hasil = 0 ;}		
if($jumlah_key32_8 > 0){$jumlah_key32_8hasil = 1 ; }else{$jumlah_key32_8hasil = 0 ;}		
if($jumlah_key32_9 > 0){$jumlah_key32_9hasil = 1 ; }else{$jumlah_key32_9hasil = 0 ;}		
if($jumlah_key32_10 > 0){$jumlah_key32_10hasil = 1 ; }else{$jumlah_key32_10hasil = 0 ;}		
if($jumlah_key32_11 > 0){$jumlah_key32_11hasil = 1 ; }else{$jumlah_key32_11hasil = 0 ;}		
if($jumlah_key32_12 > 0){$jumlah_key32_12hasil = 1 ; }else{$jumlah_key32_12hasil = 0 ;}		
if($jumlah_key32_13 > 0){$jumlah_key32_13hasil = 1 ; }else{$jumlah_key32_13hasil = 0 ;}		
if($jumlah_key32_14 > 0){$jumlah_key32_14hasil = 1 ; }else{$jumlah_key32_14hasil = 0 ;}		
if($jumlah_key32_15 > 0){$jumlah_key32_15hasil = 1 ; }else{$jumlah_key32_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '32', '$key32_1hasil', '$jumlah_key32_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_2hasil', '$jumlah_key32_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_3hasil', '$jumlah_key32_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_4hasil', '$jumlah_key32_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_5hasil', '$jumlah_key32_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_6hasil', '$jumlah_key32_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_7hasil', '$jumlah_key32_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_8hasil', '$jumlah_key32_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_9hasil', '$jumlah_key32_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_10hasil', '$jumlah_key32_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_11hasil', '$jumlah_key32_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_12hasil', '$jumlah_key32_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_13hasil', '$jumlah_key32_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_14hasil', '$jumlah_key32_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '32', '$key32_15hasil', '$jumlah_key32_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data33= mysqli_query($connect,"select * from tb_indikator where id_indikator='33'");		
	while($result33 = mysqli_fetch_array($data33)){	
	$indikator33 = $result33['indikator'];	
	$indikator_kecil33 = strtolower($indikator33);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator33 = str_replace($filter, '', $indikator_kecil33);	
	list($key33_1, $key33_2, $key33_3, $key33_4, $key33_5, $key33_6, $key33_7, $key33_8, $key33_9, $key33_10, $key33_11, $key33_12, $key33_13, $key33_14, $key33_15) = explode(' ', $filter_indikator33);	
		$jumlah_key33_1 = substr_count($source_code, $key33_1);
		$jumlah_key33_2 = substr_count($source_code, $key33_2);
		$jumlah_key33_3 = substr_count($source_code, $key33_3);
		$jumlah_key33_4 = substr_count($source_code, $key33_4);
		$jumlah_key33_5 = substr_count($source_code, $key33_5);
		$jumlah_key33_6 = substr_count($source_code, $key33_6);
		$jumlah_key33_7 = substr_count($source_code, $key33_7);
		$jumlah_key33_8 = substr_count($source_code, $key33_8);
		$jumlah_key33_9 = substr_count($source_code, $key33_9);
		$jumlah_key33_10 = substr_count($source_code, $key33_10);
		$jumlah_key33_11 = substr_count($source_code, $key33_11);
		$jumlah_key33_12 = substr_count($source_code, $key33_12);
		$jumlah_key33_13 = substr_count($source_code, $key33_13);
		$jumlah_key33_14 = substr_count($source_code, $key33_14);
		$jumlah_key33_15 = substr_count($source_code, $key33_15);
	    }	
		
if($jumlah_key33_1 > 0){$jumlah_key33_1hasil = 1 ; }else{$jumlah_key33_1hasil = 0 ;}		
if($jumlah_key33_2 > 0){$jumlah_key33_2hasil = 1 ; }else{$jumlah_key33_2hasil = 0 ;}		
if($jumlah_key33_3 > 0){$jumlah_key33_3hasil = 1 ; }else{$jumlah_key33_3hasil = 0 ;}		
if($jumlah_key33_4 > 0){$jumlah_key33_4hasil = 1 ; }else{$jumlah_key33_4hasil = 0 ;}		
if($jumlah_key33_5 > 0){$jumlah_key33_5hasil = 1 ; }else{$jumlah_key33_5hasil = 0 ;}		
if($jumlah_key33_6 > 0){$jumlah_key33_6hasil = 1 ; }else{$jumlah_key33_6hasil = 0 ;}		
if($jumlah_key33_7 > 0){$jumlah_key33_7hasil = 1 ; }else{$jumlah_key33_7hasil = 0 ;}		
if($jumlah_key33_8 > 0){$jumlah_key33_8hasil = 1 ; }else{$jumlah_key33_8hasil = 0 ;}		
if($jumlah_key33_9 > 0){$jumlah_key33_9hasil = 1 ; }else{$jumlah_key33_9hasil = 0 ;}		
if($jumlah_key33_10 > 0){$jumlah_key33_10hasil = 1 ; }else{$jumlah_key33_10hasil = 0 ;}		
if($jumlah_key33_11 > 0){$jumlah_key33_11hasil = 1 ; }else{$jumlah_key33_11hasil = 0 ;}		
if($jumlah_key33_12 > 0){$jumlah_key33_12hasil = 1 ; }else{$jumlah_key33_12hasil = 0 ;}		
if($jumlah_key33_13 > 0){$jumlah_key33_13hasil = 1 ; }else{$jumlah_key33_13hasil = 0 ;}		
if($jumlah_key33_14 > 0){$jumlah_key33_14hasil = 1 ; }else{$jumlah_key33_14hasil = 0 ;}		
if($jumlah_key33_15 > 0){$jumlah_key33_15hasil = 1 ; }else{$jumlah_key33_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '33', '$key33_1hasil', '$jumlah_key33_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_2hasil', '$jumlah_key33_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_3hasil', '$jumlah_key33_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_4hasil', '$jumlah_key33_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_5hasil', '$jumlah_key33_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_6hasil', '$jumlah_key33_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_7hasil', '$jumlah_key33_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_8hasil', '$jumlah_key33_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_9hasil', '$jumlah_key33_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_10hasil', '$jumlah_key33_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_11hasil', '$jumlah_key33_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_12hasil', '$jumlah_key33_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_13hasil', '$jumlah_key33_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_14hasil', '$jumlah_key33_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '33', '$key33_15hasil', '$jumlah_key33_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data34= mysqli_query($connect,"select * from tb_indikator where id_indikator='34'");		
	while($result34 = mysqli_fetch_array($data34)){	
	$indikator34 = $result34['indikator'];	
	$indikator_kecil34 = strtolower($indikator34);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator34 = str_replace($filter, '', $indikator_kecil34);	
	list($key34_1, $key34_2, $key34_3, $key34_4, $key34_5, $key34_6, $key34_7, $key34_8, $key34_9, $key34_10, $key34_11, $key34_12, $key34_13, $key34_14, $key34_15) = explode(' ', $filter_indikator34);	
		$jumlah_key34_1 = substr_count($source_code, $key34_1);
		$jumlah_key34_2 = substr_count($source_code, $key34_2);
		$jumlah_key34_3 = substr_count($source_code, $key34_3);
		$jumlah_key34_4 = substr_count($source_code, $key34_4);
		$jumlah_key34_5 = substr_count($source_code, $key34_5);
		$jumlah_key34_6 = substr_count($source_code, $key34_6);
		$jumlah_key34_7 = substr_count($source_code, $key34_7);
		$jumlah_key34_8 = substr_count($source_code, $key34_8);
		$jumlah_key34_9 = substr_count($source_code, $key34_9);
		$jumlah_key34_10 = substr_count($source_code, $key34_10);
		$jumlah_key34_11 = substr_count($source_code, $key34_11);
		$jumlah_key34_12 = substr_count($source_code, $key34_12);
		$jumlah_key34_13 = substr_count($source_code, $key34_13);
		$jumlah_key34_14 = substr_count($source_code, $key34_14);
		$jumlah_key34_15 = substr_count($source_code, $key34_15);
	    }	
		
if($jumlah_key34_1 > 0){$jumlah_key34_1hasil = 1 ; }else{$jumlah_key34_1hasil = 0 ;}		
if($jumlah_key34_2 > 0){$jumlah_key34_2hasil = 1 ; }else{$jumlah_key34_2hasil = 0 ;}		
if($jumlah_key34_3 > 0){$jumlah_key34_3hasil = 1 ; }else{$jumlah_key34_3hasil = 0 ;}		
if($jumlah_key34_4 > 0){$jumlah_key34_4hasil = 1 ; }else{$jumlah_key34_4hasil = 0 ;}		
if($jumlah_key34_5 > 0){$jumlah_key34_5hasil = 1 ; }else{$jumlah_key34_5hasil = 0 ;}		
if($jumlah_key34_6 > 0){$jumlah_key34_6hasil = 1 ; }else{$jumlah_key34_6hasil = 0 ;}		
if($jumlah_key34_7 > 0){$jumlah_key34_7hasil = 1 ; }else{$jumlah_key34_7hasil = 0 ;}		
if($jumlah_key34_8 > 0){$jumlah_key34_8hasil = 1 ; }else{$jumlah_key34_8hasil = 0 ;}		
if($jumlah_key34_9 > 0){$jumlah_key34_9hasil = 1 ; }else{$jumlah_key34_9hasil = 0 ;}		
if($jumlah_key34_10 > 0){$jumlah_key34_10hasil = 1 ; }else{$jumlah_key34_10hasil = 0 ;}		
if($jumlah_key34_11 > 0){$jumlah_key34_11hasil = 1 ; }else{$jumlah_key34_11hasil = 0 ;}		
if($jumlah_key34_12 > 0){$jumlah_key34_12hasil = 1 ; }else{$jumlah_key34_12hasil = 0 ;}		
if($jumlah_key34_13 > 0){$jumlah_key34_13hasil = 1 ; }else{$jumlah_key34_13hasil = 0 ;}		
if($jumlah_key34_14 > 0){$jumlah_key34_14hasil = 1 ; }else{$jumlah_key34_14hasil = 0 ;}		
if($jumlah_key34_15 > 0){$jumlah_key34_15hasil = 1 ; }else{$jumlah_key34_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '34', '$key34_1hasil', '$jumlah_key34_1hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_2hasil', '$jumlah_key34_2hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_3hasil', '$jumlah_key34_3hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_4hasil', '$jumlah_key34_4hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_5hasil', '$jumlah_key34_5hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_6hasil', '$jumlah_key34_6hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_7hasil', '$jumlah_key34_7hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_8hasil', '$jumlah_key34_8hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_9hasil', '$jumlah_key34_9hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_10hasil', '$jumlah_key34_10hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_11hasil', '$jumlah_key34_11hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_12hasil', '$jumlah_key34_12hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_13hasil', '$jumlah_key34_13hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_14hasil', '$jumlah_key34_14hasil', 'GREEN D WEB VARIABLES', '$inputer' ),		
('$id_website', '$alamat_website', '34', '$key34_15hasil', '$jumlah_key34_15hasil', 'GREEN D WEB VARIABLES', '$inputer' )		
    ");		

$data35= mysqli_query($connect,"select * from tb_indikator where id_indikator='35'");		
	while($result35 = mysqli_fetch_array($data35)){	
	$indikator35 = $result35['indikator'];	
	$indikator_kecil35 = strtolower($indikator35);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator35 = str_replace($filter, '', $indikator_kecil35);	
	list($key35_1, $key35_2, $key35_3, $key35_4, $key35_5, $key35_6, $key35_7, $key35_8, $key35_9, $key35_10, $key35_11, $key35_12, $key35_13, $key35_14, $key35_15) = explode(' ', $filter_indikator35);	
		$jumlah_key35_1 = substr_count($source_code, $key35_1);
		$jumlah_key35_2 = substr_count($source_code, $key35_2);
		$jumlah_key35_3 = substr_count($source_code, $key35_3);
		$jumlah_key35_4 = substr_count($source_code, $key35_4);
		$jumlah_key35_5 = substr_count($source_code, $key35_5);
		$jumlah_key35_6 = substr_count($source_code, $key35_6);
		$jumlah_key35_7 = substr_count($source_code, $key35_7);
		$jumlah_key35_8 = substr_count($source_code, $key35_8);
		$jumlah_key35_9 = substr_count($source_code, $key35_9);
		$jumlah_key35_10 = substr_count($source_code, $key35_10);
		$jumlah_key35_11 = substr_count($source_code, $key35_11);
		$jumlah_key35_12 = substr_count($source_code, $key35_12);
		$jumlah_key35_13 = substr_count($source_code, $key35_13);
		$jumlah_key35_14 = substr_count($source_code, $key35_14);
		$jumlah_key35_15 = substr_count($source_code, $key35_15);
	    }	
		
if($jumlah_key35_1 > 0){$jumlah_key35_1hasil = 1 ; }else{$jumlah_key35_1hasil = 0 ;}		
if($jumlah_key35_2 > 0){$jumlah_key35_2hasil = 1 ; }else{$jumlah_key35_2hasil = 0 ;}		
if($jumlah_key35_3 > 0){$jumlah_key35_3hasil = 1 ; }else{$jumlah_key35_3hasil = 0 ;}		
if($jumlah_key35_4 > 0){$jumlah_key35_4hasil = 1 ; }else{$jumlah_key35_4hasil = 0 ;}		
if($jumlah_key35_5 > 0){$jumlah_key35_5hasil = 1 ; }else{$jumlah_key35_5hasil = 0 ;}		
if($jumlah_key35_6 > 0){$jumlah_key35_6hasil = 1 ; }else{$jumlah_key35_6hasil = 0 ;}		
if($jumlah_key35_7 > 0){$jumlah_key35_7hasil = 1 ; }else{$jumlah_key35_7hasil = 0 ;}		
if($jumlah_key35_8 > 0){$jumlah_key35_8hasil = 1 ; }else{$jumlah_key35_8hasil = 0 ;}		
if($jumlah_key35_9 > 0){$jumlah_key35_9hasil = 1 ; }else{$jumlah_key35_9hasil = 0 ;}		
if($jumlah_key35_10 > 0){$jumlah_key35_10hasil = 1 ; }else{$jumlah_key35_10hasil = 0 ;}		
if($jumlah_key35_11 > 0){$jumlah_key35_11hasil = 1 ; }else{$jumlah_key35_11hasil = 0 ;}		
if($jumlah_key35_12 > 0){$jumlah_key35_12hasil = 1 ; }else{$jumlah_key35_12hasil = 0 ;}		
if($jumlah_key35_13 > 0){$jumlah_key35_13hasil = 1 ; }else{$jumlah_key35_13hasil = 0 ;}		
if($jumlah_key35_14 > 0){$jumlah_key35_14hasil = 1 ; }else{$jumlah_key35_14hasil = 0 ;}		
if($jumlah_key35_15 > 0){$jumlah_key35_15hasil = 1 ; }else{$jumlah_key35_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '35', '$key35_1hasil', '$jumlah_key35_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_2hasil', '$jumlah_key35_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_3hasil', '$jumlah_key35_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_4hasil', '$jumlah_key35_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_5hasil', '$jumlah_key35_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_6hasil', '$jumlah_key35_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_7hasil', '$jumlah_key35_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_8hasil', '$jumlah_key35_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_9hasil', '$jumlah_key35_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_10hasil', '$jumlah_key35_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_11hasil', '$jumlah_key35_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_12hasil', '$jumlah_key35_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_13hasil', '$jumlah_key35_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_14hasil', '$jumlah_key35_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '35', '$key35_15hasil', '$jumlah_key35_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data36= mysqli_query($connect,"select * from tb_indikator where id_indikator='36'");		
	while($result36 = mysqli_fetch_array($data36)){	
	$indikator36 = $result36['indikator'];	
	$indikator_kecil36 = strtolower($indikator36);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator36 = str_replace($filter, '', $indikator_kecil36);	
	list($key36_1, $key36_2, $key36_3, $key36_4, $key36_5, $key36_6, $key36_7, $key36_8, $key36_9, $key36_10, $key36_11, $key36_12, $key36_13, $key36_14, $key36_15) = explode(' ', $filter_indikator36);	
		$jumlah_key36_1 = substr_count($source_code, $key36_1);
		$jumlah_key36_2 = substr_count($source_code, $key36_2);
		$jumlah_key36_3 = substr_count($source_code, $key36_3);
		$jumlah_key36_4 = substr_count($source_code, $key36_4);
		$jumlah_key36_5 = substr_count($source_code, $key36_5);
		$jumlah_key36_6 = substr_count($source_code, $key36_6);
		$jumlah_key36_7 = substr_count($source_code, $key36_7);
		$jumlah_key36_8 = substr_count($source_code, $key36_8);
		$jumlah_key36_9 = substr_count($source_code, $key36_9);
		$jumlah_key36_10 = substr_count($source_code, $key36_10);
		$jumlah_key36_11 = substr_count($source_code, $key36_11);
		$jumlah_key36_12 = substr_count($source_code, $key36_12);
		$jumlah_key36_13 = substr_count($source_code, $key36_13);
		$jumlah_key36_14 = substr_count($source_code, $key36_14);
		$jumlah_key36_15 = substr_count($source_code, $key36_15);
	    }	
		
if($jumlah_key36_1 > 0){$jumlah_key36_1hasil = 1 ; }else{$jumlah_key36_1hasil = 0 ;}		
if($jumlah_key36_2 > 0){$jumlah_key36_2hasil = 1 ; }else{$jumlah_key36_2hasil = 0 ;}		
if($jumlah_key36_3 > 0){$jumlah_key36_3hasil = 1 ; }else{$jumlah_key36_3hasil = 0 ;}		
if($jumlah_key36_4 > 0){$jumlah_key36_4hasil = 1 ; }else{$jumlah_key36_4hasil = 0 ;}		
if($jumlah_key36_5 > 0){$jumlah_key36_5hasil = 1 ; }else{$jumlah_key36_5hasil = 0 ;}		
if($jumlah_key36_6 > 0){$jumlah_key36_6hasil = 1 ; }else{$jumlah_key36_6hasil = 0 ;}		
if($jumlah_key36_7 > 0){$jumlah_key36_7hasil = 1 ; }else{$jumlah_key36_7hasil = 0 ;}		
if($jumlah_key36_8 > 0){$jumlah_key36_8hasil = 1 ; }else{$jumlah_key36_8hasil = 0 ;}		
if($jumlah_key36_9 > 0){$jumlah_key36_9hasil = 1 ; }else{$jumlah_key36_9hasil = 0 ;}		
if($jumlah_key36_10 > 0){$jumlah_key36_10hasil = 1 ; }else{$jumlah_key36_10hasil = 0 ;}		
if($jumlah_key36_11 > 0){$jumlah_key36_11hasil = 1 ; }else{$jumlah_key36_11hasil = 0 ;}		
if($jumlah_key36_12 > 0){$jumlah_key36_12hasil = 1 ; }else{$jumlah_key36_12hasil = 0 ;}		
if($jumlah_key36_13 > 0){$jumlah_key36_13hasil = 1 ; }else{$jumlah_key36_13hasil = 0 ;}		
if($jumlah_key36_14 > 0){$jumlah_key36_14hasil = 1 ; }else{$jumlah_key36_14hasil = 0 ;}		
if($jumlah_key36_15 > 0){$jumlah_key36_15hasil = 1 ; }else{$jumlah_key36_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '36', '$key36_1hasil', '$jumlah_key36_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_2hasil', '$jumlah_key36_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_3hasil', '$jumlah_key36_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_4hasil', '$jumlah_key36_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_5hasil', '$jumlah_key36_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_6hasil', '$jumlah_key36_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_7hasil', '$jumlah_key36_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_8hasil', '$jumlah_key36_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_9hasil', '$jumlah_key36_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_10hasil', '$jumlah_key36_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_11hasil', '$jumlah_key36_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_12hasil', '$jumlah_key36_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_13hasil', '$jumlah_key36_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_14hasil', '$jumlah_key36_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '36', '$key36_15hasil', '$jumlah_key36_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data37= mysqli_query($connect,"select * from tb_indikator where id_indikator='37'");		
	while($result37 = mysqli_fetch_array($data37)){	
	$indikator37 = $result37['indikator'];	
	$indikator_kecil37 = strtolower($indikator37);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator37 = str_replace($filter, '', $indikator_kecil37);	
	list($key37_1, $key37_2, $key37_3, $key37_4, $key37_5, $key37_6, $key37_7, $key37_8, $key37_9, $key37_10, $key37_11, $key37_12, $key37_13, $key37_14, $key37_15) = explode(' ', $filter_indikator37);	
		$jumlah_key37_1 = substr_count($source_code, $key37_1);
		$jumlah_key37_2 = substr_count($source_code, $key37_2);
		$jumlah_key37_3 = substr_count($source_code, $key37_3);
		$jumlah_key37_4 = substr_count($source_code, $key37_4);
		$jumlah_key37_5 = substr_count($source_code, $key37_5);
		$jumlah_key37_6 = substr_count($source_code, $key37_6);
		$jumlah_key37_7 = substr_count($source_code, $key37_7);
		$jumlah_key37_8 = substr_count($source_code, $key37_8);
		$jumlah_key37_9 = substr_count($source_code, $key37_9);
		$jumlah_key37_10 = substr_count($source_code, $key37_10);
		$jumlah_key37_11 = substr_count($source_code, $key37_11);
		$jumlah_key37_12 = substr_count($source_code, $key37_12);
		$jumlah_key37_13 = substr_count($source_code, $key37_13);
		$jumlah_key37_14 = substr_count($source_code, $key37_14);
		$jumlah_key37_15 = substr_count($source_code, $key37_15);
	    }	
		
if($jumlah_key37_1 > 0){$jumlah_key37_1hasil = 1 ; }else{$jumlah_key37_1hasil = 0 ;}		
if($jumlah_key37_2 > 0){$jumlah_key37_2hasil = 1 ; }else{$jumlah_key37_2hasil = 0 ;}		
if($jumlah_key37_3 > 0){$jumlah_key37_3hasil = 1 ; }else{$jumlah_key37_3hasil = 0 ;}		
if($jumlah_key37_4 > 0){$jumlah_key37_4hasil = 1 ; }else{$jumlah_key37_4hasil = 0 ;}		
if($jumlah_key37_5 > 0){$jumlah_key37_5hasil = 1 ; }else{$jumlah_key37_5hasil = 0 ;}		
if($jumlah_key37_6 > 0){$jumlah_key37_6hasil = 1 ; }else{$jumlah_key37_6hasil = 0 ;}		
if($jumlah_key37_7 > 0){$jumlah_key37_7hasil = 1 ; }else{$jumlah_key37_7hasil = 0 ;}		
if($jumlah_key37_8 > 0){$jumlah_key37_8hasil = 1 ; }else{$jumlah_key37_8hasil = 0 ;}		
if($jumlah_key37_9 > 0){$jumlah_key37_9hasil = 1 ; }else{$jumlah_key37_9hasil = 0 ;}		
if($jumlah_key37_10 > 0){$jumlah_key37_10hasil = 1 ; }else{$jumlah_key37_10hasil = 0 ;}		
if($jumlah_key37_11 > 0){$jumlah_key37_11hasil = 1 ; }else{$jumlah_key37_11hasil = 0 ;}		
if($jumlah_key37_12 > 0){$jumlah_key37_12hasil = 1 ; }else{$jumlah_key37_12hasil = 0 ;}		
if($jumlah_key37_13 > 0){$jumlah_key37_13hasil = 1 ; }else{$jumlah_key37_13hasil = 0 ;}		
if($jumlah_key37_14 > 0){$jumlah_key37_14hasil = 1 ; }else{$jumlah_key37_14hasil = 0 ;}		
if($jumlah_key37_15 > 0){$jumlah_key37_15hasil = 1 ; }else{$jumlah_key37_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '37', '$key37_1hasil', '$jumlah_key37_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_2hasil', '$jumlah_key37_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_3hasil', '$jumlah_key37_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_4hasil', '$jumlah_key37_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_5hasil', '$jumlah_key37_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_6hasil', '$jumlah_key37_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_7hasil', '$jumlah_key37_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_8hasil', '$jumlah_key37_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_9hasil', '$jumlah_key37_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_10hasil', '$jumlah_key37_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_11hasil', '$jumlah_key37_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_12hasil', '$jumlah_key37_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_13hasil', '$jumlah_key37_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_14hasil', '$jumlah_key37_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '37', '$key37_15hasil', '$jumlah_key37_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data38= mysqli_query($connect,"select * from tb_indikator where id_indikator='38'");		
	while($result38 = mysqli_fetch_array($data38)){	
	$indikator38 = $result38['indikator'];	
	$indikator_kecil38 = strtolower($indikator38);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator38 = str_replace($filter, '', $indikator_kecil38);	
	list($key38_1, $key38_2, $key38_3, $key38_4, $key38_5, $key38_6, $key38_7, $key38_8, $key38_9, $key38_10, $key38_11, $key38_12, $key38_13, $key38_14, $key38_15) = explode(' ', $filter_indikator38);	
		$jumlah_key38_1 = substr_count($source_code, $key38_1);
		$jumlah_key38_2 = substr_count($source_code, $key38_2);
		$jumlah_key38_3 = substr_count($source_code, $key38_3);
		$jumlah_key38_4 = substr_count($source_code, $key38_4);
		$jumlah_key38_5 = substr_count($source_code, $key38_5);
		$jumlah_key38_6 = substr_count($source_code, $key38_6);
		$jumlah_key38_7 = substr_count($source_code, $key38_7);
		$jumlah_key38_8 = substr_count($source_code, $key38_8);
		$jumlah_key38_9 = substr_count($source_code, $key38_9);
		$jumlah_key38_10 = substr_count($source_code, $key38_10);
		$jumlah_key38_11 = substr_count($source_code, $key38_11);
		$jumlah_key38_12 = substr_count($source_code, $key38_12);
		$jumlah_key38_13 = substr_count($source_code, $key38_13);
		$jumlah_key38_14 = substr_count($source_code, $key38_14);
		$jumlah_key38_15 = substr_count($source_code, $key38_15);
	    }	
		
if($jumlah_key38_1 > 0){$jumlah_key38_1hasil = 1 ; }else{$jumlah_key38_1hasil = 0 ;}		
if($jumlah_key38_2 > 0){$jumlah_key38_2hasil = 1 ; }else{$jumlah_key38_2hasil = 0 ;}		
if($jumlah_key38_3 > 0){$jumlah_key38_3hasil = 1 ; }else{$jumlah_key38_3hasil = 0 ;}		
if($jumlah_key38_4 > 0){$jumlah_key38_4hasil = 1 ; }else{$jumlah_key38_4hasil = 0 ;}		
if($jumlah_key38_5 > 0){$jumlah_key38_5hasil = 1 ; }else{$jumlah_key38_5hasil = 0 ;}		
if($jumlah_key38_6 > 0){$jumlah_key38_6hasil = 1 ; }else{$jumlah_key38_6hasil = 0 ;}		
if($jumlah_key38_7 > 0){$jumlah_key38_7hasil = 1 ; }else{$jumlah_key38_7hasil = 0 ;}		
if($jumlah_key38_8 > 0){$jumlah_key38_8hasil = 1 ; }else{$jumlah_key38_8hasil = 0 ;}		
if($jumlah_key38_9 > 0){$jumlah_key38_9hasil = 1 ; }else{$jumlah_key38_9hasil = 0 ;}		
if($jumlah_key38_10 > 0){$jumlah_key38_10hasil = 1 ; }else{$jumlah_key38_10hasil = 0 ;}		
if($jumlah_key38_11 > 0){$jumlah_key38_11hasil = 1 ; }else{$jumlah_key38_11hasil = 0 ;}		
if($jumlah_key38_12 > 0){$jumlah_key38_12hasil = 1 ; }else{$jumlah_key38_12hasil = 0 ;}		
if($jumlah_key38_13 > 0){$jumlah_key38_13hasil = 1 ; }else{$jumlah_key38_13hasil = 0 ;}		
if($jumlah_key38_14 > 0){$jumlah_key38_14hasil = 1 ; }else{$jumlah_key38_14hasil = 0 ;}		
if($jumlah_key38_15 > 0){$jumlah_key38_15hasil = 1 ; }else{$jumlah_key38_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '38', '$key38_1hasil', '$jumlah_key38_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_2hasil', '$jumlah_key38_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_3hasil', '$jumlah_key38_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_4hasil', '$jumlah_key38_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_5hasil', '$jumlah_key38_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_6hasil', '$jumlah_key38_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_7hasil', '$jumlah_key38_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_8hasil', '$jumlah_key38_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_9hasil', '$jumlah_key38_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_10hasil', '$jumlah_key38_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_11hasil', '$jumlah_key38_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_12hasil', '$jumlah_key38_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_13hasil', '$jumlah_key38_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_14hasil', '$jumlah_key38_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '38', '$key38_15hasil', '$jumlah_key38_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data39= mysqli_query($connect,"select * from tb_indikator where id_indikator='39'");		
	while($result39 = mysqli_fetch_array($data39)){	
	$indikator39 = $result39['indikator'];	
	$indikator_kecil39 = strtolower($indikator39);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator39 = str_replace($filter, '', $indikator_kecil39);	
	list($key39_1, $key39_2, $key39_3, $key39_4, $key39_5, $key39_6, $key39_7, $key39_8, $key39_9, $key39_10, $key39_11, $key39_12, $key39_13, $key39_14, $key39_15) = explode(' ', $filter_indikator39);	
		$jumlah_key39_1 = substr_count($source_code, $key39_1);
		$jumlah_key39_2 = substr_count($source_code, $key39_2);
		$jumlah_key39_3 = substr_count($source_code, $key39_3);
		$jumlah_key39_4 = substr_count($source_code, $key39_4);
		$jumlah_key39_5 = substr_count($source_code, $key39_5);
		$jumlah_key39_6 = substr_count($source_code, $key39_6);
		$jumlah_key39_7 = substr_count($source_code, $key39_7);
		$jumlah_key39_8 = substr_count($source_code, $key39_8);
		$jumlah_key39_9 = substr_count($source_code, $key39_9);
		$jumlah_key39_10 = substr_count($source_code, $key39_10);
		$jumlah_key39_11 = substr_count($source_code, $key39_11);
		$jumlah_key39_12 = substr_count($source_code, $key39_12);
		$jumlah_key39_13 = substr_count($source_code, $key39_13);
		$jumlah_key39_14 = substr_count($source_code, $key39_14);
		$jumlah_key39_15 = substr_count($source_code, $key39_15);
	    }	
		
if($jumlah_key39_1 > 0){$jumlah_key39_1hasil = 1 ; }else{$jumlah_key39_1hasil = 0 ;}		
if($jumlah_key39_2 > 0){$jumlah_key39_2hasil = 1 ; }else{$jumlah_key39_2hasil = 0 ;}		
if($jumlah_key39_3 > 0){$jumlah_key39_3hasil = 1 ; }else{$jumlah_key39_3hasil = 0 ;}		
if($jumlah_key39_4 > 0){$jumlah_key39_4hasil = 1 ; }else{$jumlah_key39_4hasil = 0 ;}		
if($jumlah_key39_5 > 0){$jumlah_key39_5hasil = 1 ; }else{$jumlah_key39_5hasil = 0 ;}		
if($jumlah_key39_6 > 0){$jumlah_key39_6hasil = 1 ; }else{$jumlah_key39_6hasil = 0 ;}		
if($jumlah_key39_7 > 0){$jumlah_key39_7hasil = 1 ; }else{$jumlah_key39_7hasil = 0 ;}		
if($jumlah_key39_8 > 0){$jumlah_key39_8hasil = 1 ; }else{$jumlah_key39_8hasil = 0 ;}		
if($jumlah_key39_9 > 0){$jumlah_key39_9hasil = 1 ; }else{$jumlah_key39_9hasil = 0 ;}		
if($jumlah_key39_10 > 0){$jumlah_key39_10hasil = 1 ; }else{$jumlah_key39_10hasil = 0 ;}		
if($jumlah_key39_11 > 0){$jumlah_key39_11hasil = 1 ; }else{$jumlah_key39_11hasil = 0 ;}		
if($jumlah_key39_12 > 0){$jumlah_key39_12hasil = 1 ; }else{$jumlah_key39_12hasil = 0 ;}		
if($jumlah_key39_13 > 0){$jumlah_key39_13hasil = 1 ; }else{$jumlah_key39_13hasil = 0 ;}		
if($jumlah_key39_14 > 0){$jumlah_key39_14hasil = 1 ; }else{$jumlah_key39_14hasil = 0 ;}		
if($jumlah_key39_15 > 0){$jumlah_key39_15hasil = 1 ; }else{$jumlah_key39_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '39', '$key39_1hasil', '$jumlah_key39_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_2hasil', '$jumlah_key39_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_3hasil', '$jumlah_key39_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_4hasil', '$jumlah_key39_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_5hasil', '$jumlah_key39_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_6hasil', '$jumlah_key39_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_7hasil', '$jumlah_key39_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_8hasil', '$jumlah_key39_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_9hasil', '$jumlah_key39_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_10hasil', '$jumlah_key39_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_11hasil', '$jumlah_key39_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_12hasil', '$jumlah_key39_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_13hasil', '$jumlah_key39_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_14hasil', '$jumlah_key39_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '39', '$key39_15hasil', '$jumlah_key39_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data40= mysqli_query($connect,"select * from tb_indikator where id_indikator='40'");		
	while($result40 = mysqli_fetch_array($data40)){	
	$indikator40 = $result40['indikator'];	
	$indikator_kecil40 = strtolower($indikator40);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator40 = str_replace($filter, '', $indikator_kecil40);	
	list($key40_1, $key40_2, $key40_3, $key40_4, $key40_5, $key40_6, $key40_7, $key40_8, $key40_9, $key40_10, $key40_11, $key40_12, $key40_13, $key40_14, $key40_15) = explode(' ', $filter_indikator40);	
		$jumlah_key40_1 = substr_count($source_code, $key40_1);
		$jumlah_key40_2 = substr_count($source_code, $key40_2);
		$jumlah_key40_3 = substr_count($source_code, $key40_3);
		$jumlah_key40_4 = substr_count($source_code, $key40_4);
		$jumlah_key40_5 = substr_count($source_code, $key40_5);
		$jumlah_key40_6 = substr_count($source_code, $key40_6);
		$jumlah_key40_7 = substr_count($source_code, $key40_7);
		$jumlah_key40_8 = substr_count($source_code, $key40_8);
		$jumlah_key40_9 = substr_count($source_code, $key40_9);
		$jumlah_key40_10 = substr_count($source_code, $key40_10);
		$jumlah_key40_11 = substr_count($source_code, $key40_11);
		$jumlah_key40_12 = substr_count($source_code, $key40_12);
		$jumlah_key40_13 = substr_count($source_code, $key40_13);
		$jumlah_key40_14 = substr_count($source_code, $key40_14);
		$jumlah_key40_15 = substr_count($source_code, $key40_15);
	    }	
		
if($jumlah_key40_1 > 0){$jumlah_key40_1hasil = 1 ; }else{$jumlah_key40_1hasil = 0 ;}		
if($jumlah_key40_2 > 0){$jumlah_key40_2hasil = 1 ; }else{$jumlah_key40_2hasil = 0 ;}		
if($jumlah_key40_3 > 0){$jumlah_key40_3hasil = 1 ; }else{$jumlah_key40_3hasil = 0 ;}		
if($jumlah_key40_4 > 0){$jumlah_key40_4hasil = 1 ; }else{$jumlah_key40_4hasil = 0 ;}		
if($jumlah_key40_5 > 0){$jumlah_key40_5hasil = 1 ; }else{$jumlah_key40_5hasil = 0 ;}		
if($jumlah_key40_6 > 0){$jumlah_key40_6hasil = 1 ; }else{$jumlah_key40_6hasil = 0 ;}		
if($jumlah_key40_7 > 0){$jumlah_key40_7hasil = 1 ; }else{$jumlah_key40_7hasil = 0 ;}		
if($jumlah_key40_8 > 0){$jumlah_key40_8hasil = 1 ; }else{$jumlah_key40_8hasil = 0 ;}		
if($jumlah_key40_9 > 0){$jumlah_key40_9hasil = 1 ; }else{$jumlah_key40_9hasil = 0 ;}		
if($jumlah_key40_10 > 0){$jumlah_key40_10hasil = 1 ; }else{$jumlah_key40_10hasil = 0 ;}		
if($jumlah_key40_11 > 0){$jumlah_key40_11hasil = 1 ; }else{$jumlah_key40_11hasil = 0 ;}		
if($jumlah_key40_12 > 0){$jumlah_key40_12hasil = 1 ; }else{$jumlah_key40_12hasil = 0 ;}		
if($jumlah_key40_13 > 0){$jumlah_key40_13hasil = 1 ; }else{$jumlah_key40_13hasil = 0 ;}		
if($jumlah_key40_14 > 0){$jumlah_key40_14hasil = 1 ; }else{$jumlah_key40_14hasil = 0 ;}		
if($jumlah_key40_15 > 0){$jumlah_key40_15hasil = 1 ; }else{$jumlah_key40_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '40', '$key40_1hasil', '$jumlah_key40_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_2hasil', '$jumlah_key40_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_3hasil', '$jumlah_key40_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_4hasil', '$jumlah_key40_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_5hasil', '$jumlah_key40_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_6hasil', '$jumlah_key40_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_7hasil', '$jumlah_key40_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_8hasil', '$jumlah_key40_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_9hasil', '$jumlah_key40_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_10hasil', '$jumlah_key40_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_11hasil', '$jumlah_key40_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_12hasil', '$jumlah_key40_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_13hasil', '$jumlah_key40_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_14hasil', '$jumlah_key40_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '40', '$key40_15hasil', '$jumlah_key40_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data41= mysqli_query($connect,"select * from tb_indikator where id_indikator='41'");		
	while($result41 = mysqli_fetch_array($data41)){	
	$indikator41 = $result41['indikator'];	
	$indikator_kecil41 = strtolower($indikator41);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator41 = str_replace($filter, '', $indikator_kecil41);	
	list($key41_1, $key41_2, $key41_3, $key41_4, $key41_5, $key41_6, $key41_7, $key41_8, $key41_9, $key41_10, $key41_11, $key41_12, $key41_13, $key41_14, $key41_15) = explode(' ', $filter_indikator41);	
		$jumlah_key41_1 = substr_count($source_code, $key41_1);
		$jumlah_key41_2 = substr_count($source_code, $key41_2);
		$jumlah_key41_3 = substr_count($source_code, $key41_3);
		$jumlah_key41_4 = substr_count($source_code, $key41_4);
		$jumlah_key41_5 = substr_count($source_code, $key41_5);
		$jumlah_key41_6 = substr_count($source_code, $key41_6);
		$jumlah_key41_7 = substr_count($source_code, $key41_7);
		$jumlah_key41_8 = substr_count($source_code, $key41_8);
		$jumlah_key41_9 = substr_count($source_code, $key41_9);
		$jumlah_key41_10 = substr_count($source_code, $key41_10);
		$jumlah_key41_11 = substr_count($source_code, $key41_11);
		$jumlah_key41_12 = substr_count($source_code, $key41_12);
		$jumlah_key41_13 = substr_count($source_code, $key41_13);
		$jumlah_key41_14 = substr_count($source_code, $key41_14);
		$jumlah_key41_15 = substr_count($source_code, $key41_15);
	    }	
		
if($jumlah_key41_1 > 0){$jumlah_key41_1hasil = 1 ; }else{$jumlah_key41_1hasil = 0 ;}		
if($jumlah_key41_2 > 0){$jumlah_key41_2hasil = 1 ; }else{$jumlah_key41_2hasil = 0 ;}		
if($jumlah_key41_3 > 0){$jumlah_key41_3hasil = 1 ; }else{$jumlah_key41_3hasil = 0 ;}		
if($jumlah_key41_4 > 0){$jumlah_key41_4hasil = 1 ; }else{$jumlah_key41_4hasil = 0 ;}		
if($jumlah_key41_5 > 0){$jumlah_key41_5hasil = 1 ; }else{$jumlah_key41_5hasil = 0 ;}		
if($jumlah_key41_6 > 0){$jumlah_key41_6hasil = 1 ; }else{$jumlah_key41_6hasil = 0 ;}		
if($jumlah_key41_7 > 0){$jumlah_key41_7hasil = 1 ; }else{$jumlah_key41_7hasil = 0 ;}		
if($jumlah_key41_8 > 0){$jumlah_key41_8hasil = 1 ; }else{$jumlah_key41_8hasil = 0 ;}		
if($jumlah_key41_9 > 0){$jumlah_key41_9hasil = 1 ; }else{$jumlah_key41_9hasil = 0 ;}		
if($jumlah_key41_10 > 0){$jumlah_key41_10hasil = 1 ; }else{$jumlah_key41_10hasil = 0 ;}		
if($jumlah_key41_11 > 0){$jumlah_key41_11hasil = 1 ; }else{$jumlah_key41_11hasil = 0 ;}		
if($jumlah_key41_12 > 0){$jumlah_key41_12hasil = 1 ; }else{$jumlah_key41_12hasil = 0 ;}		
if($jumlah_key41_13 > 0){$jumlah_key41_13hasil = 1 ; }else{$jumlah_key41_13hasil = 0 ;}		
if($jumlah_key41_14 > 0){$jumlah_key41_14hasil = 1 ; }else{$jumlah_key41_14hasil = 0 ;}		
if($jumlah_key41_15 > 0){$jumlah_key41_15hasil = 1 ; }else{$jumlah_key41_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '41', '$key41_1hasil', '$jumlah_key41_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_2hasil', '$jumlah_key41_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_3hasil', '$jumlah_key41_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_4hasil', '$jumlah_key41_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_5hasil', '$jumlah_key41_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_6hasil', '$jumlah_key41_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_7hasil', '$jumlah_key41_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_8hasil', '$jumlah_key41_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_9hasil', '$jumlah_key41_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_10hasil', '$jumlah_key41_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_11hasil', '$jumlah_key41_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_12hasil', '$jumlah_key41_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_13hasil', '$jumlah_key41_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_14hasil', '$jumlah_key41_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '41', '$key41_15hasil', '$jumlah_key41_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data42= mysqli_query($connect,"select * from tb_indikator where id_indikator='42'");		
	while($result42 = mysqli_fetch_array($data42)){	
	$indikator42 = $result42['indikator'];	
	$indikator_kecil42 = strtolower($indikator42);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator42 = str_replace($filter, '', $indikator_kecil42);	
	list($key42_1, $key42_2, $key42_3, $key42_4, $key42_5, $key42_6, $key42_7, $key42_8, $key42_9, $key42_10, $key42_11, $key42_12, $key42_13, $key42_14, $key42_15) = explode(' ', $filter_indikator42);	
		$jumlah_key42_1 = substr_count($source_code, $key42_1);
		$jumlah_key42_2 = substr_count($source_code, $key42_2);
		$jumlah_key42_3 = substr_count($source_code, $key42_3);
		$jumlah_key42_4 = substr_count($source_code, $key42_4);
		$jumlah_key42_5 = substr_count($source_code, $key42_5);
		$jumlah_key42_6 = substr_count($source_code, $key42_6);
		$jumlah_key42_7 = substr_count($source_code, $key42_7);
		$jumlah_key42_8 = substr_count($source_code, $key42_8);
		$jumlah_key42_9 = substr_count($source_code, $key42_9);
		$jumlah_key42_10 = substr_count($source_code, $key42_10);
		$jumlah_key42_11 = substr_count($source_code, $key42_11);
		$jumlah_key42_12 = substr_count($source_code, $key42_12);
		$jumlah_key42_13 = substr_count($source_code, $key42_13);
		$jumlah_key42_14 = substr_count($source_code, $key42_14);
		$jumlah_key42_15 = substr_count($source_code, $key42_15);
	    }	
		
if($jumlah_key42_1 > 0){$jumlah_key42_1hasil = 1 ; }else{$jumlah_key42_1hasil = 0 ;}		
if($jumlah_key42_2 > 0){$jumlah_key42_2hasil = 1 ; }else{$jumlah_key42_2hasil = 0 ;}		
if($jumlah_key42_3 > 0){$jumlah_key42_3hasil = 1 ; }else{$jumlah_key42_3hasil = 0 ;}		
if($jumlah_key42_4 > 0){$jumlah_key42_4hasil = 1 ; }else{$jumlah_key42_4hasil = 0 ;}		
if($jumlah_key42_5 > 0){$jumlah_key42_5hasil = 1 ; }else{$jumlah_key42_5hasil = 0 ;}		
if($jumlah_key42_6 > 0){$jumlah_key42_6hasil = 1 ; }else{$jumlah_key42_6hasil = 0 ;}		
if($jumlah_key42_7 > 0){$jumlah_key42_7hasil = 1 ; }else{$jumlah_key42_7hasil = 0 ;}		
if($jumlah_key42_8 > 0){$jumlah_key42_8hasil = 1 ; }else{$jumlah_key42_8hasil = 0 ;}		
if($jumlah_key42_9 > 0){$jumlah_key42_9hasil = 1 ; }else{$jumlah_key42_9hasil = 0 ;}		
if($jumlah_key42_10 > 0){$jumlah_key42_10hasil = 1 ; }else{$jumlah_key42_10hasil = 0 ;}		
if($jumlah_key42_11 > 0){$jumlah_key42_11hasil = 1 ; }else{$jumlah_key42_11hasil = 0 ;}		
if($jumlah_key42_12 > 0){$jumlah_key42_12hasil = 1 ; }else{$jumlah_key42_12hasil = 0 ;}		
if($jumlah_key42_13 > 0){$jumlah_key42_13hasil = 1 ; }else{$jumlah_key42_13hasil = 0 ;}		
if($jumlah_key42_14 > 0){$jumlah_key42_14hasil = 1 ; }else{$jumlah_key42_14hasil = 0 ;}		
if($jumlah_key42_15 > 0){$jumlah_key42_15hasil = 1 ; }else{$jumlah_key42_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '42', '$key42_1hasil', '$jumlah_key42_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_2hasil', '$jumlah_key42_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_3hasil', '$jumlah_key42_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_4hasil', '$jumlah_key42_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_5hasil', '$jumlah_key42_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_6hasil', '$jumlah_key42_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_7hasil', '$jumlah_key42_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_8hasil', '$jumlah_key42_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_9hasil', '$jumlah_key42_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_10hasil', '$jumlah_key42_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_11hasil', '$jumlah_key42_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_12hasil', '$jumlah_key42_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_13hasil', '$jumlah_key42_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_14hasil', '$jumlah_key42_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '42', '$key42_15hasil', '$jumlah_key42_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data43= mysqli_query($connect,"select * from tb_indikator where id_indikator='43'");		
	while($result43 = mysqli_fetch_array($data43)){	
	$indikator43 = $result43['indikator'];	
	$indikator_kecil43 = strtolower($indikator43);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator43 = str_replace($filter, '', $indikator_kecil43);	
	list($key43_1, $key43_2, $key43_3, $key43_4, $key43_5, $key43_6, $key43_7, $key43_8, $key43_9, $key43_10, $key43_11, $key43_12, $key43_13, $key43_14, $key43_15) = explode(' ', $filter_indikator43);	
		$jumlah_key43_1 = substr_count($source_code, $key43_1);
		$jumlah_key43_2 = substr_count($source_code, $key43_2);
		$jumlah_key43_3 = substr_count($source_code, $key43_3);
		$jumlah_key43_4 = substr_count($source_code, $key43_4);
		$jumlah_key43_5 = substr_count($source_code, $key43_5);
		$jumlah_key43_6 = substr_count($source_code, $key43_6);
		$jumlah_key43_7 = substr_count($source_code, $key43_7);
		$jumlah_key43_8 = substr_count($source_code, $key43_8);
		$jumlah_key43_9 = substr_count($source_code, $key43_9);
		$jumlah_key43_10 = substr_count($source_code, $key43_10);
		$jumlah_key43_11 = substr_count($source_code, $key43_11);
		$jumlah_key43_12 = substr_count($source_code, $key43_12);
		$jumlah_key43_13 = substr_count($source_code, $key43_13);
		$jumlah_key43_14 = substr_count($source_code, $key43_14);
		$jumlah_key43_15 = substr_count($source_code, $key43_15);
	    }	
		
if($jumlah_key43_1 > 0){$jumlah_key43_1hasil = 1 ; }else{$jumlah_key43_1hasil = 0 ;}		
if($jumlah_key43_2 > 0){$jumlah_key43_2hasil = 1 ; }else{$jumlah_key43_2hasil = 0 ;}		
if($jumlah_key43_3 > 0){$jumlah_key43_3hasil = 1 ; }else{$jumlah_key43_3hasil = 0 ;}		
if($jumlah_key43_4 > 0){$jumlah_key43_4hasil = 1 ; }else{$jumlah_key43_4hasil = 0 ;}		
if($jumlah_key43_5 > 0){$jumlah_key43_5hasil = 1 ; }else{$jumlah_key43_5hasil = 0 ;}		
if($jumlah_key43_6 > 0){$jumlah_key43_6hasil = 1 ; }else{$jumlah_key43_6hasil = 0 ;}		
if($jumlah_key43_7 > 0){$jumlah_key43_7hasil = 1 ; }else{$jumlah_key43_7hasil = 0 ;}		
if($jumlah_key43_8 > 0){$jumlah_key43_8hasil = 1 ; }else{$jumlah_key43_8hasil = 0 ;}		
if($jumlah_key43_9 > 0){$jumlah_key43_9hasil = 1 ; }else{$jumlah_key43_9hasil = 0 ;}		
if($jumlah_key43_10 > 0){$jumlah_key43_10hasil = 1 ; }else{$jumlah_key43_10hasil = 0 ;}		
if($jumlah_key43_11 > 0){$jumlah_key43_11hasil = 1 ; }else{$jumlah_key43_11hasil = 0 ;}		
if($jumlah_key43_12 > 0){$jumlah_key43_12hasil = 1 ; }else{$jumlah_key43_12hasil = 0 ;}		
if($jumlah_key43_13 > 0){$jumlah_key43_13hasil = 1 ; }else{$jumlah_key43_13hasil = 0 ;}		
if($jumlah_key43_14 > 0){$jumlah_key43_14hasil = 1 ; }else{$jumlah_key43_14hasil = 0 ;}		
if($jumlah_key43_15 > 0){$jumlah_key43_15hasil = 1 ; }else{$jumlah_key43_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '43', '$key43_1hasil', '$jumlah_key43_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_2hasil', '$jumlah_key43_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_3hasil', '$jumlah_key43_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_4hasil', '$jumlah_key43_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_5hasil', '$jumlah_key43_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_6hasil', '$jumlah_key43_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_7hasil', '$jumlah_key43_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_8hasil', '$jumlah_key43_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_9hasil', '$jumlah_key43_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_10hasil', '$jumlah_key43_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_11hasil', '$jumlah_key43_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_12hasil', '$jumlah_key43_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_13hasil', '$jumlah_key43_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_14hasil', '$jumlah_key43_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '43', '$key43_15hasil', '$jumlah_key43_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data44= mysqli_query($connect,"select * from tb_indikator where id_indikator='44'");		
	while($result44 = mysqli_fetch_array($data44)){	
	$indikator44 = $result44['indikator'];	
	$indikator_kecil44 = strtolower($indikator44);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator44 = str_replace($filter, '', $indikator_kecil44);	
	list($key44_1, $key44_2, $key44_3, $key44_4, $key44_5, $key44_6, $key44_7, $key44_8, $key44_9, $key44_10, $key44_11, $key44_12, $key44_13, $key44_14, $key44_15) = explode(' ', $filter_indikator44);	
		$jumlah_key44_1 = substr_count($source_code, $key44_1);
		$jumlah_key44_2 = substr_count($source_code, $key44_2);
		$jumlah_key44_3 = substr_count($source_code, $key44_3);
		$jumlah_key44_4 = substr_count($source_code, $key44_4);
		$jumlah_key44_5 = substr_count($source_code, $key44_5);
		$jumlah_key44_6 = substr_count($source_code, $key44_6);
		$jumlah_key44_7 = substr_count($source_code, $key44_7);
		$jumlah_key44_8 = substr_count($source_code, $key44_8);
		$jumlah_key44_9 = substr_count($source_code, $key44_9);
		$jumlah_key44_10 = substr_count($source_code, $key44_10);
		$jumlah_key44_11 = substr_count($source_code, $key44_11);
		$jumlah_key44_12 = substr_count($source_code, $key44_12);
		$jumlah_key44_13 = substr_count($source_code, $key44_13);
		$jumlah_key44_14 = substr_count($source_code, $key44_14);
		$jumlah_key44_15 = substr_count($source_code, $key44_15);
	    }	
		
if($jumlah_key44_1 > 0){$jumlah_key44_1hasil = 1 ; }else{$jumlah_key44_1hasil = 0 ;}		
if($jumlah_key44_2 > 0){$jumlah_key44_2hasil = 1 ; }else{$jumlah_key44_2hasil = 0 ;}		
if($jumlah_key44_3 > 0){$jumlah_key44_3hasil = 1 ; }else{$jumlah_key44_3hasil = 0 ;}		
if($jumlah_key44_4 > 0){$jumlah_key44_4hasil = 1 ; }else{$jumlah_key44_4hasil = 0 ;}		
if($jumlah_key44_5 > 0){$jumlah_key44_5hasil = 1 ; }else{$jumlah_key44_5hasil = 0 ;}		
if($jumlah_key44_6 > 0){$jumlah_key44_6hasil = 1 ; }else{$jumlah_key44_6hasil = 0 ;}		
if($jumlah_key44_7 > 0){$jumlah_key44_7hasil = 1 ; }else{$jumlah_key44_7hasil = 0 ;}		
if($jumlah_key44_8 > 0){$jumlah_key44_8hasil = 1 ; }else{$jumlah_key44_8hasil = 0 ;}		
if($jumlah_key44_9 > 0){$jumlah_key44_9hasil = 1 ; }else{$jumlah_key44_9hasil = 0 ;}		
if($jumlah_key44_10 > 0){$jumlah_key44_10hasil = 1 ; }else{$jumlah_key44_10hasil = 0 ;}		
if($jumlah_key44_11 > 0){$jumlah_key44_11hasil = 1 ; }else{$jumlah_key44_11hasil = 0 ;}		
if($jumlah_key44_12 > 0){$jumlah_key44_12hasil = 1 ; }else{$jumlah_key44_12hasil = 0 ;}		
if($jumlah_key44_13 > 0){$jumlah_key44_13hasil = 1 ; }else{$jumlah_key44_13hasil = 0 ;}		
if($jumlah_key44_14 > 0){$jumlah_key44_14hasil = 1 ; }else{$jumlah_key44_14hasil = 0 ;}		
if($jumlah_key44_15 > 0){$jumlah_key44_15hasil = 1 ; }else{$jumlah_key44_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '44', '$key44_1hasil', '$jumlah_key44_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_2hasil', '$jumlah_key44_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_3hasil', '$jumlah_key44_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_4hasil', '$jumlah_key44_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_5hasil', '$jumlah_key44_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_6hasil', '$jumlah_key44_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_7hasil', '$jumlah_key44_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_8hasil', '$jumlah_key44_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_9hasil', '$jumlah_key44_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_10hasil', '$jumlah_key44_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_11hasil', '$jumlah_key44_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_12hasil', '$jumlah_key44_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_13hasil', '$jumlah_key44_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_14hasil', '$jumlah_key44_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '44', '$key44_15hasil', '$jumlah_key44_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data45= mysqli_query($connect,"select * from tb_indikator where id_indikator='45'");		
	while($result45 = mysqli_fetch_array($data45)){	
	$indikator45 = $result45['indikator'];	
	$indikator_kecil45 = strtolower($indikator45);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator45 = str_replace($filter, '', $indikator_kecil45);	
	list($key45_1, $key45_2, $key45_3, $key45_4, $key45_5, $key45_6, $key45_7, $key45_8, $key45_9, $key45_10, $key45_11, $key45_12, $key45_13, $key45_14, $key45_15) = explode(' ', $filter_indikator45);	
		$jumlah_key45_1 = substr_count($source_code, $key45_1);
		$jumlah_key45_2 = substr_count($source_code, $key45_2);
		$jumlah_key45_3 = substr_count($source_code, $key45_3);
		$jumlah_key45_4 = substr_count($source_code, $key45_4);
		$jumlah_key45_5 = substr_count($source_code, $key45_5);
		$jumlah_key45_6 = substr_count($source_code, $key45_6);
		$jumlah_key45_7 = substr_count($source_code, $key45_7);
		$jumlah_key45_8 = substr_count($source_code, $key45_8);
		$jumlah_key45_9 = substr_count($source_code, $key45_9);
		$jumlah_key45_10 = substr_count($source_code, $key45_10);
		$jumlah_key45_11 = substr_count($source_code, $key45_11);
		$jumlah_key45_12 = substr_count($source_code, $key45_12);
		$jumlah_key45_13 = substr_count($source_code, $key45_13);
		$jumlah_key45_14 = substr_count($source_code, $key45_14);
		$jumlah_key45_15 = substr_count($source_code, $key45_15);
	    }	
		
if($jumlah_key45_1 > 0){$jumlah_key45_1hasil = 1 ; }else{$jumlah_key45_1hasil = 0 ;}		
if($jumlah_key45_2 > 0){$jumlah_key45_2hasil = 1 ; }else{$jumlah_key45_2hasil = 0 ;}		
if($jumlah_key45_3 > 0){$jumlah_key45_3hasil = 1 ; }else{$jumlah_key45_3hasil = 0 ;}		
if($jumlah_key45_4 > 0){$jumlah_key45_4hasil = 1 ; }else{$jumlah_key45_4hasil = 0 ;}		
if($jumlah_key45_5 > 0){$jumlah_key45_5hasil = 1 ; }else{$jumlah_key45_5hasil = 0 ;}		
if($jumlah_key45_6 > 0){$jumlah_key45_6hasil = 1 ; }else{$jumlah_key45_6hasil = 0 ;}		
if($jumlah_key45_7 > 0){$jumlah_key45_7hasil = 1 ; }else{$jumlah_key45_7hasil = 0 ;}		
if($jumlah_key45_8 > 0){$jumlah_key45_8hasil = 1 ; }else{$jumlah_key45_8hasil = 0 ;}		
if($jumlah_key45_9 > 0){$jumlah_key45_9hasil = 1 ; }else{$jumlah_key45_9hasil = 0 ;}		
if($jumlah_key45_10 > 0){$jumlah_key45_10hasil = 1 ; }else{$jumlah_key45_10hasil = 0 ;}		
if($jumlah_key45_11 > 0){$jumlah_key45_11hasil = 1 ; }else{$jumlah_key45_11hasil = 0 ;}		
if($jumlah_key45_12 > 0){$jumlah_key45_12hasil = 1 ; }else{$jumlah_key45_12hasil = 0 ;}		
if($jumlah_key45_13 > 0){$jumlah_key45_13hasil = 1 ; }else{$jumlah_key45_13hasil = 0 ;}		
if($jumlah_key45_14 > 0){$jumlah_key45_14hasil = 1 ; }else{$jumlah_key45_14hasil = 0 ;}		
if($jumlah_key45_15 > 0){$jumlah_key45_15hasil = 1 ; }else{$jumlah_key45_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '45', '$key45_1hasil', '$jumlah_key45_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_2hasil', '$jumlah_key45_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_3hasil', '$jumlah_key45_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_4hasil', '$jumlah_key45_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_5hasil', '$jumlah_key45_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_6hasil', '$jumlah_key45_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_7hasil', '$jumlah_key45_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_8hasil', '$jumlah_key45_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_9hasil', '$jumlah_key45_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_10hasil', '$jumlah_key45_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_11hasil', '$jumlah_key45_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_12hasil', '$jumlah_key45_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_13hasil', '$jumlah_key45_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_14hasil', '$jumlah_key45_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '45', '$key45_15hasil', '$jumlah_key45_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data46= mysqli_query($connect,"select * from tb_indikator where id_indikator='46'");		
	while($result46 = mysqli_fetch_array($data46)){	
	$indikator46 = $result46['indikator'];	
	$indikator_kecil46 = strtolower($indikator46);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator46 = str_replace($filter, '', $indikator_kecil46);	
	list($key46_1, $key46_2, $key46_3, $key46_4, $key46_5, $key46_6, $key46_7, $key46_8, $key46_9, $key46_10, $key46_11, $key46_12, $key46_13, $key46_14, $key46_15) = explode(' ', $filter_indikator46);	
		$jumlah_key46_1 = substr_count($source_code, $key46_1);
		$jumlah_key46_2 = substr_count($source_code, $key46_2);
		$jumlah_key46_3 = substr_count($source_code, $key46_3);
		$jumlah_key46_4 = substr_count($source_code, $key46_4);
		$jumlah_key46_5 = substr_count($source_code, $key46_5);
		$jumlah_key46_6 = substr_count($source_code, $key46_6);
		$jumlah_key46_7 = substr_count($source_code, $key46_7);
		$jumlah_key46_8 = substr_count($source_code, $key46_8);
		$jumlah_key46_9 = substr_count($source_code, $key46_9);
		$jumlah_key46_10 = substr_count($source_code, $key46_10);
		$jumlah_key46_11 = substr_count($source_code, $key46_11);
		$jumlah_key46_12 = substr_count($source_code, $key46_12);
		$jumlah_key46_13 = substr_count($source_code, $key46_13);
		$jumlah_key46_14 = substr_count($source_code, $key46_14);
		$jumlah_key46_15 = substr_count($source_code, $key46_15);
	    }	
		
if($jumlah_key46_1 > 0){$jumlah_key46_1hasil = 1 ; }else{$jumlah_key46_1hasil = 0 ;}		
if($jumlah_key46_2 > 0){$jumlah_key46_2hasil = 1 ; }else{$jumlah_key46_2hasil = 0 ;}		
if($jumlah_key46_3 > 0){$jumlah_key46_3hasil = 1 ; }else{$jumlah_key46_3hasil = 0 ;}		
if($jumlah_key46_4 > 0){$jumlah_key46_4hasil = 1 ; }else{$jumlah_key46_4hasil = 0 ;}		
if($jumlah_key46_5 > 0){$jumlah_key46_5hasil = 1 ; }else{$jumlah_key46_5hasil = 0 ;}		
if($jumlah_key46_6 > 0){$jumlah_key46_6hasil = 1 ; }else{$jumlah_key46_6hasil = 0 ;}		
if($jumlah_key46_7 > 0){$jumlah_key46_7hasil = 1 ; }else{$jumlah_key46_7hasil = 0 ;}		
if($jumlah_key46_8 > 0){$jumlah_key46_8hasil = 1 ; }else{$jumlah_key46_8hasil = 0 ;}		
if($jumlah_key46_9 > 0){$jumlah_key46_9hasil = 1 ; }else{$jumlah_key46_9hasil = 0 ;}		
if($jumlah_key46_10 > 0){$jumlah_key46_10hasil = 1 ; }else{$jumlah_key46_10hasil = 0 ;}		
if($jumlah_key46_11 > 0){$jumlah_key46_11hasil = 1 ; }else{$jumlah_key46_11hasil = 0 ;}		
if($jumlah_key46_12 > 0){$jumlah_key46_12hasil = 1 ; }else{$jumlah_key46_12hasil = 0 ;}		
if($jumlah_key46_13 > 0){$jumlah_key46_13hasil = 1 ; }else{$jumlah_key46_13hasil = 0 ;}		
if($jumlah_key46_14 > 0){$jumlah_key46_14hasil = 1 ; }else{$jumlah_key46_14hasil = 0 ;}		
if($jumlah_key46_15 > 0){$jumlah_key46_15hasil = 1 ; }else{$jumlah_key46_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '46', '$key46_1hasil', '$jumlah_key46_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_2hasil', '$jumlah_key46_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_3hasil', '$jumlah_key46_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_4hasil', '$jumlah_key46_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_5hasil', '$jumlah_key46_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_6hasil', '$jumlah_key46_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_7hasil', '$jumlah_key46_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_8hasil', '$jumlah_key46_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_9hasil', '$jumlah_key46_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_10hasil', '$jumlah_key46_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_11hasil', '$jumlah_key46_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_12hasil', '$jumlah_key46_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_13hasil', '$jumlah_key46_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_14hasil', '$jumlah_key46_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '46', '$key46_15hasil', '$jumlah_key46_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data47= mysqli_query($connect,"select * from tb_indikator where id_indikator='47'");		
	while($result47 = mysqli_fetch_array($data47)){	
	$indikator47 = $result47['indikator'];	
	$indikator_kecil47 = strtolower($indikator47);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator47 = str_replace($filter, '', $indikator_kecil47);	
	list($key47_1, $key47_2, $key47_3, $key47_4, $key47_5, $key47_6, $key47_7, $key47_8, $key47_9, $key47_10, $key47_11, $key47_12, $key47_13, $key47_14, $key47_15) = explode(' ', $filter_indikator47);	
		$jumlah_key47_1 = substr_count($source_code, $key47_1);
		$jumlah_key47_2 = substr_count($source_code, $key47_2);
		$jumlah_key47_3 = substr_count($source_code, $key47_3);
		$jumlah_key47_4 = substr_count($source_code, $key47_4);
		$jumlah_key47_5 = substr_count($source_code, $key47_5);
		$jumlah_key47_6 = substr_count($source_code, $key47_6);
		$jumlah_key47_7 = substr_count($source_code, $key47_7);
		$jumlah_key47_8 = substr_count($source_code, $key47_8);
		$jumlah_key47_9 = substr_count($source_code, $key47_9);
		$jumlah_key47_10 = substr_count($source_code, $key47_10);
		$jumlah_key47_11 = substr_count($source_code, $key47_11);
		$jumlah_key47_12 = substr_count($source_code, $key47_12);
		$jumlah_key47_13 = substr_count($source_code, $key47_13);
		$jumlah_key47_14 = substr_count($source_code, $key47_14);
		$jumlah_key47_15 = substr_count($source_code, $key47_15);
	    }	
		
if($jumlah_key47_1 > 0){$jumlah_key47_1hasil = 1 ; }else{$jumlah_key47_1hasil = 0 ;}		
if($jumlah_key47_2 > 0){$jumlah_key47_2hasil = 1 ; }else{$jumlah_key47_2hasil = 0 ;}		
if($jumlah_key47_3 > 0){$jumlah_key47_3hasil = 1 ; }else{$jumlah_key47_3hasil = 0 ;}		
if($jumlah_key47_4 > 0){$jumlah_key47_4hasil = 1 ; }else{$jumlah_key47_4hasil = 0 ;}		
if($jumlah_key47_5 > 0){$jumlah_key47_5hasil = 1 ; }else{$jumlah_key47_5hasil = 0 ;}		
if($jumlah_key47_6 > 0){$jumlah_key47_6hasil = 1 ; }else{$jumlah_key47_6hasil = 0 ;}		
if($jumlah_key47_7 > 0){$jumlah_key47_7hasil = 1 ; }else{$jumlah_key47_7hasil = 0 ;}		
if($jumlah_key47_8 > 0){$jumlah_key47_8hasil = 1 ; }else{$jumlah_key47_8hasil = 0 ;}		
if($jumlah_key47_9 > 0){$jumlah_key47_9hasil = 1 ; }else{$jumlah_key47_9hasil = 0 ;}		
if($jumlah_key47_10 > 0){$jumlah_key47_10hasil = 1 ; }else{$jumlah_key47_10hasil = 0 ;}		
if($jumlah_key47_11 > 0){$jumlah_key47_11hasil = 1 ; }else{$jumlah_key47_11hasil = 0 ;}		
if($jumlah_key47_12 > 0){$jumlah_key47_12hasil = 1 ; }else{$jumlah_key47_12hasil = 0 ;}		
if($jumlah_key47_13 > 0){$jumlah_key47_13hasil = 1 ; }else{$jumlah_key47_13hasil = 0 ;}		
if($jumlah_key47_14 > 0){$jumlah_key47_14hasil = 1 ; }else{$jumlah_key47_14hasil = 0 ;}		
if($jumlah_key47_15 > 0){$jumlah_key47_15hasil = 1 ; }else{$jumlah_key47_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '47', '$key47_1hasil', '$jumlah_key47_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_2hasil', '$jumlah_key47_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_3hasil', '$jumlah_key47_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_4hasil', '$jumlah_key47_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_5hasil', '$jumlah_key47_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_6hasil', '$jumlah_key47_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_7hasil', '$jumlah_key47_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_8hasil', '$jumlah_key47_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_9hasil', '$jumlah_key47_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_10hasil', '$jumlah_key47_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_11hasil', '$jumlah_key47_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_12hasil', '$jumlah_key47_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_13hasil', '$jumlah_key47_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_14hasil', '$jumlah_key47_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '47', '$key47_15hasil', '$jumlah_key47_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data48= mysqli_query($connect,"select * from tb_indikator where id_indikator='48'");		
	while($result48 = mysqli_fetch_array($data48)){	
	$indikator48 = $result48['indikator'];	
	$indikator_kecil48 = strtolower($indikator48);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator48 = str_replace($filter, '', $indikator_kecil48);	
	list($key48_1, $key48_2, $key48_3, $key48_4, $key48_5, $key48_6, $key48_7, $key48_8, $key48_9, $key48_10, $key48_11, $key48_12, $key48_13, $key48_14, $key48_15) = explode(' ', $filter_indikator48);	
		$jumlah_key48_1 = substr_count($source_code, $key48_1);
		$jumlah_key48_2 = substr_count($source_code, $key48_2);
		$jumlah_key48_3 = substr_count($source_code, $key48_3);
		$jumlah_key48_4 = substr_count($source_code, $key48_4);
		$jumlah_key48_5 = substr_count($source_code, $key48_5);
		$jumlah_key48_6 = substr_count($source_code, $key48_6);
		$jumlah_key48_7 = substr_count($source_code, $key48_7);
		$jumlah_key48_8 = substr_count($source_code, $key48_8);
		$jumlah_key48_9 = substr_count($source_code, $key48_9);
		$jumlah_key48_10 = substr_count($source_code, $key48_10);
		$jumlah_key48_11 = substr_count($source_code, $key48_11);
		$jumlah_key48_12 = substr_count($source_code, $key48_12);
		$jumlah_key48_13 = substr_count($source_code, $key48_13);
		$jumlah_key48_14 = substr_count($source_code, $key48_14);
		$jumlah_key48_15 = substr_count($source_code, $key48_15);
	    }	
		
if($jumlah_key48_1 > 0){$jumlah_key48_1hasil = 1 ; }else{$jumlah_key48_1hasil = 0 ;}		
if($jumlah_key48_2 > 0){$jumlah_key48_2hasil = 1 ; }else{$jumlah_key48_2hasil = 0 ;}		
if($jumlah_key48_3 > 0){$jumlah_key48_3hasil = 1 ; }else{$jumlah_key48_3hasil = 0 ;}		
if($jumlah_key48_4 > 0){$jumlah_key48_4hasil = 1 ; }else{$jumlah_key48_4hasil = 0 ;}		
if($jumlah_key48_5 > 0){$jumlah_key48_5hasil = 1 ; }else{$jumlah_key48_5hasil = 0 ;}		
if($jumlah_key48_6 > 0){$jumlah_key48_6hasil = 1 ; }else{$jumlah_key48_6hasil = 0 ;}		
if($jumlah_key48_7 > 0){$jumlah_key48_7hasil = 1 ; }else{$jumlah_key48_7hasil = 0 ;}		
if($jumlah_key48_8 > 0){$jumlah_key48_8hasil = 1 ; }else{$jumlah_key48_8hasil = 0 ;}		
if($jumlah_key48_9 > 0){$jumlah_key48_9hasil = 1 ; }else{$jumlah_key48_9hasil = 0 ;}		
if($jumlah_key48_10 > 0){$jumlah_key48_10hasil = 1 ; }else{$jumlah_key48_10hasil = 0 ;}		
if($jumlah_key48_11 > 0){$jumlah_key48_11hasil = 1 ; }else{$jumlah_key48_11hasil = 0 ;}		
if($jumlah_key48_12 > 0){$jumlah_key48_12hasil = 1 ; }else{$jumlah_key48_12hasil = 0 ;}		
if($jumlah_key48_13 > 0){$jumlah_key48_13hasil = 1 ; }else{$jumlah_key48_13hasil = 0 ;}		
if($jumlah_key48_14 > 0){$jumlah_key48_14hasil = 1 ; }else{$jumlah_key48_14hasil = 0 ;}		
if($jumlah_key48_15 > 0){$jumlah_key48_15hasil = 1 ; }else{$jumlah_key48_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '48', '$key48_1hasil', '$jumlah_key48_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_2hasil', '$jumlah_key48_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_3hasil', '$jumlah_key48_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_4hasil', '$jumlah_key48_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_5hasil', '$jumlah_key48_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_6hasil', '$jumlah_key48_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_7hasil', '$jumlah_key48_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_8hasil', '$jumlah_key48_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_9hasil', '$jumlah_key48_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_10hasil', '$jumlah_key48_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_11hasil', '$jumlah_key48_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_12hasil', '$jumlah_key48_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_13hasil', '$jumlah_key48_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_14hasil', '$jumlah_key48_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '48', '$key48_15hasil', '$jumlah_key48_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data49= mysqli_query($connect,"select * from tb_indikator where id_indikator='49'");		
	while($result49 = mysqli_fetch_array($data49)){	
	$indikator49 = $result49['indikator'];	
	$indikator_kecil49 = strtolower($indikator49);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator49 = str_replace($filter, '', $indikator_kecil49);	
	list($key49_1, $key49_2, $key49_3, $key49_4, $key49_5, $key49_6, $key49_7, $key49_8, $key49_9, $key49_10, $key49_11, $key49_12, $key49_13, $key49_14, $key49_15) = explode(' ', $filter_indikator49);	
		$jumlah_key49_1 = substr_count($source_code, $key49_1);
		$jumlah_key49_2 = substr_count($source_code, $key49_2);
		$jumlah_key49_3 = substr_count($source_code, $key49_3);
		$jumlah_key49_4 = substr_count($source_code, $key49_4);
		$jumlah_key49_5 = substr_count($source_code, $key49_5);
		$jumlah_key49_6 = substr_count($source_code, $key49_6);
		$jumlah_key49_7 = substr_count($source_code, $key49_7);
		$jumlah_key49_8 = substr_count($source_code, $key49_8);
		$jumlah_key49_9 = substr_count($source_code, $key49_9);
		$jumlah_key49_10 = substr_count($source_code, $key49_10);
		$jumlah_key49_11 = substr_count($source_code, $key49_11);
		$jumlah_key49_12 = substr_count($source_code, $key49_12);
		$jumlah_key49_13 = substr_count($source_code, $key49_13);
		$jumlah_key49_14 = substr_count($source_code, $key49_14);
		$jumlah_key49_15 = substr_count($source_code, $key49_15);
	    }	
		
if($jumlah_key49_1 > 0){$jumlah_key49_1hasil = 1 ; }else{$jumlah_key49_1hasil = 0 ;}		
if($jumlah_key49_2 > 0){$jumlah_key49_2hasil = 1 ; }else{$jumlah_key49_2hasil = 0 ;}		
if($jumlah_key49_3 > 0){$jumlah_key49_3hasil = 1 ; }else{$jumlah_key49_3hasil = 0 ;}		
if($jumlah_key49_4 > 0){$jumlah_key49_4hasil = 1 ; }else{$jumlah_key49_4hasil = 0 ;}		
if($jumlah_key49_5 > 0){$jumlah_key49_5hasil = 1 ; }else{$jumlah_key49_5hasil = 0 ;}		
if($jumlah_key49_6 > 0){$jumlah_key49_6hasil = 1 ; }else{$jumlah_key49_6hasil = 0 ;}		
if($jumlah_key49_7 > 0){$jumlah_key49_7hasil = 1 ; }else{$jumlah_key49_7hasil = 0 ;}		
if($jumlah_key49_8 > 0){$jumlah_key49_8hasil = 1 ; }else{$jumlah_key49_8hasil = 0 ;}		
if($jumlah_key49_9 > 0){$jumlah_key49_9hasil = 1 ; }else{$jumlah_key49_9hasil = 0 ;}		
if($jumlah_key49_10 > 0){$jumlah_key49_10hasil = 1 ; }else{$jumlah_key49_10hasil = 0 ;}		
if($jumlah_key49_11 > 0){$jumlah_key49_11hasil = 1 ; }else{$jumlah_key49_11hasil = 0 ;}		
if($jumlah_key49_12 > 0){$jumlah_key49_12hasil = 1 ; }else{$jumlah_key49_12hasil = 0 ;}		
if($jumlah_key49_13 > 0){$jumlah_key49_13hasil = 1 ; }else{$jumlah_key49_13hasil = 0 ;}		
if($jumlah_key49_14 > 0){$jumlah_key49_14hasil = 1 ; }else{$jumlah_key49_14hasil = 0 ;}		
if($jumlah_key49_15 > 0){$jumlah_key49_15hasil = 1 ; }else{$jumlah_key49_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '49', '$key49_1hasil', '$jumlah_key49_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_2hasil', '$jumlah_key49_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_3hasil', '$jumlah_key49_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_4hasil', '$jumlah_key49_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_5hasil', '$jumlah_key49_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_6hasil', '$jumlah_key49_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_7hasil', '$jumlah_key49_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_8hasil', '$jumlah_key49_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_9hasil', '$jumlah_key49_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_10hasil', '$jumlah_key49_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_11hasil', '$jumlah_key49_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_12hasil', '$jumlah_key49_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_13hasil', '$jumlah_key49_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_14hasil', '$jumlah_key49_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '49', '$key49_15hasil', '$jumlah_key49_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data50= mysqli_query($connect,"select * from tb_indikator where id_indikator='50'");		
	while($result50 = mysqli_fetch_array($data50)){	
	$indikator50 = $result50['indikator'];	
	$indikator_kecil50 = strtolower($indikator50);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator50 = str_replace($filter, '', $indikator_kecil50);	
	list($key50_1, $key50_2, $key50_3, $key50_4, $key50_5, $key50_6, $key50_7, $key50_8, $key50_9, $key50_10, $key50_11, $key50_12, $key50_13, $key50_14, $key50_15) = explode(' ', $filter_indikator50);	
		$jumlah_key50_1 = substr_count($source_code, $key50_1);
		$jumlah_key50_2 = substr_count($source_code, $key50_2);
		$jumlah_key50_3 = substr_count($source_code, $key50_3);
		$jumlah_key50_4 = substr_count($source_code, $key50_4);
		$jumlah_key50_5 = substr_count($source_code, $key50_5);
		$jumlah_key50_6 = substr_count($source_code, $key50_6);
		$jumlah_key50_7 = substr_count($source_code, $key50_7);
		$jumlah_key50_8 = substr_count($source_code, $key50_8);
		$jumlah_key50_9 = substr_count($source_code, $key50_9);
		$jumlah_key50_10 = substr_count($source_code, $key50_10);
		$jumlah_key50_11 = substr_count($source_code, $key50_11);
		$jumlah_key50_12 = substr_count($source_code, $key50_12);
		$jumlah_key50_13 = substr_count($source_code, $key50_13);
		$jumlah_key50_14 = substr_count($source_code, $key50_14);
		$jumlah_key50_15 = substr_count($source_code, $key50_15);
	    }	
		
if($jumlah_key50_1 > 0){$jumlah_key50_1hasil = 1 ; }else{$jumlah_key50_1hasil = 0 ;}		
if($jumlah_key50_2 > 0){$jumlah_key50_2hasil = 1 ; }else{$jumlah_key50_2hasil = 0 ;}		
if($jumlah_key50_3 > 0){$jumlah_key50_3hasil = 1 ; }else{$jumlah_key50_3hasil = 0 ;}		
if($jumlah_key50_4 > 0){$jumlah_key50_4hasil = 1 ; }else{$jumlah_key50_4hasil = 0 ;}		
if($jumlah_key50_5 > 0){$jumlah_key50_5hasil = 1 ; }else{$jumlah_key50_5hasil = 0 ;}		
if($jumlah_key50_6 > 0){$jumlah_key50_6hasil = 1 ; }else{$jumlah_key50_6hasil = 0 ;}		
if($jumlah_key50_7 > 0){$jumlah_key50_7hasil = 1 ; }else{$jumlah_key50_7hasil = 0 ;}		
if($jumlah_key50_8 > 0){$jumlah_key50_8hasil = 1 ; }else{$jumlah_key50_8hasil = 0 ;}		
if($jumlah_key50_9 > 0){$jumlah_key50_9hasil = 1 ; }else{$jumlah_key50_9hasil = 0 ;}		
if($jumlah_key50_10 > 0){$jumlah_key50_10hasil = 1 ; }else{$jumlah_key50_10hasil = 0 ;}		
if($jumlah_key50_11 > 0){$jumlah_key50_11hasil = 1 ; }else{$jumlah_key50_11hasil = 0 ;}		
if($jumlah_key50_12 > 0){$jumlah_key50_12hasil = 1 ; }else{$jumlah_key50_12hasil = 0 ;}		
if($jumlah_key50_13 > 0){$jumlah_key50_13hasil = 1 ; }else{$jumlah_key50_13hasil = 0 ;}		
if($jumlah_key50_14 > 0){$jumlah_key50_14hasil = 1 ; }else{$jumlah_key50_14hasil = 0 ;}		
if($jumlah_key50_15 > 0){$jumlah_key50_15hasil = 1 ; }else{$jumlah_key50_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '50', '$key50_1hasil', '$jumlah_key50_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_2hasil', '$jumlah_key50_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_3hasil', '$jumlah_key50_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_4hasil', '$jumlah_key50_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_5hasil', '$jumlah_key50_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_6hasil', '$jumlah_key50_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_7hasil', '$jumlah_key50_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_8hasil', '$jumlah_key50_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_9hasil', '$jumlah_key50_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_10hasil', '$jumlah_key50_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_11hasil', '$jumlah_key50_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_12hasil', '$jumlah_key50_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_13hasil', '$jumlah_key50_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_14hasil', '$jumlah_key50_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '50', '$key50_15hasil', '$jumlah_key50_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data51= mysqli_query($connect,"select * from tb_indikator where id_indikator='51'");		
	while($result51 = mysqli_fetch_array($data51)){	
	$indikator51 = $result51['indikator'];	
	$indikator_kecil51 = strtolower($indikator51);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator51 = str_replace($filter, '', $indikator_kecil51);	
	list($key51_1, $key51_2, $key51_3, $key51_4, $key51_5, $key51_6, $key51_7, $key51_8, $key51_9, $key51_10, $key51_11, $key51_12, $key51_13, $key51_14, $key51_15) = explode(' ', $filter_indikator51);	
		$jumlah_key51_1 = substr_count($source_code, $key51_1);
		$jumlah_key51_2 = substr_count($source_code, $key51_2);
		$jumlah_key51_3 = substr_count($source_code, $key51_3);
		$jumlah_key51_4 = substr_count($source_code, $key51_4);
		$jumlah_key51_5 = substr_count($source_code, $key51_5);
		$jumlah_key51_6 = substr_count($source_code, $key51_6);
		$jumlah_key51_7 = substr_count($source_code, $key51_7);
		$jumlah_key51_8 = substr_count($source_code, $key51_8);
		$jumlah_key51_9 = substr_count($source_code, $key51_9);
		$jumlah_key51_10 = substr_count($source_code, $key51_10);
		$jumlah_key51_11 = substr_count($source_code, $key51_11);
		$jumlah_key51_12 = substr_count($source_code, $key51_12);
		$jumlah_key51_13 = substr_count($source_code, $key51_13);
		$jumlah_key51_14 = substr_count($source_code, $key51_14);
		$jumlah_key51_15 = substr_count($source_code, $key51_15);
	    }	
		
if($jumlah_key51_1 > 0){$jumlah_key51_1hasil = 1 ; }else{$jumlah_key51_1hasil = 0 ;}		
if($jumlah_key51_2 > 0){$jumlah_key51_2hasil = 1 ; }else{$jumlah_key51_2hasil = 0 ;}		
if($jumlah_key51_3 > 0){$jumlah_key51_3hasil = 1 ; }else{$jumlah_key51_3hasil = 0 ;}		
if($jumlah_key51_4 > 0){$jumlah_key51_4hasil = 1 ; }else{$jumlah_key51_4hasil = 0 ;}		
if($jumlah_key51_5 > 0){$jumlah_key51_5hasil = 1 ; }else{$jumlah_key51_5hasil = 0 ;}		
if($jumlah_key51_6 > 0){$jumlah_key51_6hasil = 1 ; }else{$jumlah_key51_6hasil = 0 ;}		
if($jumlah_key51_7 > 0){$jumlah_key51_7hasil = 1 ; }else{$jumlah_key51_7hasil = 0 ;}		
if($jumlah_key51_8 > 0){$jumlah_key51_8hasil = 1 ; }else{$jumlah_key51_8hasil = 0 ;}		
if($jumlah_key51_9 > 0){$jumlah_key51_9hasil = 1 ; }else{$jumlah_key51_9hasil = 0 ;}		
if($jumlah_key51_10 > 0){$jumlah_key51_10hasil = 1 ; }else{$jumlah_key51_10hasil = 0 ;}		
if($jumlah_key51_11 > 0){$jumlah_key51_11hasil = 1 ; }else{$jumlah_key51_11hasil = 0 ;}		
if($jumlah_key51_12 > 0){$jumlah_key51_12hasil = 1 ; }else{$jumlah_key51_12hasil = 0 ;}		
if($jumlah_key51_13 > 0){$jumlah_key51_13hasil = 1 ; }else{$jumlah_key51_13hasil = 0 ;}		
if($jumlah_key51_14 > 0){$jumlah_key51_14hasil = 1 ; }else{$jumlah_key51_14hasil = 0 ;}		
if($jumlah_key51_15 > 0){$jumlah_key51_15hasil = 1 ; }else{$jumlah_key51_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '51', '$key51_1hasil', '$jumlah_key51_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_2hasil', '$jumlah_key51_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_3hasil', '$jumlah_key51_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_4hasil', '$jumlah_key51_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_5hasil', '$jumlah_key51_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_6hasil', '$jumlah_key51_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_7hasil', '$jumlah_key51_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_8hasil', '$jumlah_key51_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_9hasil', '$jumlah_key51_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_10hasil', '$jumlah_key51_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_11hasil', '$jumlah_key51_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_12hasil', '$jumlah_key51_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_13hasil', '$jumlah_key51_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_14hasil', '$jumlah_key51_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '51', '$key51_15hasil', '$jumlah_key51_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data52= mysqli_query($connect,"select * from tb_indikator where id_indikator='52'");		
	while($result52 = mysqli_fetch_array($data52)){	
	$indikator52 = $result52['indikator'];	
	$indikator_kecil52 = strtolower($indikator52);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator52 = str_replace($filter, '', $indikator_kecil52);	
	list($key52_1, $key52_2, $key52_3, $key52_4, $key52_5, $key52_6, $key52_7, $key52_8, $key52_9, $key52_10, $key52_11, $key52_12, $key52_13, $key52_14, $key52_15) = explode(' ', $filter_indikator52);	
		$jumlah_key52_1 = substr_count($source_code, $key52_1);
		$jumlah_key52_2 = substr_count($source_code, $key52_2);
		$jumlah_key52_3 = substr_count($source_code, $key52_3);
		$jumlah_key52_4 = substr_count($source_code, $key52_4);
		$jumlah_key52_5 = substr_count($source_code, $key52_5);
		$jumlah_key52_6 = substr_count($source_code, $key52_6);
		$jumlah_key52_7 = substr_count($source_code, $key52_7);
		$jumlah_key52_8 = substr_count($source_code, $key52_8);
		$jumlah_key52_9 = substr_count($source_code, $key52_9);
		$jumlah_key52_10 = substr_count($source_code, $key52_10);
		$jumlah_key52_11 = substr_count($source_code, $key52_11);
		$jumlah_key52_12 = substr_count($source_code, $key52_12);
		$jumlah_key52_13 = substr_count($source_code, $key52_13);
		$jumlah_key52_14 = substr_count($source_code, $key52_14);
		$jumlah_key52_15 = substr_count($source_code, $key52_15);
	    }	
		
if($jumlah_key52_1 > 0){$jumlah_key52_1hasil = 1 ; }else{$jumlah_key52_1hasil = 0 ;}		
if($jumlah_key52_2 > 0){$jumlah_key52_2hasil = 1 ; }else{$jumlah_key52_2hasil = 0 ;}		
if($jumlah_key52_3 > 0){$jumlah_key52_3hasil = 1 ; }else{$jumlah_key52_3hasil = 0 ;}		
if($jumlah_key52_4 > 0){$jumlah_key52_4hasil = 1 ; }else{$jumlah_key52_4hasil = 0 ;}		
if($jumlah_key52_5 > 0){$jumlah_key52_5hasil = 1 ; }else{$jumlah_key52_5hasil = 0 ;}		
if($jumlah_key52_6 > 0){$jumlah_key52_6hasil = 1 ; }else{$jumlah_key52_6hasil = 0 ;}		
if($jumlah_key52_7 > 0){$jumlah_key52_7hasil = 1 ; }else{$jumlah_key52_7hasil = 0 ;}		
if($jumlah_key52_8 > 0){$jumlah_key52_8hasil = 1 ; }else{$jumlah_key52_8hasil = 0 ;}		
if($jumlah_key52_9 > 0){$jumlah_key52_9hasil = 1 ; }else{$jumlah_key52_9hasil = 0 ;}		
if($jumlah_key52_10 > 0){$jumlah_key52_10hasil = 1 ; }else{$jumlah_key52_10hasil = 0 ;}		
if($jumlah_key52_11 > 0){$jumlah_key52_11hasil = 1 ; }else{$jumlah_key52_11hasil = 0 ;}		
if($jumlah_key52_12 > 0){$jumlah_key52_12hasil = 1 ; }else{$jumlah_key52_12hasil = 0 ;}		
if($jumlah_key52_13 > 0){$jumlah_key52_13hasil = 1 ; }else{$jumlah_key52_13hasil = 0 ;}		
if($jumlah_key52_14 > 0){$jumlah_key52_14hasil = 1 ; }else{$jumlah_key52_14hasil = 0 ;}		
if($jumlah_key52_15 > 0){$jumlah_key52_15hasil = 1 ; }else{$jumlah_key52_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '52', '$key52_1hasil', '$jumlah_key52_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_2hasil', '$jumlah_key52_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_3hasil', '$jumlah_key52_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_4hasil', '$jumlah_key52_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_5hasil', '$jumlah_key52_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_6hasil', '$jumlah_key52_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_7hasil', '$jumlah_key52_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_8hasil', '$jumlah_key52_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_9hasil', '$jumlah_key52_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_10hasil', '$jumlah_key52_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_11hasil', '$jumlah_key52_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_12hasil', '$jumlah_key52_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_13hasil', '$jumlah_key52_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_14hasil', '$jumlah_key52_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '52', '$key52_15hasil', '$jumlah_key52_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data53= mysqli_query($connect,"select * from tb_indikator where id_indikator='53'");		
	while($result53 = mysqli_fetch_array($data53)){	
	$indikator53 = $result53['indikator'];	
	$indikator_kecil53 = strtolower($indikator53);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator53 = str_replace($filter, '', $indikator_kecil53);	
	list($key53_1, $key53_2, $key53_3, $key53_4, $key53_5, $key53_6, $key53_7, $key53_8, $key53_9, $key53_10, $key53_11, $key53_12, $key53_13, $key53_14, $key53_15) = explode(' ', $filter_indikator53);	
		$jumlah_key53_1 = substr_count($source_code, $key53_1);
		$jumlah_key53_2 = substr_count($source_code, $key53_2);
		$jumlah_key53_3 = substr_count($source_code, $key53_3);
		$jumlah_key53_4 = substr_count($source_code, $key53_4);
		$jumlah_key53_5 = substr_count($source_code, $key53_5);
		$jumlah_key53_6 = substr_count($source_code, $key53_6);
		$jumlah_key53_7 = substr_count($source_code, $key53_7);
		$jumlah_key53_8 = substr_count($source_code, $key53_8);
		$jumlah_key53_9 = substr_count($source_code, $key53_9);
		$jumlah_key53_10 = substr_count($source_code, $key53_10);
		$jumlah_key53_11 = substr_count($source_code, $key53_11);
		$jumlah_key53_12 = substr_count($source_code, $key53_12);
		$jumlah_key53_13 = substr_count($source_code, $key53_13);
		$jumlah_key53_14 = substr_count($source_code, $key53_14);
		$jumlah_key53_15 = substr_count($source_code, $key53_15);
	    }	
		
if($jumlah_key53_1 > 0){$jumlah_key53_1hasil = 1 ; }else{$jumlah_key53_1hasil = 0 ;}		
if($jumlah_key53_2 > 0){$jumlah_key53_2hasil = 1 ; }else{$jumlah_key53_2hasil = 0 ;}		
if($jumlah_key53_3 > 0){$jumlah_key53_3hasil = 1 ; }else{$jumlah_key53_3hasil = 0 ;}		
if($jumlah_key53_4 > 0){$jumlah_key53_4hasil = 1 ; }else{$jumlah_key53_4hasil = 0 ;}		
if($jumlah_key53_5 > 0){$jumlah_key53_5hasil = 1 ; }else{$jumlah_key53_5hasil = 0 ;}		
if($jumlah_key53_6 > 0){$jumlah_key53_6hasil = 1 ; }else{$jumlah_key53_6hasil = 0 ;}		
if($jumlah_key53_7 > 0){$jumlah_key53_7hasil = 1 ; }else{$jumlah_key53_7hasil = 0 ;}		
if($jumlah_key53_8 > 0){$jumlah_key53_8hasil = 1 ; }else{$jumlah_key53_8hasil = 0 ;}		
if($jumlah_key53_9 > 0){$jumlah_key53_9hasil = 1 ; }else{$jumlah_key53_9hasil = 0 ;}		
if($jumlah_key53_10 > 0){$jumlah_key53_10hasil = 1 ; }else{$jumlah_key53_10hasil = 0 ;}		
if($jumlah_key53_11 > 0){$jumlah_key53_11hasil = 1 ; }else{$jumlah_key53_11hasil = 0 ;}		
if($jumlah_key53_12 > 0){$jumlah_key53_12hasil = 1 ; }else{$jumlah_key53_12hasil = 0 ;}		
if($jumlah_key53_13 > 0){$jumlah_key53_13hasil = 1 ; }else{$jumlah_key53_13hasil = 0 ;}		
if($jumlah_key53_14 > 0){$jumlah_key53_14hasil = 1 ; }else{$jumlah_key53_14hasil = 0 ;}		
if($jumlah_key53_15 > 0){$jumlah_key53_15hasil = 1 ; }else{$jumlah_key53_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '53', '$key53_1hasil', '$jumlah_key53_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_2hasil', '$jumlah_key53_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_3hasil', '$jumlah_key53_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_4hasil', '$jumlah_key53_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_5hasil', '$jumlah_key53_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_6hasil', '$jumlah_key53_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_7hasil', '$jumlah_key53_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_8hasil', '$jumlah_key53_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_9hasil', '$jumlah_key53_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_10hasil', '$jumlah_key53_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_11hasil', '$jumlah_key53_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_12hasil', '$jumlah_key53_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_13hasil', '$jumlah_key53_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_14hasil', '$jumlah_key53_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '53', '$key53_15hasil', '$jumlah_key53_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data54= mysqli_query($connect,"select * from tb_indikator where id_indikator='54'");		
	while($result54 = mysqli_fetch_array($data54)){	
	$indikator54 = $result54['indikator'];	
	$indikator_kecil54 = strtolower($indikator54);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator54 = str_replace($filter, '', $indikator_kecil54);	
	list($key54_1, $key54_2, $key54_3, $key54_4, $key54_5, $key54_6, $key54_7, $key54_8, $key54_9, $key54_10, $key54_11, $key54_12, $key54_13, $key54_14, $key54_15) = explode(' ', $filter_indikator54);	
		$jumlah_key54_1 = substr_count($source_code, $key54_1);
		$jumlah_key54_2 = substr_count($source_code, $key54_2);
		$jumlah_key54_3 = substr_count($source_code, $key54_3);
		$jumlah_key54_4 = substr_count($source_code, $key54_4);
		$jumlah_key54_5 = substr_count($source_code, $key54_5);
		$jumlah_key54_6 = substr_count($source_code, $key54_6);
		$jumlah_key54_7 = substr_count($source_code, $key54_7);
		$jumlah_key54_8 = substr_count($source_code, $key54_8);
		$jumlah_key54_9 = substr_count($source_code, $key54_9);
		$jumlah_key54_10 = substr_count($source_code, $key54_10);
		$jumlah_key54_11 = substr_count($source_code, $key54_11);
		$jumlah_key54_12 = substr_count($source_code, $key54_12);
		$jumlah_key54_13 = substr_count($source_code, $key54_13);
		$jumlah_key54_14 = substr_count($source_code, $key54_14);
		$jumlah_key54_15 = substr_count($source_code, $key54_15);
	    }	
		
if($jumlah_key54_1 > 0){$jumlah_key54_1hasil = 1 ; }else{$jumlah_key54_1hasil = 0 ;}		
if($jumlah_key54_2 > 0){$jumlah_key54_2hasil = 1 ; }else{$jumlah_key54_2hasil = 0 ;}		
if($jumlah_key54_3 > 0){$jumlah_key54_3hasil = 1 ; }else{$jumlah_key54_3hasil = 0 ;}		
if($jumlah_key54_4 > 0){$jumlah_key54_4hasil = 1 ; }else{$jumlah_key54_4hasil = 0 ;}		
if($jumlah_key54_5 > 0){$jumlah_key54_5hasil = 1 ; }else{$jumlah_key54_5hasil = 0 ;}		
if($jumlah_key54_6 > 0){$jumlah_key54_6hasil = 1 ; }else{$jumlah_key54_6hasil = 0 ;}		
if($jumlah_key54_7 > 0){$jumlah_key54_7hasil = 1 ; }else{$jumlah_key54_7hasil = 0 ;}		
if($jumlah_key54_8 > 0){$jumlah_key54_8hasil = 1 ; }else{$jumlah_key54_8hasil = 0 ;}		
if($jumlah_key54_9 > 0){$jumlah_key54_9hasil = 1 ; }else{$jumlah_key54_9hasil = 0 ;}		
if($jumlah_key54_10 > 0){$jumlah_key54_10hasil = 1 ; }else{$jumlah_key54_10hasil = 0 ;}		
if($jumlah_key54_11 > 0){$jumlah_key54_11hasil = 1 ; }else{$jumlah_key54_11hasil = 0 ;}		
if($jumlah_key54_12 > 0){$jumlah_key54_12hasil = 1 ; }else{$jumlah_key54_12hasil = 0 ;}		
if($jumlah_key54_13 > 0){$jumlah_key54_13hasil = 1 ; }else{$jumlah_key54_13hasil = 0 ;}		
if($jumlah_key54_14 > 0){$jumlah_key54_14hasil = 1 ; }else{$jumlah_key54_14hasil = 0 ;}		
if($jumlah_key54_15 > 0){$jumlah_key54_15hasil = 1 ; }else{$jumlah_key54_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '54', '$key54_1hasil', '$jumlah_key54_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_2hasil', '$jumlah_key54_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_3hasil', '$jumlah_key54_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_4hasil', '$jumlah_key54_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_5hasil', '$jumlah_key54_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_6hasil', '$jumlah_key54_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_7hasil', '$jumlah_key54_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_8hasil', '$jumlah_key54_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_9hasil', '$jumlah_key54_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_10hasil', '$jumlah_key54_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_11hasil', '$jumlah_key54_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_12hasil', '$jumlah_key54_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_13hasil', '$jumlah_key54_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_14hasil', '$jumlah_key54_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '54', '$key54_15hasil', '$jumlah_key54_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data55= mysqli_query($connect,"select * from tb_indikator where id_indikator='55'");		
	while($result55 = mysqli_fetch_array($data55)){	
	$indikator55 = $result55['indikator'];	
	$indikator_kecil55 = strtolower($indikator55);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator55 = str_replace($filter, '', $indikator_kecil55);	
	list($key55_1, $key55_2, $key55_3, $key55_4, $key55_5, $key55_6, $key55_7, $key55_8, $key55_9, $key55_10, $key55_11, $key55_12, $key55_13, $key55_14, $key55_15) = explode(' ', $filter_indikator55);	
		$jumlah_key55_1 = substr_count($source_code, $key55_1);
		$jumlah_key55_2 = substr_count($source_code, $key55_2);
		$jumlah_key55_3 = substr_count($source_code, $key55_3);
		$jumlah_key55_4 = substr_count($source_code, $key55_4);
		$jumlah_key55_5 = substr_count($source_code, $key55_5);
		$jumlah_key55_6 = substr_count($source_code, $key55_6);
		$jumlah_key55_7 = substr_count($source_code, $key55_7);
		$jumlah_key55_8 = substr_count($source_code, $key55_8);
		$jumlah_key55_9 = substr_count($source_code, $key55_9);
		$jumlah_key55_10 = substr_count($source_code, $key55_10);
		$jumlah_key55_11 = substr_count($source_code, $key55_11);
		$jumlah_key55_12 = substr_count($source_code, $key55_12);
		$jumlah_key55_13 = substr_count($source_code, $key55_13);
		$jumlah_key55_14 = substr_count($source_code, $key55_14);
		$jumlah_key55_15 = substr_count($source_code, $key55_15);
	    }	
		
if($jumlah_key55_1 > 0){$jumlah_key55_1hasil = 1 ; }else{$jumlah_key55_1hasil = 0 ;}		
if($jumlah_key55_2 > 0){$jumlah_key55_2hasil = 1 ; }else{$jumlah_key55_2hasil = 0 ;}		
if($jumlah_key55_3 > 0){$jumlah_key55_3hasil = 1 ; }else{$jumlah_key55_3hasil = 0 ;}		
if($jumlah_key55_4 > 0){$jumlah_key55_4hasil = 1 ; }else{$jumlah_key55_4hasil = 0 ;}		
if($jumlah_key55_5 > 0){$jumlah_key55_5hasil = 1 ; }else{$jumlah_key55_5hasil = 0 ;}		
if($jumlah_key55_6 > 0){$jumlah_key55_6hasil = 1 ; }else{$jumlah_key55_6hasil = 0 ;}		
if($jumlah_key55_7 > 0){$jumlah_key55_7hasil = 1 ; }else{$jumlah_key55_7hasil = 0 ;}		
if($jumlah_key55_8 > 0){$jumlah_key55_8hasil = 1 ; }else{$jumlah_key55_8hasil = 0 ;}		
if($jumlah_key55_9 > 0){$jumlah_key55_9hasil = 1 ; }else{$jumlah_key55_9hasil = 0 ;}		
if($jumlah_key55_10 > 0){$jumlah_key55_10hasil = 1 ; }else{$jumlah_key55_10hasil = 0 ;}		
if($jumlah_key55_11 > 0){$jumlah_key55_11hasil = 1 ; }else{$jumlah_key55_11hasil = 0 ;}		
if($jumlah_key55_12 > 0){$jumlah_key55_12hasil = 1 ; }else{$jumlah_key55_12hasil = 0 ;}		
if($jumlah_key55_13 > 0){$jumlah_key55_13hasil = 1 ; }else{$jumlah_key55_13hasil = 0 ;}		
if($jumlah_key55_14 > 0){$jumlah_key55_14hasil = 1 ; }else{$jumlah_key55_14hasil = 0 ;}		
if($jumlah_key55_15 > 0){$jumlah_key55_15hasil = 1 ; }else{$jumlah_key55_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '55', '$key55_1hasil', '$jumlah_key55_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_2hasil', '$jumlah_key55_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_3hasil', '$jumlah_key55_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_4hasil', '$jumlah_key55_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_5hasil', '$jumlah_key55_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_6hasil', '$jumlah_key55_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_7hasil', '$jumlah_key55_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_8hasil', '$jumlah_key55_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_9hasil', '$jumlah_key55_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_10hasil', '$jumlah_key55_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_11hasil', '$jumlah_key55_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_12hasil', '$jumlah_key55_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_13hasil', '$jumlah_key55_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_14hasil', '$jumlah_key55_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '55', '$key55_15hasil', '$jumlah_key55_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data56= mysqli_query($connect,"select * from tb_indikator where id_indikator='56'");		
	while($result56 = mysqli_fetch_array($data56)){	
	$indikator56 = $result56['indikator'];	
	$indikator_kecil56 = strtolower($indikator56);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator56 = str_replace($filter, '', $indikator_kecil56);	
	list($key56_1, $key56_2, $key56_3, $key56_4, $key56_5, $key56_6, $key56_7, $key56_8, $key56_9, $key56_10, $key56_11, $key56_12, $key56_13, $key56_14, $key56_15) = explode(' ', $filter_indikator56);	
		$jumlah_key56_1 = substr_count($source_code, $key56_1);
		$jumlah_key56_2 = substr_count($source_code, $key56_2);
		$jumlah_key56_3 = substr_count($source_code, $key56_3);
		$jumlah_key56_4 = substr_count($source_code, $key56_4);
		$jumlah_key56_5 = substr_count($source_code, $key56_5);
		$jumlah_key56_6 = substr_count($source_code, $key56_6);
		$jumlah_key56_7 = substr_count($source_code, $key56_7);
		$jumlah_key56_8 = substr_count($source_code, $key56_8);
		$jumlah_key56_9 = substr_count($source_code, $key56_9);
		$jumlah_key56_10 = substr_count($source_code, $key56_10);
		$jumlah_key56_11 = substr_count($source_code, $key56_11);
		$jumlah_key56_12 = substr_count($source_code, $key56_12);
		$jumlah_key56_13 = substr_count($source_code, $key56_13);
		$jumlah_key56_14 = substr_count($source_code, $key56_14);
		$jumlah_key56_15 = substr_count($source_code, $key56_15);
	    }	
		
if($jumlah_key56_1 > 0){$jumlah_key56_1hasil = 1 ; }else{$jumlah_key56_1hasil = 0 ;}		
if($jumlah_key56_2 > 0){$jumlah_key56_2hasil = 1 ; }else{$jumlah_key56_2hasil = 0 ;}		
if($jumlah_key56_3 > 0){$jumlah_key56_3hasil = 1 ; }else{$jumlah_key56_3hasil = 0 ;}		
if($jumlah_key56_4 > 0){$jumlah_key56_4hasil = 1 ; }else{$jumlah_key56_4hasil = 0 ;}		
if($jumlah_key56_5 > 0){$jumlah_key56_5hasil = 1 ; }else{$jumlah_key56_5hasil = 0 ;}		
if($jumlah_key56_6 > 0){$jumlah_key56_6hasil = 1 ; }else{$jumlah_key56_6hasil = 0 ;}		
if($jumlah_key56_7 > 0){$jumlah_key56_7hasil = 1 ; }else{$jumlah_key56_7hasil = 0 ;}		
if($jumlah_key56_8 > 0){$jumlah_key56_8hasil = 1 ; }else{$jumlah_key56_8hasil = 0 ;}		
if($jumlah_key56_9 > 0){$jumlah_key56_9hasil = 1 ; }else{$jumlah_key56_9hasil = 0 ;}		
if($jumlah_key56_10 > 0){$jumlah_key56_10hasil = 1 ; }else{$jumlah_key56_10hasil = 0 ;}		
if($jumlah_key56_11 > 0){$jumlah_key56_11hasil = 1 ; }else{$jumlah_key56_11hasil = 0 ;}		
if($jumlah_key56_12 > 0){$jumlah_key56_12hasil = 1 ; }else{$jumlah_key56_12hasil = 0 ;}		
if($jumlah_key56_13 > 0){$jumlah_key56_13hasil = 1 ; }else{$jumlah_key56_13hasil = 0 ;}		
if($jumlah_key56_14 > 0){$jumlah_key56_14hasil = 1 ; }else{$jumlah_key56_14hasil = 0 ;}		
if($jumlah_key56_15 > 0){$jumlah_key56_15hasil = 1 ; }else{$jumlah_key56_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '56', '$key56_1hasil', '$jumlah_key56_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_2hasil', '$jumlah_key56_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_3hasil', '$jumlah_key56_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_4hasil', '$jumlah_key56_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_5hasil', '$jumlah_key56_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_6hasil', '$jumlah_key56_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_7hasil', '$jumlah_key56_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_8hasil', '$jumlah_key56_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_9hasil', '$jumlah_key56_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_10hasil', '$jumlah_key56_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_11hasil', '$jumlah_key56_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_12hasil', '$jumlah_key56_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_13hasil', '$jumlah_key56_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_14hasil', '$jumlah_key56_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '56', '$key56_15hasil', '$jumlah_key56_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data57= mysqli_query($connect,"select * from tb_indikator where id_indikator='57'");		
	while($result57 = mysqli_fetch_array($data57)){	
	$indikator57 = $result57['indikator'];	
	$indikator_kecil57 = strtolower($indikator57);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator57 = str_replace($filter, '', $indikator_kecil57);	
	list($key57_1, $key57_2, $key57_3, $key57_4, $key57_5, $key57_6, $key57_7, $key57_8, $key57_9, $key57_10, $key57_11, $key57_12, $key57_13, $key57_14, $key57_15) = explode(' ', $filter_indikator57);	
		$jumlah_key57_1 = substr_count($source_code, $key57_1);
		$jumlah_key57_2 = substr_count($source_code, $key57_2);
		$jumlah_key57_3 = substr_count($source_code, $key57_3);
		$jumlah_key57_4 = substr_count($source_code, $key57_4);
		$jumlah_key57_5 = substr_count($source_code, $key57_5);
		$jumlah_key57_6 = substr_count($source_code, $key57_6);
		$jumlah_key57_7 = substr_count($source_code, $key57_7);
		$jumlah_key57_8 = substr_count($source_code, $key57_8);
		$jumlah_key57_9 = substr_count($source_code, $key57_9);
		$jumlah_key57_10 = substr_count($source_code, $key57_10);
		$jumlah_key57_11 = substr_count($source_code, $key57_11);
		$jumlah_key57_12 = substr_count($source_code, $key57_12);
		$jumlah_key57_13 = substr_count($source_code, $key57_13);
		$jumlah_key57_14 = substr_count($source_code, $key57_14);
		$jumlah_key57_15 = substr_count($source_code, $key57_15);
	    }	
		
if($jumlah_key57_1 > 0){$jumlah_key57_1hasil = 1 ; }else{$jumlah_key57_1hasil = 0 ;}		
if($jumlah_key57_2 > 0){$jumlah_key57_2hasil = 1 ; }else{$jumlah_key57_2hasil = 0 ;}		
if($jumlah_key57_3 > 0){$jumlah_key57_3hasil = 1 ; }else{$jumlah_key57_3hasil = 0 ;}		
if($jumlah_key57_4 > 0){$jumlah_key57_4hasil = 1 ; }else{$jumlah_key57_4hasil = 0 ;}		
if($jumlah_key57_5 > 0){$jumlah_key57_5hasil = 1 ; }else{$jumlah_key57_5hasil = 0 ;}		
if($jumlah_key57_6 > 0){$jumlah_key57_6hasil = 1 ; }else{$jumlah_key57_6hasil = 0 ;}		
if($jumlah_key57_7 > 0){$jumlah_key57_7hasil = 1 ; }else{$jumlah_key57_7hasil = 0 ;}		
if($jumlah_key57_8 > 0){$jumlah_key57_8hasil = 1 ; }else{$jumlah_key57_8hasil = 0 ;}		
if($jumlah_key57_9 > 0){$jumlah_key57_9hasil = 1 ; }else{$jumlah_key57_9hasil = 0 ;}		
if($jumlah_key57_10 > 0){$jumlah_key57_10hasil = 1 ; }else{$jumlah_key57_10hasil = 0 ;}		
if($jumlah_key57_11 > 0){$jumlah_key57_11hasil = 1 ; }else{$jumlah_key57_11hasil = 0 ;}		
if($jumlah_key57_12 > 0){$jumlah_key57_12hasil = 1 ; }else{$jumlah_key57_12hasil = 0 ;}		
if($jumlah_key57_13 > 0){$jumlah_key57_13hasil = 1 ; }else{$jumlah_key57_13hasil = 0 ;}		
if($jumlah_key57_14 > 0){$jumlah_key57_14hasil = 1 ; }else{$jumlah_key57_14hasil = 0 ;}		
if($jumlah_key57_15 > 0){$jumlah_key57_15hasil = 1 ; }else{$jumlah_key57_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '57', '$key57_1hasil', '$jumlah_key57_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_2hasil', '$jumlah_key57_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_3hasil', '$jumlah_key57_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_4hasil', '$jumlah_key57_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_5hasil', '$jumlah_key57_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_6hasil', '$jumlah_key57_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_7hasil', '$jumlah_key57_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_8hasil', '$jumlah_key57_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_9hasil', '$jumlah_key57_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_10hasil', '$jumlah_key57_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_11hasil', '$jumlah_key57_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_12hasil', '$jumlah_key57_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_13hasil', '$jumlah_key57_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_14hasil', '$jumlah_key57_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '57', '$key57_15hasil', '$jumlah_key57_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data58= mysqli_query($connect,"select * from tb_indikator where id_indikator='58'");		
	while($result58 = mysqli_fetch_array($data58)){	
	$indikator58 = $result58['indikator'];	
	$indikator_kecil58 = strtolower($indikator58);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator58 = str_replace($filter, '', $indikator_kecil58);	
	list($key58_1, $key58_2, $key58_3, $key58_4, $key58_5, $key58_6, $key58_7, $key58_8, $key58_9, $key58_10, $key58_11, $key58_12, $key58_13, $key58_14, $key58_15) = explode(' ', $filter_indikator58);	
		$jumlah_key58_1 = substr_count($source_code, $key58_1);
		$jumlah_key58_2 = substr_count($source_code, $key58_2);
		$jumlah_key58_3 = substr_count($source_code, $key58_3);
		$jumlah_key58_4 = substr_count($source_code, $key58_4);
		$jumlah_key58_5 = substr_count($source_code, $key58_5);
		$jumlah_key58_6 = substr_count($source_code, $key58_6);
		$jumlah_key58_7 = substr_count($source_code, $key58_7);
		$jumlah_key58_8 = substr_count($source_code, $key58_8);
		$jumlah_key58_9 = substr_count($source_code, $key58_9);
		$jumlah_key58_10 = substr_count($source_code, $key58_10);
		$jumlah_key58_11 = substr_count($source_code, $key58_11);
		$jumlah_key58_12 = substr_count($source_code, $key58_12);
		$jumlah_key58_13 = substr_count($source_code, $key58_13);
		$jumlah_key58_14 = substr_count($source_code, $key58_14);
		$jumlah_key58_15 = substr_count($source_code, $key58_15);
	    }	
		
if($jumlah_key58_1 > 0){$jumlah_key58_1hasil = 1 ; }else{$jumlah_key58_1hasil = 0 ;}		
if($jumlah_key58_2 > 0){$jumlah_key58_2hasil = 1 ; }else{$jumlah_key58_2hasil = 0 ;}		
if($jumlah_key58_3 > 0){$jumlah_key58_3hasil = 1 ; }else{$jumlah_key58_3hasil = 0 ;}		
if($jumlah_key58_4 > 0){$jumlah_key58_4hasil = 1 ; }else{$jumlah_key58_4hasil = 0 ;}		
if($jumlah_key58_5 > 0){$jumlah_key58_5hasil = 1 ; }else{$jumlah_key58_5hasil = 0 ;}		
if($jumlah_key58_6 > 0){$jumlah_key58_6hasil = 1 ; }else{$jumlah_key58_6hasil = 0 ;}		
if($jumlah_key58_7 > 0){$jumlah_key58_7hasil = 1 ; }else{$jumlah_key58_7hasil = 0 ;}		
if($jumlah_key58_8 > 0){$jumlah_key58_8hasil = 1 ; }else{$jumlah_key58_8hasil = 0 ;}		
if($jumlah_key58_9 > 0){$jumlah_key58_9hasil = 1 ; }else{$jumlah_key58_9hasil = 0 ;}		
if($jumlah_key58_10 > 0){$jumlah_key58_10hasil = 1 ; }else{$jumlah_key58_10hasil = 0 ;}		
if($jumlah_key58_11 > 0){$jumlah_key58_11hasil = 1 ; }else{$jumlah_key58_11hasil = 0 ;}		
if($jumlah_key58_12 > 0){$jumlah_key58_12hasil = 1 ; }else{$jumlah_key58_12hasil = 0 ;}		
if($jumlah_key58_13 > 0){$jumlah_key58_13hasil = 1 ; }else{$jumlah_key58_13hasil = 0 ;}		
if($jumlah_key58_14 > 0){$jumlah_key58_14hasil = 1 ; }else{$jumlah_key58_14hasil = 0 ;}		
if($jumlah_key58_15 > 0){$jumlah_key58_15hasil = 1 ; }else{$jumlah_key58_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '58', '$key58_1hasil', '$jumlah_key58_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_2hasil', '$jumlah_key58_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_3hasil', '$jumlah_key58_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_4hasil', '$jumlah_key58_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_5hasil', '$jumlah_key58_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_6hasil', '$jumlah_key58_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_7hasil', '$jumlah_key58_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_8hasil', '$jumlah_key58_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_9hasil', '$jumlah_key58_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_10hasil', '$jumlah_key58_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_11hasil', '$jumlah_key58_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_12hasil', '$jumlah_key58_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_13hasil', '$jumlah_key58_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_14hasil', '$jumlah_key58_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '58', '$key58_15hasil', '$jumlah_key58_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data59= mysqli_query($connect,"select * from tb_indikator where id_indikator='59'");		
	while($result59 = mysqli_fetch_array($data59)){	
	$indikator59 = $result59['indikator'];	
	$indikator_kecil59 = strtolower($indikator59);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator59 = str_replace($filter, '', $indikator_kecil59);	
	list($key59_1, $key59_2, $key59_3, $key59_4, $key59_5, $key59_6, $key59_7, $key59_8, $key59_9, $key59_10, $key59_11, $key59_12, $key59_13, $key59_14, $key59_15) = explode(' ', $filter_indikator59);	
		$jumlah_key59_1 = substr_count($source_code, $key59_1);
		$jumlah_key59_2 = substr_count($source_code, $key59_2);
		$jumlah_key59_3 = substr_count($source_code, $key59_3);
		$jumlah_key59_4 = substr_count($source_code, $key59_4);
		$jumlah_key59_5 = substr_count($source_code, $key59_5);
		$jumlah_key59_6 = substr_count($source_code, $key59_6);
		$jumlah_key59_7 = substr_count($source_code, $key59_7);
		$jumlah_key59_8 = substr_count($source_code, $key59_8);
		$jumlah_key59_9 = substr_count($source_code, $key59_9);
		$jumlah_key59_10 = substr_count($source_code, $key59_10);
		$jumlah_key59_11 = substr_count($source_code, $key59_11);
		$jumlah_key59_12 = substr_count($source_code, $key59_12);
		$jumlah_key59_13 = substr_count($source_code, $key59_13);
		$jumlah_key59_14 = substr_count($source_code, $key59_14);
		$jumlah_key59_15 = substr_count($source_code, $key59_15);
	    }	
		
if($jumlah_key59_1 > 0){$jumlah_key59_1hasil = 1 ; }else{$jumlah_key59_1hasil = 0 ;}		
if($jumlah_key59_2 > 0){$jumlah_key59_2hasil = 1 ; }else{$jumlah_key59_2hasil = 0 ;}		
if($jumlah_key59_3 > 0){$jumlah_key59_3hasil = 1 ; }else{$jumlah_key59_3hasil = 0 ;}		
if($jumlah_key59_4 > 0){$jumlah_key59_4hasil = 1 ; }else{$jumlah_key59_4hasil = 0 ;}		
if($jumlah_key59_5 > 0){$jumlah_key59_5hasil = 1 ; }else{$jumlah_key59_5hasil = 0 ;}		
if($jumlah_key59_6 > 0){$jumlah_key59_6hasil = 1 ; }else{$jumlah_key59_6hasil = 0 ;}		
if($jumlah_key59_7 > 0){$jumlah_key59_7hasil = 1 ; }else{$jumlah_key59_7hasil = 0 ;}		
if($jumlah_key59_8 > 0){$jumlah_key59_8hasil = 1 ; }else{$jumlah_key59_8hasil = 0 ;}		
if($jumlah_key59_9 > 0){$jumlah_key59_9hasil = 1 ; }else{$jumlah_key59_9hasil = 0 ;}		
if($jumlah_key59_10 > 0){$jumlah_key59_10hasil = 1 ; }else{$jumlah_key59_10hasil = 0 ;}		
if($jumlah_key59_11 > 0){$jumlah_key59_11hasil = 1 ; }else{$jumlah_key59_11hasil = 0 ;}		
if($jumlah_key59_12 > 0){$jumlah_key59_12hasil = 1 ; }else{$jumlah_key59_12hasil = 0 ;}		
if($jumlah_key59_13 > 0){$jumlah_key59_13hasil = 1 ; }else{$jumlah_key59_13hasil = 0 ;}		
if($jumlah_key59_14 > 0){$jumlah_key59_14hasil = 1 ; }else{$jumlah_key59_14hasil = 0 ;}		
if($jumlah_key59_15 > 0){$jumlah_key59_15hasil = 1 ; }else{$jumlah_key59_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '59', '$key59_1hasil', '$jumlah_key59_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_2hasil', '$jumlah_key59_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_3hasil', '$jumlah_key59_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_4hasil', '$jumlah_key59_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_5hasil', '$jumlah_key59_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_6hasil', '$jumlah_key59_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_7hasil', '$jumlah_key59_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_8hasil', '$jumlah_key59_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_9hasil', '$jumlah_key59_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_10hasil', '$jumlah_key59_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_11hasil', '$jumlah_key59_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_12hasil', '$jumlah_key59_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_13hasil', '$jumlah_key59_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_14hasil', '$jumlah_key59_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '59', '$key59_15hasil', '$jumlah_key59_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data60= mysqli_query($connect,"select * from tb_indikator where id_indikator='60'");		
	while($result60 = mysqli_fetch_array($data60)){	
	$indikator60 = $result60['indikator'];	
	$indikator_kecil60 = strtolower($indikator60);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator60 = str_replace($filter, '', $indikator_kecil60);	
	list($key60_1, $key60_2, $key60_3, $key60_4, $key60_5, $key60_6, $key60_7, $key60_8, $key60_9, $key60_10, $key60_11, $key60_12, $key60_13, $key60_14, $key60_15) = explode(' ', $filter_indikator60);	
		$jumlah_key60_1 = substr_count($source_code, $key60_1);
		$jumlah_key60_2 = substr_count($source_code, $key60_2);
		$jumlah_key60_3 = substr_count($source_code, $key60_3);
		$jumlah_key60_4 = substr_count($source_code, $key60_4);
		$jumlah_key60_5 = substr_count($source_code, $key60_5);
		$jumlah_key60_6 = substr_count($source_code, $key60_6);
		$jumlah_key60_7 = substr_count($source_code, $key60_7);
		$jumlah_key60_8 = substr_count($source_code, $key60_8);
		$jumlah_key60_9 = substr_count($source_code, $key60_9);
		$jumlah_key60_10 = substr_count($source_code, $key60_10);
		$jumlah_key60_11 = substr_count($source_code, $key60_11);
		$jumlah_key60_12 = substr_count($source_code, $key60_12);
		$jumlah_key60_13 = substr_count($source_code, $key60_13);
		$jumlah_key60_14 = substr_count($source_code, $key60_14);
		$jumlah_key60_15 = substr_count($source_code, $key60_15);
	    }	
		
if($jumlah_key60_1 > 0){$jumlah_key60_1hasil = 1 ; }else{$jumlah_key60_1hasil = 0 ;}		
if($jumlah_key60_2 > 0){$jumlah_key60_2hasil = 1 ; }else{$jumlah_key60_2hasil = 0 ;}		
if($jumlah_key60_3 > 0){$jumlah_key60_3hasil = 1 ; }else{$jumlah_key60_3hasil = 0 ;}		
if($jumlah_key60_4 > 0){$jumlah_key60_4hasil = 1 ; }else{$jumlah_key60_4hasil = 0 ;}		
if($jumlah_key60_5 > 0){$jumlah_key60_5hasil = 1 ; }else{$jumlah_key60_5hasil = 0 ;}		
if($jumlah_key60_6 > 0){$jumlah_key60_6hasil = 1 ; }else{$jumlah_key60_6hasil = 0 ;}		
if($jumlah_key60_7 > 0){$jumlah_key60_7hasil = 1 ; }else{$jumlah_key60_7hasil = 0 ;}		
if($jumlah_key60_8 > 0){$jumlah_key60_8hasil = 1 ; }else{$jumlah_key60_8hasil = 0 ;}		
if($jumlah_key60_9 > 0){$jumlah_key60_9hasil = 1 ; }else{$jumlah_key60_9hasil = 0 ;}		
if($jumlah_key60_10 > 0){$jumlah_key60_10hasil = 1 ; }else{$jumlah_key60_10hasil = 0 ;}		
if($jumlah_key60_11 > 0){$jumlah_key60_11hasil = 1 ; }else{$jumlah_key60_11hasil = 0 ;}		
if($jumlah_key60_12 > 0){$jumlah_key60_12hasil = 1 ; }else{$jumlah_key60_12hasil = 0 ;}		
if($jumlah_key60_13 > 0){$jumlah_key60_13hasil = 1 ; }else{$jumlah_key60_13hasil = 0 ;}		
if($jumlah_key60_14 > 0){$jumlah_key60_14hasil = 1 ; }else{$jumlah_key60_14hasil = 0 ;}		
if($jumlah_key60_15 > 0){$jumlah_key60_15hasil = 1 ; }else{$jumlah_key60_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '60', '$key60_1hasil', '$jumlah_key60_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_2hasil', '$jumlah_key60_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_3hasil', '$jumlah_key60_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_4hasil', '$jumlah_key60_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_5hasil', '$jumlah_key60_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_6hasil', '$jumlah_key60_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_7hasil', '$jumlah_key60_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_8hasil', '$jumlah_key60_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_9hasil', '$jumlah_key60_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_10hasil', '$jumlah_key60_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_11hasil', '$jumlah_key60_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_12hasil', '$jumlah_key60_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_13hasil', '$jumlah_key60_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_14hasil', '$jumlah_key60_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '60', '$key60_15hasil', '$jumlah_key60_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data61= mysqli_query($connect,"select * from tb_indikator where id_indikator='61'");		
	while($result61 = mysqli_fetch_array($data61)){	
	$indikator61 = $result61['indikator'];	
	$indikator_kecil61 = strtolower($indikator61);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator61 = str_replace($filter, '', $indikator_kecil61);	
	list($key61_1, $key61_2, $key61_3, $key61_4, $key61_5, $key61_6, $key61_7, $key61_8, $key61_9, $key61_10, $key61_11, $key61_12, $key61_13, $key61_14, $key61_15) = explode(' ', $filter_indikator61);	
		$jumlah_key61_1 = substr_count($source_code, $key61_1);
		$jumlah_key61_2 = substr_count($source_code, $key61_2);
		$jumlah_key61_3 = substr_count($source_code, $key61_3);
		$jumlah_key61_4 = substr_count($source_code, $key61_4);
		$jumlah_key61_5 = substr_count($source_code, $key61_5);
		$jumlah_key61_6 = substr_count($source_code, $key61_6);
		$jumlah_key61_7 = substr_count($source_code, $key61_7);
		$jumlah_key61_8 = substr_count($source_code, $key61_8);
		$jumlah_key61_9 = substr_count($source_code, $key61_9);
		$jumlah_key61_10 = substr_count($source_code, $key61_10);
		$jumlah_key61_11 = substr_count($source_code, $key61_11);
		$jumlah_key61_12 = substr_count($source_code, $key61_12);
		$jumlah_key61_13 = substr_count($source_code, $key61_13);
		$jumlah_key61_14 = substr_count($source_code, $key61_14);
		$jumlah_key61_15 = substr_count($source_code, $key61_15);
	    }	
		
if($jumlah_key61_1 > 0){$jumlah_key61_1hasil = 1 ; }else{$jumlah_key61_1hasil = 0 ;}		
if($jumlah_key61_2 > 0){$jumlah_key61_2hasil = 1 ; }else{$jumlah_key61_2hasil = 0 ;}		
if($jumlah_key61_3 > 0){$jumlah_key61_3hasil = 1 ; }else{$jumlah_key61_3hasil = 0 ;}		
if($jumlah_key61_4 > 0){$jumlah_key61_4hasil = 1 ; }else{$jumlah_key61_4hasil = 0 ;}		
if($jumlah_key61_5 > 0){$jumlah_key61_5hasil = 1 ; }else{$jumlah_key61_5hasil = 0 ;}		
if($jumlah_key61_6 > 0){$jumlah_key61_6hasil = 1 ; }else{$jumlah_key61_6hasil = 0 ;}		
if($jumlah_key61_7 > 0){$jumlah_key61_7hasil = 1 ; }else{$jumlah_key61_7hasil = 0 ;}		
if($jumlah_key61_8 > 0){$jumlah_key61_8hasil = 1 ; }else{$jumlah_key61_8hasil = 0 ;}		
if($jumlah_key61_9 > 0){$jumlah_key61_9hasil = 1 ; }else{$jumlah_key61_9hasil = 0 ;}		
if($jumlah_key61_10 > 0){$jumlah_key61_10hasil = 1 ; }else{$jumlah_key61_10hasil = 0 ;}		
if($jumlah_key61_11 > 0){$jumlah_key61_11hasil = 1 ; }else{$jumlah_key61_11hasil = 0 ;}		
if($jumlah_key61_12 > 0){$jumlah_key61_12hasil = 1 ; }else{$jumlah_key61_12hasil = 0 ;}		
if($jumlah_key61_13 > 0){$jumlah_key61_13hasil = 1 ; }else{$jumlah_key61_13hasil = 0 ;}		
if($jumlah_key61_14 > 0){$jumlah_key61_14hasil = 1 ; }else{$jumlah_key61_14hasil = 0 ;}		
if($jumlah_key61_15 > 0){$jumlah_key61_15hasil = 1 ; }else{$jumlah_key61_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '61', '$key61_1hasil', '$jumlah_key61_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_2hasil', '$jumlah_key61_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_3hasil', '$jumlah_key61_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_4hasil', '$jumlah_key61_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_5hasil', '$jumlah_key61_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_6hasil', '$jumlah_key61_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_7hasil', '$jumlah_key61_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_8hasil', '$jumlah_key61_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_9hasil', '$jumlah_key61_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_10hasil', '$jumlah_key61_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_11hasil', '$jumlah_key61_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_12hasil', '$jumlah_key61_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_13hasil', '$jumlah_key61_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_14hasil', '$jumlah_key61_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '61', '$key61_15hasil', '$jumlah_key61_15hasil', 'MICE or CVB', '$inputer' )		
    ");		

$data62= mysqli_query($connect,"select * from tb_indikator where id_indikator='62'");		
	while($result62 = mysqli_fetch_array($data62)){	
	$indikator62 = $result62['indikator'];	
	$indikator_kecil62 = strtolower($indikator62);	
	$filter = array(".",",","!","?","(",")","-","_");	
	$filter_indikator62 = str_replace($filter, '', $indikator_kecil62);	
	list($key62_1, $key62_2, $key62_3, $key62_4, $key62_5, $key62_6, $key62_7, $key62_8, $key62_9, $key62_10, $key62_11, $key62_12, $key62_13, $key62_14, $key62_15) = explode(' ', $filter_indikator62);	
		$jumlah_key62_1 = substr_count($source_code, $key62_1);
		$jumlah_key62_2 = substr_count($source_code, $key62_2);
		$jumlah_key62_3 = substr_count($source_code, $key62_3);
		$jumlah_key62_4 = substr_count($source_code, $key62_4);
		$jumlah_key62_5 = substr_count($source_code, $key62_5);
		$jumlah_key62_6 = substr_count($source_code, $key62_6);
		$jumlah_key62_7 = substr_count($source_code, $key62_7);
		$jumlah_key62_8 = substr_count($source_code, $key62_8);
		$jumlah_key62_9 = substr_count($source_code, $key62_9);
		$jumlah_key62_10 = substr_count($source_code, $key62_10);
		$jumlah_key62_11 = substr_count($source_code, $key62_11);
		$jumlah_key62_12 = substr_count($source_code, $key62_12);
		$jumlah_key62_13 = substr_count($source_code, $key62_13);
		$jumlah_key62_14 = substr_count($source_code, $key62_14);
		$jumlah_key62_15 = substr_count($source_code, $key62_15);
	    }	
		
if($jumlah_key62_1 > 0){$jumlah_key62_1hasil = 1 ; }else{$jumlah_key62_1hasil = 0 ;}		
if($jumlah_key62_2 > 0){$jumlah_key62_2hasil = 1 ; }else{$jumlah_key62_2hasil = 0 ;}		
if($jumlah_key62_3 > 0){$jumlah_key62_3hasil = 1 ; }else{$jumlah_key62_3hasil = 0 ;}		
if($jumlah_key62_4 > 0){$jumlah_key62_4hasil = 1 ; }else{$jumlah_key62_4hasil = 0 ;}		
if($jumlah_key62_5 > 0){$jumlah_key62_5hasil = 1 ; }else{$jumlah_key62_5hasil = 0 ;}		
if($jumlah_key62_6 > 0){$jumlah_key62_6hasil = 1 ; }else{$jumlah_key62_6hasil = 0 ;}		
if($jumlah_key62_7 > 0){$jumlah_key62_7hasil = 1 ; }else{$jumlah_key62_7hasil = 0 ;}		
if($jumlah_key62_8 > 0){$jumlah_key62_8hasil = 1 ; }else{$jumlah_key62_8hasil = 0 ;}		
if($jumlah_key62_9 > 0){$jumlah_key62_9hasil = 1 ; }else{$jumlah_key62_9hasil = 0 ;}		
if($jumlah_key62_10 > 0){$jumlah_key62_10hasil = 1 ; }else{$jumlah_key62_10hasil = 0 ;}		
if($jumlah_key62_11 > 0){$jumlah_key62_11hasil = 1 ; }else{$jumlah_key62_11hasil = 0 ;}		
if($jumlah_key62_12 > 0){$jumlah_key62_12hasil = 1 ; }else{$jumlah_key62_12hasil = 0 ;}		
if($jumlah_key62_13 > 0){$jumlah_key62_13hasil = 1 ; }else{$jumlah_key62_13hasil = 0 ;}		
if($jumlah_key62_14 > 0){$jumlah_key62_14hasil = 1 ; }else{$jumlah_key62_14hasil = 0 ;}		
if($jumlah_key62_15 > 0){$jumlah_key62_15hasil = 1 ; }else{$jumlah_key62_15hasil = 0 ;}		
		
		
 mysqli_query($connect,"INSERT INTO tb_analisakeyword ( id_website, alamat_website, id_indikator, indikator, nilai_indikator, kelompok, inputer) VALUES		
('$id_website', '$alamat_website', '62', '$key62_1hasil', '$jumlah_key62_1hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_2hasil', '$jumlah_key62_2hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_3hasil', '$jumlah_key62_3hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_4hasil', '$jumlah_key62_4hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_5hasil', '$jumlah_key62_5hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_6hasil', '$jumlah_key62_6hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_7hasil', '$jumlah_key62_7hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_8hasil', '$jumlah_key62_8hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_9hasil', '$jumlah_key62_9hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_10hasil', '$jumlah_key62_10hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_11hasil', '$jumlah_key62_11hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_12hasil', '$jumlah_key62_12hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_13hasil', '$jumlah_key62_13hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_14hasil', '$jumlah_key62_14hasil', 'MICE or CVB', '$inputer' ),		
('$id_website', '$alamat_website', '62', '$key62_15hasil', '$jumlah_key62_15hasil', 'MICE or CVB', '$inputer' )		
    ");		



    	
   
  
?>

<script type="text/javascript">
    window.location.replace("http://imam.test/website/read/<?php echo $id_website ; ?>");
</script>

    
    