	</div>
			<!-- /.box-body -->
			<div class="box-footer">
				<center> <a href="https://green.adiva.click"><strong>Automated Checklist</strong></a> - 2024</center>
			</div>
			<!-- /.box-footer-->
		  </div>
		  <!-- /.box -->
		</section>
		<!-- /.content -->
	  </div>
	  <!-- /.content-wrapper -->

	  <footer class="main-footer">
		<div class="pull-right hidden-xs">
		  <b>Version</b> 1.0
		</div>
		<strong><a href="https://adiva.click"></a>.</strong> 
	  </footer>  
	</div>
	<!-- Bootstrap 3.3.7 -->
	<script src="<?php echo base_url('assets/bower_components/bootstrap/dist/js/bootstrap.min.js') ?>"></script>
	<!-- SlimScroll -->
	<script src="<?php echo base_url('assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js') ?>"></script>
	<!-- FastClick -->
	<script src="<?php echo base_url('assets/bower_components/fastclick/lib/fastclick.js') ?>"></script>
	<!-- AdminLTE App -->
	<script src="<?php echo base_url('assets/js/adminlte.min.js') ?>"></script>
	<!-- AdminLTE for demo purposes -->
	<script src="<?php echo base_url('assets/js/demo.js') ?>"></script>
	<script>
	  $(document).ready(function () {
		$('.sidebar-menu').tree()
	  })
	</script>
	</body>
</html>
<!-------------------------------------------------------*/
/* Copyright   : CV Adiva                                */
/* Publish     : Automated Checlist                      */
/*-------------------------------------------------------->