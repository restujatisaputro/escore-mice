<?php 
    mysql_connect("localhost","u197914754_simo","Andri13021980");
    mysql_select_db("u197914754_simo");
?>